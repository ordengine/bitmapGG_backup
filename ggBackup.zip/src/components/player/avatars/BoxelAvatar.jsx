
import React, {useMemo, useRef} from "react";
import {useFrame} from "@react-three/fiber";

import {boxelGeometry, shaderNoise} from 'boxels-shader'

import CustomShaderMaterial from 'three-custom-shader-material'
import * as THREE from "three";
import {InstancedAttribute, Instances, Instance} from "@react-three/drei";


export const BoxelAvatar = (props) => {

    const {
        scale = 0.75,
        skinColor = [2, 0.55, 0],
        bodyScale = [1.3, 1.3, 1.3],
        headScale = [1.0, 1.0, 1.0],
        head = [],
        body = [],
        arms = [],
        legs = [],
        feet = [],
        gloves = [],
        mainHand = [],
        offHand = [],
        idle = null,
        walk = null,
    } = props

    const allInstancesRef = useRef()
    const headRef = useRef()
    const bodyRef = useRef()
    const leftArmRef = useRef()
    const leftHandRef = useRef()
    const rightArmRef = useRef()
    const rightHandRef = useRef()
    const leftLegRef = useRef()
    const leftFootRef = useRef()
    const rightLegRef = useRef()
    const rightFootRef = useRef()

    const bones = {
        all: allInstancesRef,
        head: headRef,
        body: bodyRef,
        leftArm: leftArmRef,
        leftHand: leftHandRef,
        rightArm: rightArmRef,
        rightHand: rightHandRef,
        leftLeg: leftLegRef,
        leftFoot: leftFootRef,
        rightLeg: rightLegRef,
        rightFoot: rightFootRef,
    }
    useFrame((state, dt) => {

            const worldTime = Date.now() / 1000;
            const time03 = worldTime * 0.3;
            const time = worldTime * 1;
            const time2 = worldTime * 12;
            const time3 = worldTime * 12;

            const sin2 = Math.sin(time2)
            const sin03 = Math.cos(time3)





//             if (window.particleMesh1?.current !== null) {
//
//                 const worldPosHand = new THREE.Vector3();
//                 const worldQuatHand = new THREE.Quaternion();
//                 bones.rightHand.current.getWorldPosition(worldPosHand);
//                 bones.rightHand.current.getWorldQuaternion(worldQuatHand);
//
// // Offset in local space (e.g., 0.5 units along the Z-axis)
//                 const offset = new THREE.Vector3(0, 0, 0.5);
//
// // Apply rotation to the offset
//                 offset.applyQuaternion(worldQuatHand);
//
// // Set particle position to the hand’s position plus the rotated offset
//                 worldPosHand.add(offset);
//                 window.particleMesh1.current?.position.copy(worldPosHand);
//
//             }






            if (window.playerMoving) {
                bones.leftLeg.current.rotation.x = Math.sin(time * 12) * 0.9
                bones.rightLeg.current.rotation.x = Math.sin(time * 12) * -0.9

                bones.all.current.rotation.y = -Math.sin(time * 12) * 0.1

                bones.all.current.position.y = Math.abs(Math.cos(time * 12)) * 0.2

                bones.leftArm.current.rotation.x = sin2
                bones.leftArm.current.rotation.y = 0
                bones.leftArm.current.rotation.z = 0.3
                // bones.leftArm.current.rotation.y += Math.sin(time * 3) * 0.002
                // bones.leftArm.current.rotation.z += Math.sin(time * 4) * 0.001

                bones.rightArm.current.rotation.x = sin03
                bones.rightArm.current.rotation.y = 0
                bones.rightArm.current.rotation.z = -0.3

            } else {

                // bones.leftArm.current.rotation.x = 0
                // bones.rightArm.current.rotation.x = 0

                bones.leftArm.current.rotation.x = Math.sin(time) * Math.sin(time * 0.3) * 0.1;
                bones.rightArm.current.rotation.x = Math.sin(time) * Math.sin(time * 0.1) * 0.1;
                //

                bones.all.current.position.y = 0
                bones.all.current.rotation.y = 0
                bones.leftLeg.current.rotation.x =0
                bones.rightLeg.current.rotation.x = 0

                bones.head.current.rotation.y = Math.sin(time) * Math.sin(time * 0.3) * 0.04;
                bones.head.current.rotation.x = Math.sin(time) * Math.sin(time * 0.1) * 0.05;
                //
                // bones.body.current.rotation.x = sin2 * 0.013;
                // bones.body.current.rotation.y = sin03 * 0.006;
                // bones.body.current.rotation.z = sin2 * 0.007;




            }

            if (window.castingSpell) {
                bones.rightArm.current.rotation.x = -2 + Math.sin(time * 12.2) * 0.5
            }


    });

    return (
        <Instances geometry={boxelGeometry} scale={scale} {...props}>
            <meshStandardMaterial flatShading />
            <InstancedAttribute name="angle" defaultValue={0.4}/>
            <InstancedAttribute name="opacity" defaultValue={1}/>


            <group ref={allInstancesRef}>

                <group ref={headRef} position={[0, 1.9 - (1 - bodyScale[1]) - (1 - headScale[1]) * 0.5, 0.06]}
                       scale={headScale}>
                    {head?.map(boxel => (
                        <Instance color={skinColor} {...boxel}/>
                    ))}
                    {head?.find(b => b.hideDefault) ? null : <Instance v color={skinColor} angle={0.5}/>}
                </group>


                <group ref={bodyRef} position={[0, 0.85 - (1 - bodyScale[1]) * 0.5, 0]} scale={bodyScale}>
                    {body?.map(boxel => (
                        <Instance color={skinColor} {...boxel}/>
                    ))}
                    {body?.find(b => b.hideDefault) ? null : <Instance color={skinColor} angle={0.4}/>}
                </group>

                <group ref={leftArmRef} rotation={[0, 0, Math.PI/4]} position={[0.5 * bodyScale[0], 1 - (1 - bodyScale[1]) * 0.5, 0]}>
                    <group rotation={[0, 0, 0]}>

                        {arms?.map(boxel => (
                            <Instance {...boxel} position={[-boxel.position.x, boxel.position.y, boxel.position.z]}/>
                        ))}
                        {arms?.find(b => b.hideDefault) ? null :
                            <Instance color={skinColor} angle={0.1} position={[0, -0.25 * bodyScale[2], 0]}
                                      scale={[0.1, 0.4 * bodyScale[2], 0.1]}/>}

                        <group ref={leftHandRef}  rotation={[0, 0, -Math.PI/4]} position={[0, -0.48 * bodyScale[2], 0]}>
                            {offHand?.map(boxel => (
                                <Instance {...boxel}/>
                            ))}
                            {gloves?.map(boxel => (
                                <Instance {...boxel} position={[-boxel.position.x, boxel.position.y, boxel.position.z]}/>
                            ))}




                            {(offHand?.find(b => b.hideDefault) || gloves?.find(b => b.hideDefault)) ? null :
                                <Instance color={skinColor} position={[0, 0.0, 0]} scale={[0.15, 0.15, 0.15]}/>}
                        </group>
                    </group>
                </group>

                <group ref={rightArmRef} rotation={[0, 0, -Math.PI/4]} position={[-0.5 * bodyScale[0], 1 - (1 - bodyScale[1]) * 0.5, 0]}>
                    <group rotation={[0, 0, 0]}>
                        {arms?.map(boxel => (
                            <Instance {...boxel}/>
                        ))}
                        {arms?.find(b => b.hideDefault) ? null :
                            <Instance color={skinColor} angle={0.1} position={[0, -0.25 * bodyScale[2], 0]}
                                      scale={[0.1, 0.4 * bodyScale[2], 0.1]}/>}

                        <group ref={rightHandRef} rotation={[0, 0, Math.PI/4]}  position={[0, -0.48 * bodyScale[2], 0]}>
                            {mainHand?.map(boxel => (
                                <Instance {...boxel}/>
                            ))}
                            {gloves?.map(boxel => (
                                <Instance {...boxel}/>
                            ))}

                            <Instance color={'brown'} position={[0, 0, 0.6]} scale={[0.1, 0.1, 1.7]} />
                            <Instance color={[12, 4, 1]} position={[0, 0, 1.99]} scale={[0.16, 0.16, 1.7]} />

                            {(mainHand?.find(b => b.hideDefault) || gloves?.find(b => b.hideDefault)) ? null :
                                <Instance color={skinColor} position={[0, 0.0, 0]} scale={[0.15, 0.15, 0.15]}/>}
                        </group>
                    </group>
                </group>

                <group ref={leftLegRef} position={[0.25 - (1 - bodyScale[0]) * 0.25, 0.35, 0]}>
                    <group>


                        {legs?.map(boxel => (
                            <Instance {...boxel} position={[-boxel.position.x, boxel.position.y, boxel.position.z]}/>
                        ))
                        }
                        {legs?.find(b => b.hideDefault) ? null : <group>
                            <Instance color={skinColor} position={[0, -0.11, 0]} scale={[0.05, 0.4, 0.05]}/>
                        </group>}


                        <group ref={leftFootRef} position={[0, -0.3, 0]}>
                            <group rotation={[0, 0, 0]}>
                                {feet?.map(boxel => (
                                    <Instance {...boxel} position={[-boxel.position.x, boxel.position.y, boxel.position.z]}/>
                                ))}

                                {feet?.find(b => b.hideDefault) ? null :
                                    <Instance color={skinColor} angle={0.65} position={[0, 0.0, 0.07]}
                                              scale={[0.15, 0.08, 0.3]}/>}
                            </group>
                        </group>


                    </group>
                </group>

                <group ref={rightLegRef} position={[-0.25 + (1 - bodyScale[0]) * 0.25, 0.35, 0]}>

                    <group rotation={[0, 0, 0]}>
                        {legs?.map(boxel => (
                            <Instance {...boxel}/>
                        ))
                        }
                        {legs?.find(b => b.hideDefault) ? null : <group>
                            <Instance color={skinColor} position={[0, -0.11, 0]} scale={[0.05, 0.4, 0.05]}/>
                        </group>}

                        <group ref={rightFootRef} position={[0, -0.3, 0]}>
                            <group rotation={[0, 0, 0]}>
                                {feet?.map(boxel => (
                                    <Instance {...boxel}/>
                                ))}

                                {feet?.find(b => b.hideDefault) ? null :
                                    <Instance color={skinColor} angle={0.65} position={[0, 0.0, 0.07]}
                                              scale={[0.15, 0.08, 0.3]}/>}
                            </group>
                        </group>
                    </group>


                </group>
            </group>




        </Instances>
    )
}
// [["Main Hand","hammerHandle",2,[0,0,0.22],[0.1,0.1,0.7],[0,0,0,1],[0.3,0.1,0],[true,1,0,0.5]],["Main Hand","hammerHead",3,[0,0.004,0.421],[0.2,0.3,0.2],[0,0,0,1],[3,0,0],[true,1,0.28,0.17]],["Main Hand","dupe-60287150",3,[0,0.082,0.418],[0.214,0.023,0.214],[0,0,0,1],[3,1.53,0],[true,1,0.28,0.17]],["Main Hand","dupe-81204271",3,[0,-0.082,0.422],[0.214,0.023,0.214],[0,0,0,1],[3,1.53,0],[true,1,0.28,0.17]],["Main Hand","dupe-62302921",1,[-0.035,-0.038,0.392],[0.157,0.026,0.029],[0,0,0,1],[2.22,0.57,0],[true,1,-0.1,0.17]],["Main Hand","dupe-67527591",1,[-0.035,0.026,0.42],[0.157,0.078,0.086],[0,0,0,1],[2.22,0.57,0],[true,1,-0.1,0.17]]]
