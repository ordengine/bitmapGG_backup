import {useEffect, useRef, useState} from "react";

window.hammerImageBase64 = ' data:image/webp;base64,UklGRvYYAABXRUJQVlA4TOkYAAAvp8JPEF5h0LaRpCblj3r/OwIRMQHhab7M/BN+yJniO4S2NbzTIsM5DIxDHYB2pxR6c6FKAuG6KoATmgSPBLdAjWpAD5aL4giQMAoFnLhmqrEJQAsFSACkFNhSHmcVzXOnSD7IWt/FH2i+SAk2H3ZeSrKtvZGifym5FC2DIUvwbsZS7ApYov7v/5T6s1TEdyf4uWbYjBLeZoRYQGWo8NAYEWVGbdRODD2ofTNkJElQoxzKoAzKoizKIjzCm7TjSJKcOJsm8NRQT9QJhGwkSeVQHmVQHuVRHuVMCguSZCVS9VuhsHMbDt7KFyVX2xbLTS8lnCyjh2a3vIJeQHhMpgWEmYYZMgyztVT9+H3v9//loCk4MrNdsUOjv0HJqKSWusJXhnsl32CbZJfDSTsVqVshyVFs220jKIbSCwwvu/3NQFAMwcteUoAIQIoSApeJJElSdbVsgt0FeUPJCdSNXoFAojr6JsmibbuqmrV9bE5zd/GRNAJB7Scd19YWSVIvpb3eRi2hudsck2H/3kR83/ve+zL+IY9Kvz/MzPArpJDaHJ5VxDBk6bcGmiEkVpFtp7EQSewj0iKFsSghn+VeCUrbSHKTCz9cWDhw+y8Jtq2wbQ7JyMAP8SZJq/+F3HQnt9n2NpJamVK2lC3BFrC1k////UbrQuGf8KKJGO0WwPPpmgIGWEeA5xQOLrvwBIxCBW0bOdQKrUB+dAFV1DaSm10IC2EgbLmS5/QfEts2kiR79uhsl8ezqGRStWd/j2OaY/5zzH9eIojDODyH73ALl7JpiTkNKJEphwWmnRLK5Q4XBpTaL1YfaHFjcrkMi9qwP2cwk2ENYUoaqYBx52XyEHiWStdDVBtlSLYGFzfgyFKDm8AjnJ7hpKnN1MHXp9XRQzSHQ4sbHnD0/fYZXk/xUvXqq69m5glOr/agdebT6r6LXBUu7i5CzlM8FGUFg6lh5VsyuexT0uJuI2ioBaMBZr9/q6MgFStuRsPNAPM2KIeh4nRcDSr7Pa3+L1dFipu5k6CV3Q0m+329DNQHUNyUjo+B5LCvx/v/TGU5DBKXP+sbfgZw44uiKHFGfA0eaUuKLIdR4kz4GzQO+/jyMiyHQeLyJxUvc0I1cITlMEJcwMv0dANF2sJyGCHOglfBZJBQFR8uQGegUMphcLgQpQFBtlNS0eGAz57h1KtrQnOi14NANKUcxoYLURsAZHt8N/gvLTAcgd5goJXDyHAxDoPA71o5jAtH4DE9VhQ1SAWFo/CYV3s9btRyGBWOwWPa3PCilsMaJhyF1XCSUQ4DwhHyEwzMho+schgQjsRtuMgqh/HgWPyGhzAdBoPjIRhC7iOomP4qPwSDo2GYfHE6jAXHQzHZiHQYCE6BY3bib3R9NgiOcRNBRY7pPcPpYU6HdIh0WMeBU2CZDC5PX9ohCJwGzWTh0mEQOAmekbmXagacBtFkINNhADgVptGx6TAAnAjVJAvLYeZ3KlyjodNhxnc6ZEPyLBnfTRjFTQZ5QjrM9E6HblhCOszwjgJ8gwsLNNwvhDG8I0CCwfI0qSqzOwpkGO0AFr/nVrXRHQ1SjNefXh70NfaFvttgoztPjm7sZMgxGrlXZXJHgxwTg7fBzgPt7WgQIf9AxfN0WGlv5yuFV8VIXPGT5Eq4wM7arnzLWxmtJB3x79anS99ehnmIwy+HXBTM0pi5516Bcxfw/lKwsZWm1Zd5s3pKYGv3t4c+8u3vv4+K0w0lRx1lazpxOQx89DDi29W2d+5vcdpiXv6ZN8lgaRoxft/VdkChy1+Dc39fB/5eCcxaDhQ1hEoeffnnHkc7HN3e4ypfbM6V/4GmK+3gw7zOPIepnL//blYATSvYZVrOTlHloa1I7tHLqaff6ypXTM+Vv8HrU5pq9c8CarJXHp/91myh+SR7pX7Y5+vZ5aqnhtyKYoerOQ7cNfJHJ5iPGxqWbl9N/QXRTI/18+r/FCOoueE+hy4T+jiU5gY1HBXZkhDlDKOqfGYYdqeeHc76Ph/JAgbbv5cM9d84AEIi9gE8uL83CyL0MwwqpO/nOHA36HmI4PNxOCS5+4BBhtBbAzK/MO4ARyLZ2Ju3Hh7Ow0JyqOueCdCqcRSEKMg1v/DIGEE/p4GH4dazkNDzelzuXIcJkUOdDssRLwW5ECj4Iw8KPS/Hcaq3+t0HYYcLQV0GdeAw33koERPSwP0gVycPlMGJfk4DzQTWyoREHRwiuMaF9RrZ58+pYLv7IFnVPG/HMJEW4iOIsRZGoaeBLYkUEkH9Nwy4CSobFodAwVGeI150+ypJB2FgfWQijSAonf9NTh/Vyq2AD+QQ5eps+rUwIFE1QqjrngY29MHxVYQYVkGUtTAa/iIvnblpdx/k0IREs/lictbNwZ+BCxEFG+7V2ZIXfAoX9DQKwefJeMdZFlsCE4UwHV3I4RwscY/R+5XICWGgtb4DVQOPuECB1UzkhKgEQe5fibNsackm9AhURYpDEaK6GnOk59CGih9t1YyVDQTqIsVhI2R/COU7dTxzmxOiE8S7W5DfnlBll6v+6EVbOVR2i8GHZ3BpPYVSEBgx4Twni/fyJq92vVvIvSdXiP8ryM4DSMmf4MBnGDT39/oQ3+psPcR0VVHIu93//P7981A8oBLXvjykKQ9lNc/lK4prjjFwV6pGOkHN2+Awcu9/fv68BnNywMlJ5jU5UvBI5c4jcTWR4vrABroKGI1aEGh19pivTRbIvFNeeWBODjk3yby+E5yD+X6kMxXEs9HORLC4mmeBsTUc514UfpTkTmXXXj5qlX3I2BJYQrC4DMOjNCVvQGmSvBNBWY7OCe1cEzzoGGTG1xrIXWRyP0d6lCUlyzLl80pZGE/CPLeghlHkNH8c+XmZp/2djgNxA7kz2YPVsdVpbyJa63rHEsJbnW25gyakeeOGqYU178Sf8HlJUM4dwYOOtdbe6zhW5K5mcj8guyJq0DyYE1kgJ81SSr4Dxs08E3MRMCsTiIPeyOO4xFi2ywlMoWLAu6/eid6X5w3ml+VD612P7kib79Z6y+dxF5XV78gzP0jFB0nDzxMqfmR/NRpnp6TZyec0H2fIbafcQtkP4SaWOi6qsIX4VmezIY+2em+75w3rypan9gsl78QvNpcKJo+1jjW7q6ji14pePT/PvF0pU+6yJ9Jro6RJpN0O62UTx0pypub4hcSmM4QkE6QzBPu9Ui//M0OfUI0AeNA7hX2stU56Z5L0GFrr6Lym4Tyjik/zZgFF//l5bois16Fzv+I637uit+i9y84E+IlFs7UwDwRanY2AQEVgDsBmvbWkd+3wU+e+Wo8IJy4k/TIr9qwPed7Qgs8rPjni7crmmXirNGd4u0J77NZcsW6Xd0gJRMQfFGO9RaNCkA6o9U7SUx9r6AsqLnsRiXkcgfH52OOdIfxafPtlFW9TRraykws+WClOZKFINjpQr/1MdkIi4P7XSDsVui4V4SeICpioYw1hrc5OoxTLxqG2OBUClw3YZzpWG7MjiE8HTmp3RNBX4kKx0IwpBS0UI1rj+3x1IBgFxWH7783pGoeqAlcIzI8Fs9+lX7jWJCHbWsxjdWf5kDVrPLzqV4rWfJFO7Y3W/N75QpHuWbCF4mYG+8vTxJuWZYEAgeOiGqsg0upsz5dqKTJnLR2q2oJWCMDYGwbszx58R4K7ID2zQBXa5a4yhkBxpVqcGeWdNvHLqdn9YZp5l/yUTdUWqkLg0hsibI9z6yla+OaEdp/JIsM9+uz16/oZu463V+RTdlQBc/mPOwb3VeF3DcLiELMg0Opsy3c1W/bPbwIiZt0YMr+ol+mPIAu3QgCpni2Qxn35Ynuccc/cVRKc2Bodx+/Ayy3enfL6ngDuVOtV46g1b6/Yp95rayr0DHZBiQTbe8jFnUomszFmPTVJNAWZPOV9hgBf+7YXFwGLu+vP5W11NTD8fpb8gXmVh5ks70nToL6/FYd2Td5DdzqcIVg3IU6nJ4qLYq11GUEgGijDwHP8dNO2IDlbabhUOqV1qx760rwepdHwdWAn5PtVUgRaV2czrIXB0IG3l+J9O9sY5Kxl7rPZpGiOoB4SyNag4NdfdxQPxbqMoCSQ/YMaOwh0O80sFU1uvk71nBx1XS8QiFU9p4aStGPHjlS3bV0faNu2TsVAEDhzu3L3VDc1IQkEWZ2diuDdK0aNQiTqdk6+aOt5LRYI5nc7meq2aUGPTCml1UnVPEGraVZnQb+zabVRf5rltX8h3jtO6yqaQHms9lYqYlAqZLs4p97MyRf9vlAzr9201k//5B8Xtd7CWlcHTLAhVCWM1dkWDpQQKCajoymN93OTJEMXF3HWBESBQMBDOXKlbr/t95O4QteG/V8je1zXf1S3KOy9hbEMgWoIVSD36uzCqcqjf+jXKQUAe5zPqB5btp2rmoAz6ELBYOq+YoThJe85c9RGdefdMcRrjVvU1IQsEGB1NmHeF8Nm8miBYMRFjjpc7KqiC8Rj/mryOh2zUaO7KUlrAhUX9oCY7YAMgxRCWUK5XxDslsXavJ9HywIxLkpsIsLAMLPDrRek1H2uedtPKYk4vwCi+IzqnqsnhBe7KiGUgZyrs9MsNcDD5bX9qIMY8OOiwDAxBVWDyDzvS8ScdZDcJMZzZr5jvh76iN/fgrjEvDrbCg6l8DJqtAikxcUdJRCQ8K0IEGcdWmWCLKZJMRjVGSso1VLuX0Fd4l2dXTLfQleNRkd2XAhBF7sKyEthxWF1/Au1asQ3iesRCdI6BvprCCMdWhkCLTMMoh6DhIHl4pIOKSETkrhHNV1B/QRBFFgg9axDNyVZTWI+Z+bUBU3UyoRwB1KuhSkYpWnz6IRJuOJCQ2tdQR8Yaiij65SAKQ6jOhLkZ4cSGCUEM1ALiUq1ykBbmFdvWsUgESIpZeHy6QqWEjtBqda0XfYjIT2G0yQgkjqqJ9YTVupi1ylzE45AntXZXtQtCXl02++m6MAwZ5ZJ61PRaSJBStJBWcWFfn4hvnNm7FOouvFlzDDQIUwllvsFlYxL2ukxHGIQV4S6bBKeQBzmec9ImvL4XHLY73ZTCsJGfM6mITibgLe1ZPAEct4vKD48mtHvN1CnhEB84mC49jDSQxuNrRRguKMTaFDM58zQUiv+YmidD+EK5LhfULnYpR91SMzELo6doARmSrZNIGlDEExXjUZoUhxGdb6zdFZVMZYYVmdbTGApQKI5iWscNxuPL5AL4lAMkOhuFg3cJK5HJLgO2HedxhdIe7+gRxEQRx2YiHlcsnGCxVoKLEjRWTGxN4n6JITvVLTvOn0/IM5A6tXZtHk/ZXtNQEX3x+tET3GIK0+ngWH+CntzUqoQPNNVVxwQUzjisOAeQGMg3UEKVK+FsYgupc7fj0AgyrDigJKiEScZA1m8gajsqNs2M4LYVcmhUsBoEucv8d470MEdOLUMgbYTgwoUrtlKp7wTZ1Pi5zxHTIBG54aK4hH3iqCz2EsIzPOeGk4pjbd5tGAy9xtInucXCorCTngtAffvn+EvUa7OtrgDG6I0zwwK4NEFk9b61FQNOKtX69H8gBfG1aMOMWyC9SBuIVwCUysDL5AP2YXVhmggsI86FEY6CaEEjKn5eBbNgEMZFGPRCaaJ/H5QWCe6P6UJ3OA5Mu38ArvoAhEyUMkv4AZ5whRj0XUqirQ+PZ08kBjuIJClJ0Rh4jfGKmRN1iCqN7tPcNTBKFHdL2gnVNKToyCL1r4nZqHiLca6TVLVgHE9qitQSi8M8E86GM8vFBQFYDB61ZRMfgEzkAtRzHuaWnohIOGkQ1HiNmtjoJSYqb/iWaRnMWguX/4sDvuvCzlHHdTobnHZwGB9NnotNdT9KqUEelw30Uxk5dy5lXPnorFS0O5+9FuleUZR0eBN3phh4IAEoqH/rCq9UkkanyElVvdpCpoDebsdhUXI4r8uon3X4xCckv/9gnLZ/m0aPy5Jgm7+pETpjtIobMxsEtE2TVXDzjzvAwZujMIwjfj44jVZN/Nh+GyNwGGUsY3usGoDJpDsfkHsIXBZw2GYXh4nZRW/u3R7Z2dVLktNii5zzWlXMLMdi7Z47swtAamEwXEqY5e4Qtr0fLf+ovaP0s867hd1lctiw9UloV0UWuWgHWZ1+piiy0Kz6FiuKnJCFrwCqH3tCxGCEriUzXLgf7+gRPJ6k+s1eoQv6iqXxgaljEvjhl33mCOV085U5SWRKTpm1li2NZ9QZ3777chIqLUbQIE4vDuEHuKgDgPpJ7B/T6qces2xsUzlmLXTVGGFeISvJTBtYJVofr9ZPtDJX2/Bf1HHZaCscR7yD+adxqHXOIz4AcVdSzBVVUMGffCC9WzX4FGwL+p4oHcavxF/Dr/jh2Uj2NaSARXosTo7mfr/2Cp5UIdHwog/s9/x7dOVKwGdgFYCoNzfParyP6N3HdRxkT/if2DqM7qsQd4Ih9CEXxO0OwhxIXSpliBUgzoiIRnxlSV/zGmyDYqfiIEFsrH/ShC6QX0whLnXHDwINumsFZ8Nuwya4Dv4awokT0nCOKjfmxAdyRX/4EG3Ef/gQeuIT0+ftKrBJIyD+o4O5SYuI/5BlxFf7TUoD/YmDAmn7EQMPXDM1+5Y4AZ1ZQ9iI+Lym2s/932C+x96ALHkjZBhoAVpUCf6Ai+mMF1X4NlK7GgI3WHVBGLJ935BwoEX0EFdtcDLiKJ4rtOS1WULQZbQCN+grpfTrieMos4S6S+brAMblK8Fn8DqIcjSKBuyM4Ee1PfH9XLwWSYdIxp9INmmrWrwCPugvn//Xhrtj7Qc8OcMNFWrzTAYzy8gyun6AkwKZIV5UCdXEcGUwEydcn2BQjnQAj2oT4aRmUKnaLSBQpMu+g10wFCcYbBtyAnMFQUzOTm54ZTlE2NAKQpVcdKjUBD/Y3wzbDZAA3dsVfk/cFgfiGsKq70xEDjl6Lj/U2BpEwEOWZoDI8F45haf3yZDP095b2lKAewEj6qZsDSREqg7AQi4gZiwEL93TBRoaSIl8MkYY6AZ4MDo1LXlB6pra3SxqwjkAv222lloBxzoZoBLnBB+Cnjm1uy7bmoiJzDDbRow21qawA5EBdDss3AZBuOGnMAENQ/8bAE8cAy0N6vDNLQby88fuoC7pmBpKc8WR0Aw8rMG+hMi8L+3DH+HVVMTOYE5naTAwNT/ZvAD2eDHYP81HOIyDLBTzoLQsCEFLEjHid7m4J3XgnNjrgRmkuihUWqwExPFvT3/AVVLCDMMXgnNEEgNWzmUwMg0RqbRqDWegvuuA+UsGIfHLGAnnGKG2IDe4WI0TMD8QhlZBkTpeMXJAPpMzuY75SxIDa0VRSgsBuD64TIucBrKkiwQHPpkUJboYDEtemBddiEFLYgEB1pv9bDh/80u425glPQWhWB/lp2l92c5u+9qC6t+tut0jigNQ59+ulfbn1NzEqFbW/WMVfscNDPzd3iUXC5beqC9LNvgJT4avkTRxPZhI9L08st2JaEtG/vR6XVIcJ4rE3Mmc9DQZJqGrp6iOaMNjb1jQnWymmjfyyx/VvqWZmr12cTQZbmGrsSkoS0xa8GWnF0wJQsm6/VKWToZ6/btk7uHdna2bWd3j+211w4PL126sOkb+JxduSzGm/phlFVLx8pMi8+WSaVNZ89mXaacnl7yTMTon7O1TtYyXxRn94HNPgsx3YezqrO2OlMe8FG59cyxad0seWYSZBwN7dw2sNlnkU6XnkZFm8fgqvTmXYMRQ2PbuwxncUXAuyYjnkFzNlfefPSR0YhAeB8NmrO68sdi4DlkvTtzYVl71KStrgiwGmjOziX4cPbzZeWIqnZX3jgYcOj3x5eVR2LE8soXJwNNwpjllQdDW6I8OxpgEsZsr/xwN5jcvrj7SB+zvmKVOT4GFHJsqjx9F6yvNHLMB//89BrDJmq1zbPsrxS+BhA1UUuAEvgbeKLyLACUgsIgE5dnMaHKM78fy6ExUE20MQoUjcogcx2NQaB4dAZmQyrP4kCxKA0ISqKWBEWiNRAoiVoQFIvaACAkallQHHrDfv0LP0aDonAYzhcDfgwGxeExrNBjPCgGl2GELc8iQhH4DBtseRYQisFpmJqQiVomVIzXsECWZ0GhQtyGAa48CwoV4zfkUGN4qFIF25yK/apg0BwYKoBhSGHKs8BQnJ07BcR88NVnnx0eEYlaNpQr3IYMIlELh3LcgDcfnK51ttcgTtTCocxAGRrCMT6UCSSTFSkIxwhRZU8FzvhxZRCNAaJyPlWAMscU48XNw6g8ixGlgnbjKj/zwT+fDaLyLEaUBtiTwQiCRC0kSgPsyWhoQXkWJUoD2OiQsXkWJ0oF2ijwt+5AUVDgG/3CB4Kf93fmF/TNs0BRGUDfgjps/B2Bd/7WN89CRR2bxlHW61L4Xi3UwqKAJLyAj6engqgXallR2xk1YVDtoB+j9i/FR0Xms1aohUX9Na194uqvqRrzl2+uMX0CgVeUPiHLO0qf4OqXW+SeMPCev1K47jLBu7Il5wlYf84i4yWJH8c0x/znmP8c858SjQA='


export const LoadingScreen = () => {

    const [hammerRotation, setHammerRotation] = useState('-15')

    const loadingRef = useRef()
    const loadingTextRef = useRef()

    useEffect(() => {
        window.loadingRef = loadingRef
        window.loadingTextRef = loadingTextRef
    }, [])

    useEffect(() => {
        const intt = setInterval(() => {
            if (hammerRotation === '-15') {
                setHammerRotation('-35')
            } else if (hammerRotation === '-35') {
                setHammerRotation('15')
            } else if (hammerRotation === '15') {
                setHammerRotation('-15')
            }
        }, 500)

        return () => clearInterval(intt)
    }, [hammerRotation, setHammerRotation])

    return (
        <div ref={loadingRef} style={{zIndex: 1000000}} className={'select-none pointer-events-none bg1 absolute w-full h-full bg-neutral-800 bg-opacity-30 flex flex-col justify-center items-center'}>


            <div className={'bg-neutral-900 bg-opacity-80 p-4 rounded-md ring-4 ring-orange-400 flex flex-col justify-center items-center'}>


                <div ref={loadingTextRef} className={'my-2 w-64 h-32 text-[64px] gloww text-orange-400 flex flex-col justify-center items-center'}>
                    Gladion

                    <div ref={loadingTextRef} className={'font-mono -mt-4 mb-12 w-64 text-2xl gloww text-yellow-400 flex justify-center items-center'}>
                        [test build]
                    </div>
                </div>


                <div className={`w-44 h-fit transition-all rotate-[${hammerRotation}deg]`}>
                    <img src={window.hammerImageBase64} />
                </div>


                <div ref={loadingTextRef} className={'w-64 h-32 text-4xl gloww text-lime-400 flex justify-center items-center'}>
                    loading..

                </div>
            </div>


        </div>
    )
}
