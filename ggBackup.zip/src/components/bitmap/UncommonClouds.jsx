import {useEffect, useMemo, useRef, useState} from "react";
import { useStore } from "statery";
import { bitmapStore, currentBitmapStore } from "../../modules/stores.mjs"; // Stores
import {Box, useTexture} from "@react-three/drei";
import {getBitmapFromCoordinates, getCoordinates, getUncommon} from "../../modules/utils.mjs";

import * as PropTypes from "prop-types";
import * as THREE from "three";

function InscriptionBox({id, i, bitmap}) {

    const [content, setContent] = useState('')

    const [texId, setTexId] = useState('cfab194b924f7785c6e453728e1c264b89b74843633278cda3ad3f57576c1e93i0')
    const texture = useTexture('https://ordinals.com/content/' + texId)

    useEffect(() => {
        // texture.flipY = false
        texture.encoding = THREE.sRGBEncoding;
        texture.minFilter = THREE.NearestFilter;
        texture.magFilter = THREE.NearestFilter;
        texture.needsUpdate = true;


    }, [texture])

    useEffect(() => {
        const getContent = async () => {


            if (id) {

                const info = await fetch('https://ordinals.com/r/inscription/' + id).then(r => r.json())



                // console.log(info)

                if (info.content_type === 'image/png' || info.content_type === 'image/jpg' || info.content_type === 'image/jpeg' || info.content_type === 'image/avif' || info.content_type === 'image/webp') {
                    setTexId(id)
                } else {

                    // const content = await fetch('https://ordinals.com/content/' + id).then(r => r.text())
                    // setContent(content)
                }
            }

        }

        getContent()
    }, [id, setTexId, setContent])

    return (
        <group position={[40 - (i * 10), 100, 40]}>
            <mesh renderOrder={1} visible={texId !== 'cfab194b924f7785c6e453728e1c264b89b74843633278cda3ad3f57576c1e93i0'} onClick={() => {
                sendChat('uncommon sat #' + getUncommon(bitmap) + ' (block ' + bitmap + ')')
            }} scale={[100 +  + (i*0.0001), 25 + (i*0.0001), 100 +  + (i*0.0001)]}>
                <boxGeometry />
                <meshStandardMaterial map={texture} />
            </mesh>
        </group>
        // <group position={[80 - (i * 10), 0, 80]}>
        //     <mesh onClick={() => {
        //         sendChat(content.slice(0, 100), bitmap + '.bitmap ~ #' + i)
        //     }} scale={[5.1, 6, 2.1]}>
        //         <boxGeometry />
        //         <meshStandardMaterial map={texture} />
        //     </mesh>
        // </group>
    )
}

InscriptionBox.propTypes = {id: PropTypes.any};

function BitmapBuildData({ id, color, coords }) {

    const bitmap = useMemo(() => getBitmapFromCoordinates(coords.x, coords.y), [coords])

    const [textureId, setTextureId] = useState('a4676e57277b70171d69dc6ad2781485b491fe0ff5870f6f6b01999e7180b29ei0')

    const texture = useTexture('https://ordinals.com/content/' + textureId)

    const [childrenIds, setChildrenIds] = useState([])

    useEffect(() => {
        if (childrenIds.length > 0) {
            // console.log('getchildrendatafor bitmap ' + bitmap)
        }
    }, [childrenIds])

    useEffect(() => {


        const getChildren = async () => {

            if (coords.x < 0 || coords.y < 0) {
                return
            }

            // let sat, satIndex
            //
            // try {
            //     sat = await getBitmapSat(bitmap)
            //     // console.log(sat)
            //     satIndex = await getBitmapSatIndex(bitmap)
            // } catch (e) {
            // }
            //
            // if (sat) {
            //     const data = await fetch('https://ordinals.com/r/sat/' + sat + '/at/' + satIndex ).then(r => r.json())
            //     const bitmapInscriptionId = data.id
            //
            //     const c = await fetch('https://ordinals.com/r/children/' + bitmapInscriptionId ).then(r => r.json())

            const bitmap = getBitmapFromCoordinates(coords.x, coords.y)

            // sendChat(bitmap)

            // console.log(bitmap)





            if (bitmap > 0) {

                const data = await fetch('https://ordinals.com/r/sat/' + getUncommon(bitmap) + '/at/0' ).then(r => r.json())

                // console.log(data)

                setChildrenIds([data.id])
            }

        }

        getChildren()


    }, [setChildrenIds, bitmap]);

    return (
        <group visible={childrenIds.length>0} key={id} position={[coords.x * 100 + 10, 6, coords.y * 100 + 10]}>
            {
                childrenIds.map((cId, i) => {

                    return (
                        <InscriptionBox id={cId} i={i} bitmap={bitmap} />
                    )
                })
            }
        </group>
    );
}

export const UncommonClouds = () => {
    const ref = useRef();
    const { bitmaps } = useStore(bitmapStore);
    const { currentBitmap } = useStore(currentBitmapStore);

    const renderDistance = 4; // Distance for visible tiles
    const loadedBitmaps = useRef(new Set()); // Tracks already loaded tiles

    useEffect(() => {

        const updateNearbyBitmaps = (currentBitmap) => {
            // if (!currentBitmap >= 0) return;

            const currentCoords = getCoordinates(currentBitmap);
            const nearbyBitmaps = {};

            // Generate bitmaps within render distance
            for (let dx = -renderDistance; dx <= renderDistance; dx++) {
                for (let dy = -renderDistance; dy <= renderDistance; dy++) {
                    const x = currentCoords.x + dx;
                    const y = currentCoords.y + dy;
                    const bitmapId = `${x}_${y}`; // Example ID

                    if (!loadedBitmaps.current.has(bitmapId)) {
                        loadedBitmaps.current.add(bitmapId); // Mark as loaded
                        nearbyBitmaps[bitmapId] = {
                            id: bitmapId,
                            color: `#${Math.floor(Math.random() * 16777215).toString(16)}`, // Random color
                            coords: { x, y },
                        };
                    }
                }
            }

            // Update store with new bitmaps
            bitmapStore.set((prev) => ({
                bitmaps: { ...prev.bitmaps, ...nearbyBitmaps },
            }));

            // Remove old bitmaps out of view
            Object.keys(bitmaps).forEach((id) => {
                const coords = bitmaps[id].coords;
                const distX = Math.abs(coords.x - currentCoords.x);
                const distY = Math.abs(coords.y - currentCoords.y);

                if (distX > renderDistance || distY > renderDistance) {
                    bitmapStore.set((prev) => {
                        const updated = { ...prev.bitmaps };
                        delete updated[id];
                        return { bitmaps: updated };
                    });

                    loadedBitmaps.current.delete(id); // Unload old bitmaps
                }
            });
        };

        // Track player movement and update bitmaps
        const interval = setInterval(() => {
            updateNearbyBitmaps(currentBitmap);
        }, 500); // Check every 500ms

        return () => clearInterval(interval);
    }, [bitmaps, currentBitmap]);

    return (
        <group ref={ref}>
            {Object.values(bitmaps).map((props) => (
                <BitmapBuildData key={props.id} {...props} />
            ))}
        </group>
    );
};
