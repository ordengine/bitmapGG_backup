// ordinals.com recursive proxy

import {
    getMondrian
} from 'https://ordinals.com/content/55551557695dd82a2bda5ec3497684ec7cbb2cc1752ff5101accff1648666c3ai0'

import {deflate} from 'https://ordinals.com/content/fba6f95fb1152db43304a27dce8cb8c65509eba6ab0b6958cedeb33e5f443077i0';


const MAX_NUM = 1000000;
let isPrimeArray = Array(MAX_NUM + 1).fill(true);
isPrimeArray[0] = isPrimeArray[1] = false;
for (let i = 2; i * i <= MAX_NUM; i++) {
    if (isPrimeArray[i]) {
        for (let j = i * i; j <= MAX_NUM; j += i) {
            isPrimeArray[j] = false;
        }
    }
}
const isPrime = (n) => {
    return isPrimeArray[n];
}


const isPalindrome = (str) => {
    return str == str.toString().split('').reverse().join('');
}

const isRare = (num) => {
    return num % 2016 === 0
}

export function isFibonacci(num) {

    return [
        0,
        1,
        1,
        2,
        3,
        5,
        8,
        13,
        21,
        34,
        55,
        89,
        144,
        233,
        377,
        610,
        987,
        1597,
        2584,
        4181,
        6765,
        10946,
        17711,
        28657,
        46368,
        75025,
        121393,
        196418,
        317811,
        514229,
        832040,
        1346269,
        2178309,
        3524578,
        5702887,
        9227465,
    ].includes(num)

}


function serializeMondrian(mondrian) {
    // Map long key names to shorter ones
    const keyMap = {
        height: 'h',
        length: 'l',
        rowOffset: 'ro',
        width: 'w',
        slots: 's',
        position: 'p',
        size: 'z',
        x: 'x',
        y: 'y'
    };

    return JSON.stringify(mondrian, (key, value) => {
        if (key === 'slots') {
            // Compress slots into arrays of [x, y, size]
            return value.map(slot => [slot.position.x, slot.position.y, slot.size]);
        }
        return keyMap[key] || value;
    });
}



self.addEventListener('fetch', function (event) {
    const url = new URL(event.request.url);

    if (url.origin === location.origin && (
        url.pathname.startsWith('/content/')
        || url.pathname.startsWith('/r/')
        || url.pathname.startsWith('/blockheight')
        || url.pathname.startsWith('/blockhash/')
        || url.pathname.startsWith('/blocktime')
    )) {
        const newUrl = 'https://ordinals.com' + url.pathname;

        const modifiedRequest = new Request(newUrl, {
            method: event.request.method,
            headers: event.request.headers,
            mode: 'cors',
            credentials: event.request.credentials,
            redirect: 'follow',
            referrer: event.request.referrer,
            body: event.request.body,
        });

        event.respondWith(fetch(modifiedRequest));
    }
});

self.addEventListener('message', (event) => {
    console.log('Service Worker received message:', event.data);

    if (event.data.action === 'testMessage') {
        const gen = async () => {

            try {
                console.log('Test message received in Service Worker.');

                console.log('generateTexure is action!')
                const width = 1000
                const height = 1000

                // Perform heavy texture generation computation
                const canvas = new OffscreenCanvas(width, height);
                const ctx = canvas.getContext('2d');
                const imageData = ctx.createImageData(width, height);
                const data = imageData.data;

                const bitmapData = {}

                for (let y = 0; y < height; y++) {
                    for (let x = 0; x < width; x++) {
                        const index = (y * width + x) * 4;
                        const bitmapNumber = y * 1000 + x;


                        // Simulate texture generation logic (simplified for demonstration)
                        let r = (bitmapNumber % 55) / 255;
                        let g = (bitmapNumber % 88) / 255;
                        let b = (bitmapNumber % 50) / 255;

                        if (true) {

                            const prime = isPrime(bitmapNumber);

                            let isPrimeTouching = false
                            let isPrimeTouching2 = false
                            if (!prime) {
                                [
                                    [1, 0], [0, 1], [1, 1], [-1, -1], [0, -1], [-1, 0], [-1, 1], [1, -1]
                                ].forEach(dir => {
                                    const num = ((y + dir[0]) * 1000) + (x + dir[1])
                                    const prime = isPrime(num)
                                    if (prime) {
                                        isPrimeTouching = true
                                    }
                                })
                            }

                            if (!prime && !isPrimeTouching) {
                                [
                                    [2, 0], [2, 1], [2, -1], [2, 2], [2, -2],
                                    [-2, 0], [-2, 1], [-2, -1], [-2, 2], [-2, -2],
                                    [0, 2], [0, -2], [1, 2], [1, -2], [-1, 2], [-1, -2],

                                ].forEach(dir => {
                                    const num = ((y + dir[0]) * 1000) + (x + dir[1])
                                    const prime = isPrime(num)
                                    if (prime) {
                                        isPrimeTouching2 = true
                                    }
                                })
                            }

                            const ran = 0.9 * -Math.sin(Math.sin(bitmapNumber) % (Math.cos(x - y) * 11.369) * 420.710999) * 0.02

                            if (isRare(bitmapNumber)) {
                                r = 255 / 255
                                g = 25 / 255
                                b = 15 / 255

                                if (!bitmapData[bitmapNumber]) {
                                    bitmapData[bitmapNumber] = {}
                                }
                                bitmapData[bitmapNumber].rare = true
                            } else if (isPalindrome(bitmapNumber)) {
                                r = 0.65
                                g = 0.05
                                b = 0.5
                                if (!bitmapData[bitmapNumber]) {
                                    bitmapData[bitmapNumber] = {}
                                }
                                bitmapData[bitmapNumber].palindrome = true
                            } else if (prime) {
                                r = 0.01
                                g = 0.4 + ran
                                b = 0.0
                                if (!bitmapData[bitmapNumber]) {
                                    bitmapData[bitmapNumber] = {}
                                }
                                bitmapData[bitmapNumber].prime = true
                            } else if (isPrimeTouching) {
                                r = 0.06
                                g = 0.55 + ran
                                b = 0.0
                                if (!bitmapData[bitmapNumber]) {
                                    bitmapData[bitmapNumber] = {}
                                }
                                bitmapData[bitmapNumber].primeTouching = true
                            } else if (isPrimeTouching2) {
                                r = 0.06
                                g = 0.55 + ran
                                b = 0.0
                                if (!bitmapData[bitmapNumber]) {
                                    bitmapData[bitmapNumber] = {}
                                }
                                bitmapData[bitmapNumber].primeTouching2 = true

                            } else {
                                // color.set(0.0, 0.5 + ran, 1.0)
                                r = 0.0
                                g = 0.5 + ran
                                b = 1.0
                                if (!bitmapData[bitmapNumber]) {
                                    bitmapData[bitmapNumber] = {}
                                }
                                bitmapData[bitmapNumber].water = true
                            }

                            if (isFibonacci(bitmapNumber)) {
                                // color.set(1, 0.5, 0)
                                r = 1
                                g = 0.5
                                b = 0.0
                                if (!bitmapData[bitmapNumber]) {
                                    bitmapData[bitmapNumber] = {}
                                }
                                bitmapData[bitmapNumber].fibonacci = true
                            }

                            if (bitmapNumber === 0) {
                                // color.set(0.9, 0.9, 0.9)
                                r = 0.9
                                g = 0.9
                                b = 0.9
                                // if (!bitmapData[bitmapNumber]) {
                                //     bitmapData[bitmapNumber] = {}
                                // }
                                // bitmapData[bitmapNumber].bitoshi = true
                            }

                            // if (isRare(bitmap)) {
                            //     h = 2
                            // }  else if (isPalindrome(bitmap)) {
                            //     h = 1;
                            // } else if (prime) {
                            //     h += 3;
                            // } else if (bitmapData[bitmap].bitmon?.parcelCount === 1) {
                            //     if (prime || isPrimeTouching || isPrimeTouching2) {
                            //         h = 3
                            //     } else {
                            //         h = 0
                            //     }
                            //
                            // } else if (bitmapData[bitmap].bitmon?.parcelCount > 1) {
                            //     h = 2
                            // } else if (isPrimeTouching || isPrimeTouching2) {
                            //     h = 3.5;
                            // } else {
                            //     h = 0;
                            // }

                            g -= 0.1
                            if (true) {

                                let mondrian = getMondrian(bitmapNumber)
                                delete mondrian.rows

                                if (mondrian?.slots?.length === 1) {
                                    if (!bitmapData[bitmapNumber]) {
                                        bitmapData[bitmapNumber] = {}
                                    }
                                    bitmapData[bitmapNumber].bitmon = {
                                        m: {slots: [1]}
                                    }
                                    g += 0.2
                                } else if (mondrian?.slots?.length === 2) {
                                    r += 0.99 + ran
                                    g += 0.15 + ran
                                    b += 0.0 + ran

                                    if (!bitmapData[bitmapNumber]) {
                                        bitmapData[bitmapNumber] = {}
                                    }
                                    bitmapData[bitmapNumber].bitmon = {
                                        // parcelCount: mondrian?.slots?.length,
                                        m: mondrian
                                    }


                                } else if (mondrian?.slots?.length === 3) {
                                    r += 0.88 + ran
                                    g += 0.2 + ran
                                    b += 0.0 + ran

                                    if (!bitmapData[bitmapNumber]) {
                                        bitmapData[bitmapNumber] = {}
                                    }
                                    bitmapData[bitmapNumber].bitmon = {
                                        // parcelCount: mondrian?.slots?.length,
                                        m: mondrian
                                    }


                                } else if (mondrian?.slots?.length > 3) {
                                    g += 0.15 + ran


                                    b = 0.03 * mondrian?.slots?.length

                                    // g -= 0.1 + (mondrian?.slots?.length * 0.0)
                                    // b +=  0.0 + (mondrian?.slots?.length * 0.05)
                                    // r +=  0.0 + (mondrian?.slots?.length * 0.03)
                                    // b += mondrian?.slots?.length * 0.02
                                    // g += mondrian?.slots?.length * 0.01

                                    if (!bitmapData[bitmapNumber]) {
                                        bitmapData[bitmapNumber] = {}
                                    }
                                    bitmapData[bitmapNumber].bitmon = {
                                        // parcelCount: mondrian?.slots?.length,
                                        m: mondrian
                                    }


                                }
                            }

                            //
                            if (bitmapNumber > 210000) {
                                // r += 0.03
                                r -= 0.03
                                // b += 0.02
                                // bitmapData[bitmapNumber].epoch = 2
                            }

                            if (bitmapNumber > 420000) {
                                // r += 0.03
                                r -= 0.03
                                // b += 0.02
                                // bitmapData[bitmapNumber].epoch = 3
                            }

                            if (bitmapNumber > 630000) {
                                // r += 0.03
                                r -= 0.03
                                // b += 0.02
                                // bitmapData[bitmapNumber].epoch = 4
                            }

                            if (bitmapNumber > 840000) {
                                // r += 0.03
                                r -= 0.03
                                // b += 0.02
                                // bitmapData[bitmapNumber].epoch = 5
                            }

                            if (bitmapNumber > 869300) {
                                r = 0.5 + ran
                                g = 0.2 + ran
                                b = 0.02
                                if (prime) {
                                    g = 0.4
                                    b = 0.0
                                }
                            }

                            if (bitmapNumber < 10) {
                                r = 0.8 + ran
                                g = 0.36 + ran
                                b = 0.0 + ran
                            }
                        }

                        data[index] = r * 255;
                        data[index + 1] = g * 255;
                        data[index + 2] = b * 255;
                        data[index + 3] = 255;
                    }
                }

                ctx.putImageData(imageData, 0, 0);

                // Convert canvas to Blob
                const blob = await canvas.convertToBlob();

                const compressedData = deflate(JSON.stringify(bitmapData));


                // Send the Blob back to the main thread
                event.source.postMessage({
                    action: 'testResponse',
                    blob,
                    bitmapData: compressedData,
                    compressedSize: compressedData.length,
                    size: JSON.stringify(bitmapData).length
                });

            } catch (error) {
                console.error('Error in Service Worker:', error);
                // Send error message back to main thread
                event.source.postMessage({
                    action: 'textureError',
                    message: error.message,
                });
            }


        }

        gen()


        //
        //
        // Respond back to the client that sent the message
        event.source.postMessage({
            action: 'testResponse',
            message: 'Hello from Service Worker!',
        });
    }
});
//
// self.addEventListener('message', async (event) => {
//     console.log('got message ' + JSON.stringify(event.data))
//     if (event.data.action === 'generateTexture') {
//
//         console.log('generateTexure is action!')
//         const { width, height } = event.data;
//
//         // Perform heavy texture generation computation
//         const canvas = new OffscreenCanvas(width, height);
//         const ctx = canvas.getContext('2d');
//         const imageData = ctx.createImageData(width, height);
//         const data = imageData.data;
//
//         for (let y = 0; y < height; y++) {
//             for (let x = 0; x < width; x++) {
//                 const index = (y * width + x) * 4;
//                 const bitmapNumber = y * 1000 + x;
//
//                 // Simulate texture generation logic (simplified for demonstration)
//                 const r = (bitmapNumber % 255) / 255;
//                 const g = (bitmapNumber % 100) / 255;
//                 const b = (bitmapNumber % 50) / 255;
//
//                 data[index] = r * 255;
//                 data[index + 1] = g * 255;
//                 data[index + 2] = b * 255;
//                 data[index + 3] = 255; // Full opacity
//             }
//         }
//
//         ctx.putImageData(imageData, 0, 0);
//
//         // Convert canvas to Blob URL for texture
//         const blob = await canvas.convertToBlob();
//         const textureUrl = URL.createObjectURL(blob);
//
//         // Post the result back to the main thread
//         self.postMessage({ action: 'textureGenerated', textureUrl });
//     }
// });
