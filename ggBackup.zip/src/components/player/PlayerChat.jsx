import {Billboard, Text} from "@react-three/drei";
import React, {useEffect} from "react";
import {useStore} from "statery";
import {latestChatStore} from "../../modules/stores.mjs";

export const PlayerChat = () => {

    const {latestChat} = useStore(latestChatStore)

    useEffect(() => {
        // console.log('atest chat: ' + latestChat)
        if (latestChat && window.connections) {
            Object.values(window.connections).forEach((conn) => {
                // console.log('sending to ')
                // console.log(conn.peer)
                // console.log([x, elev, y])

                conn.send(JSON.stringify({
                    type: 'chat',
                    message: latestChat
                }));
            });
        }
    }, [latestChat])

    return (
        <Billboard>
            <Text outlineOpacity={1} renderOrder={6} outlineColor={'#111'} color={'#ff9900'} outlineWidth={0.1} font={'https://ordinals.com/content/74eed71c46430c38e056ef1bc69ad2c521293a8941d2177b52e7d447b42d5522i0'} fontSize={0.6} position={[0, 2.5, 0]}>
                {latestChat}
            </Text>
        </Billboard>
    )
}
