import { useEffect, useRef } from "react";
import Peer from "peerjs";
import { peerStore, myNameStore, componentBuildStore } from "../../modules/stores.mjs";
import { AllPeers } from "./peers/AllPeers.jsx";

window.connections = {};
window.peerTargets = {};
window.peerChats = {};
window.peer = null;
window.myPeerId = "";

export const Peers = () => {
    const attemptIndex = useRef(0);
    const isClosing = useRef(false);

    const onOpen = (connection) => {
        window.connections[connection.peer] = connection;

        peerStore.set((prev) => ({
            peers: {
                ...prev.peers,
                [connection.peer]: { position: [0, 0, 0], rotation: [0, 0, 0] },
            },
        }));

        const myPeersInitialMessage = JSON.stringify({
            type: "initialPeers",
            peerIds: Object.keys(window.connections),
            components: componentBuildStore.state.componentBuilds,
        });
        connection.send(myPeersInitialMessage);
    };

    const onPeerData = (conn, data) => {
        const message = JSON.parse(data);
        if (message.type === "update") {
            window.peerTargets[conn.peer] = {
                position: message.position,
                rotation: message.rotation,
            };
        } else if (message.type === "chat") {
            window.peerChats[conn.peer] = message.message;
        } else if (message.type === "initialPeers") {
            message.peerIds.reverse().slice(0, 5).forEach((peerId) => {
                if (!window.connections[peerId] && peerId !== conn.peer && peerId !== window.myPeerId) {
                    connectToPeer(peerId);
                }
            });

            if (message.components) {
                updateComponentBuilds(message.components)
            }

        } else if (message.type === "buildUpdate") {
            console.log("got buildUpdate:");
            console.log(message);

            const components = message.components.map((component) => ({
                ...component,
                selected: false, // Ensure selected is set to false
            }));

            updateComponentBuilds(components);

            setTimeout(() => {
                console.log(componentBuildStore.state);
            }, 100);
        }
    };

    const connectToPeer = (peerIdToConnect) => {
        if (peerIdToConnect === window.myPeerId || window.connections[peerIdToConnect]) {
            return;
        }

        console.log('try' + peerIdToConnect)

        const connection = peer.connect(peerIdToConnect);

        connection.on("open", () => onOpen(connection));
        connection.on("data", (data) => onPeerData(connection, data));
        connection.on("error", (err) => connection.close());
        connection.on("close", () => {
            delete window.connections[connection.peer];
            peerStore.set((prev) => {
                const { [connection.peer]: _, ...rest } = prev.peers;
                return { peers: rest };
            });
        });
    };

    const createNewPeerId = (id) => {
        const peer = new Peer(id);
        window.peer = peer;

        peer.on("open", (peerId) => {
            window.myPeerId = peerId;
            myNameStore.set({ myName: peerId });

            for (let i = 0; i < 10; i++) {
                const id = "0_bitmap_" + i;
                if (id !== window.myPeerId && !window.connections[id]) {
                    connectToPeer(id);
                }
            }
        });

        peer.on("error", (err) => {
            if (err.message.includes("taken")) {
                if (attemptIndex.current < 20) {
                    attemptIndex.current++;
                    createNewPeerId("0_bitmap_" + attemptIndex.current);
                } else {
                    createNewPeerId("0_bitmap_" + Math.floor(Math.random() * 1000));
                }
            }
        });

        peer.on("connection", (connection) => {
            connection.on("open", () => onOpen(connection));
            connection.on("data", (data) => onPeerData(connection, data));
            connection.on("close", () => {
                delete window.connections[connection.peer];
                peerStore.set((prev) => {
                    const { [connection.peer]: _, ...rest } = prev.peers;
                    return { peers: rest };
                });
            });
        });
    };

    useEffect(() => {
        createNewPeerId("0_bitmap_" + attemptIndex.current);

        const cleanup = () => {
            if (isClosing.current && window.peer) {
                window.peer.destroy();
                window.connections = {};
                peerStore.set({ peers: {} });
            }
        };

        const handleBeforeUnload = (event) => {
            isClosing.current = true; // Indicate that the user is attempting to close the tab
            event.preventDefault();
            event.returnValue = ""; // Trigger the confirmation dialog
        };

        const handleUnload = () => {
            isClosing.current = true;
            cleanup();
        };

        window.addEventListener("beforeunload", handleBeforeUnload);
        window.addEventListener("unload", handleUnload);

        return () => {
            cleanup();
            window.removeEventListener("beforeunload", handleBeforeUnload);
            window.removeEventListener("unload", handleUnload);
        };
    }, []);

    return <AllPeers />;
};
