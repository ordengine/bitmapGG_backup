import React, { useState, useEffect, useRef, useCallback } from 'react';
import {makeStore, useStore} from 'statery';
import {BottomButtons} from "./BottomButtons.jsx";
import {latestChatStore} from "../../modules/stores.mjs"; // Adjust the import based on your actual store library

// Assuming makeStore is imported or defined elsewhere
// import { makeStore } from 'your-store-library';

// Initialize the chat message store
window.chatMessageStore = makeStore({
    chats: [
        // {
        //     name: 'system',
        //     nameClass: 'text-yellow-500',
        //     text: 'welcome to the Gladion testcenter!',
        //     textClass:
        //         'text-orange-400 gloww bg-neutral-800 rounded-md px-2 bg-opacity-60 ring-2 ring-orange-500',
        // },
    ],
});

export const Chat = () => {
    const [open, setOpen] = useState(false);
    const { chats } = useStore(chatMessageStore);

    const [inputActive, setInputActive] = useState(false);

    const scrollDiv = useRef();
    const inputRef = useRef();
    const spacerRef = useRef();
    const bgRef = useRef();

    const sendSystemChat = useCallback(
        (text) => {
            const arr = Array.from(chats);

            arr.push({
                name: 'system',
                nameClass: 'text-yellow-500',
                text,
                textClass: 'text-neutral-100',
            });

            chatMessageStore.set({ chats: arr });
        },
        [chats]
    );

    useEffect(() => {
        setTimeout(() => {
            // sendSystemChat('say /help for a list of commands');
        }, 500);
    }, []);

    const sendChat = useCallback(
        (text, name, clearInput) => {
            // console.log('CHAT: ' + text);

            if (name === 'you') {
                latestChatStore.set({latestChat: inputRef.current.value.replace('> ', '')})
                setTimeout(() => {
                    latestChatStore.set({latestChat: ''})
                }, 3000)



            }

            if (clearInput) {
                inputRef.current.value = '> ';
            }


            const arr = Array.from(chats);

            text = text.replace('> ', '');

            arr.push({
                name: name || 'you',
                nameClass: 'text-cyan-400',
                text,
                textClass: 'text-orange-300',
            });

            setTimeout(() => {
                chatMessageStore.set({ chats: arr });
            }, 100 * Math.random());


            if (text.includes('/peer ')) {
                const id = text.split('/peer ')?.[1]

                console.log('connect to ' + id)
                sendSystemChat('connecting to peer id: ' + id)


                window.connectToPeer(id)

            }

        },
        [chats]
    );

    useEffect(() => {
        window.sendChat = sendChat;
    }, [sendChat]);

    const onKeyDown = useCallback(
        (e) => {
            const key = e.key.toLowerCase();

            if (key === 'capslock') {
                e.stopPropagation();
                e.preventDefault();
                // console.log('caps');
            }

            if (key === 'enter') {
                return
                if (open) {
                    if (inputRef.current.value !== '> ' && inputRef.current.value !== '') {
                        sendChat(inputRef.current.value, 'you', true);
                    } else {
                        setOpen(false);
                        inputRef.current.value = '';
                        inputRef.current.blur();
                        spacerRef.current.style.height = '0px';

                        setTimeout(() => {
                            scrollDiv.current.scrollTop = scrollDiv.current.scrollHeight;
                        }, 200);

                        setInputActive(false);
                    }
                } else {
                    if (inputRef.current.value !== '> ' && inputRef.current.value !== '') {
                        sendChat(inputRef.current.value, 'you');
                    } else {
                        setOpen(false);
                        inputRef.current.value = '';
                        inputRef.current.blur();
                        spacerRef.current.style.height = '0px';

                        setTimeout(() => {
                            scrollDiv.current.scrollTop = scrollDiv.current.scrollHeight;
                        }, 200);
                    }

                    setOpen(true);
                    inputRef.current.value = '> ';

                    inputRef.current.focus();

                    setTimeout(() => {
                        scrollDiv.current.scrollTop = scrollDiv.current.scrollHeight;
                    }, 200);
                }
            }
        },
        [open, sendChat]
    );

    const onKeyUp = useCallback((e) => {
        // Handle key up events if necessary
    }, []);

    useEffect(() => {
        window.addEventListener('keydown', onKeyDown);
        window.addEventListener('keyup', onKeyUp);
        return () => {
            window.removeEventListener('keydown', onKeyDown);
            window.removeEventListener('keyup', onKeyUp);
        };
    }, [onKeyDown, onKeyUp]);

    useEffect(() => {
        scrollDiv.current.scrollTop = scrollDiv.current.scrollHeight;

        const handleFocus = (e) => {
            // console.log('focused');
            if (window.fullscreen) {
                spacerRef.current.style.height = '40px';
            }

            setInputActive(true);

            if (inputRef.current.value === '>') {
                inputRef.current.value = '';
            }

            if (!inputRef.current.value.startsWith('> ')) {
                inputRef.current.value = '> ' + inputRef.current.value;
            }
        };

        const handleInput = (e) => {
            if (inputRef.current.value === '>') {
                inputRef.current.value = '';
            }

            if (!inputRef.current.value.startsWith('> ')) {
                inputRef.current.value = '> ' + inputRef.current.value;
            }
        };

        inputRef?.current.addEventListener('focus', handleFocus);
        inputRef?.current.addEventListener('input', handleInput);

        return () => {
            inputRef?.current?.removeEventListener('focus', handleFocus);
            inputRef?.current?.removeEventListener('input', handleInput);
        };
    }, []);

    const onClick = useCallback(() => {
        if (open) {
            setOpen(false);
            setInputActive(false);

            if (inputRef.current.value === '> ' || inputRef.current.value === '>') {
                inputRef.current.value = '';
            }

            setTimeout(() => {
                scrollDiv.current.scrollTop = scrollDiv.current.scrollHeight;
            }, 200);
        } else {
            setOpen(true);

            if (inputRef.current.value.length < 3) {
                inputRef.current.value = '> ';
            }

            setTimeout(() => {
                scrollDiv.current.scrollTop = scrollDiv.current.scrollHeight;
            }, 200);
        }
    }, [open]);

    return (
        <div className={''}>
            {inputActive ? (
                <div
                    onPointerDown={() => {
                        setInputActive(false);
                        setOpen(false);

                        if (inputRef.current.value === '> ' || inputRef.current.value === '>') {
                            inputRef.current.value = '';
                        }

                        inputRef.current.blur();
                        spacerRef.current.style.height = '0px';

                        setTimeout(() => {
                            scrollDiv.current.scrollTop = scrollDiv.current.scrollHeight;
                        }, 200);
                    }}
                    style={{ zIndex: 9 }}
                    ref={bgRef}
                    className="w-full h-full absolute bottom-0 left-0 bg-neutral-900 bg-opacity-0"
                ></div>
            ) : null}

            <div
                style={{ zIndex: 9 }}
                className={`pointer-events-none h-full -ml-3 sm:w-full w-full ${
                    open || inputActive ? 'w-full' : ''
                } absolute bottom-0 left-0 px-1 pb-0 flex flex-col justify-end`}
            >

                <div
                    style={{ zIndex: 91 }}
                    onClick={onClick}
                    ref={scrollDiv}
                    className={`${
                        open || inputActive
                            ? 'pointer-events-auto w-2/3 h-2/3 bg-opacity-80 text-md overflow-y-scroll'
                            : 'gloww h-24 pointer-events-none bg-opacity-0 overflow-hidden'
                    } leading-4 scroll-smooth p-1 ring-orange-500 bg-neutral-800 transition-all border-orange-600 flex flex-col justify-end items-start pb-2`}
                >
                    {chats.map((chat, index) => (
                        <button key={index} className="hover:bg-neutral-700 bg-opacity-50 pointer-events-auto w-fit text-start text-orange-400 px-2.5">
                            <span className={`${chat.nameClass}`}>{chat.name}: </span>
                            <span className={`${chat.textClass} gloww`}>{chat.text}</span>
                        </button>
                    ))}
                </div>

                <div
                    onClick={onClick}
                    className="pointer-events-auto h-10 flex  rounded-sm"
                >
                    <input
                        style={{ zIndex: 92 }}
                        onClick={(e) => {
                            e.stopPropagation();
                            e.preventDefault();
                        }}
                        ref={inputRef}
                        placeholder="> 💬 [chat]"
                        className={` select-none focus:outline-none focus:ring-0 w-full bg-neutral-800 ${
                            open || inputActive ? 'bg-opacity-90' : 'bg-opacity-20'
                        } text-orange-200 text-2xl px-2`}
                    />
                    <button
                        style={{ zIndex: 92 }}
                        onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            if (inputRef.current.value !== '> ') {
                                sendChat(inputRef.current.value, 'you');
                            } else {
                                inputRef.current.value = '';
                            }

                            setInputActive(false);
                            setOpen(false);
                        }}
                        className={`h-9 pt-1 gloww px-2 bg-neutral-900 hover:ring-2 ring-orange-400 active:text-orange-400 ${
                            open || inputActive ? 'bg-opacity-100' : 'bg-opacity-40'
                        } text-xl rounded-sm text-orange-300 hover:text-orange-200`}
                    >
                        send
                    </button>
                    <BottomButtons />
                </div>
                <div ref={spacerRef} className="transition-all"></div>
            </div>
        </div>
    );
};
