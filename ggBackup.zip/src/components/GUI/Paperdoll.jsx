import {DragContainer} from "./DragContainer.jsx";
import {Canvas} from "@react-three/fiber";

import {EnvironmentLighting} from "../core/EnvironmentLighting.jsx";
import {useEffect, useRef, useState} from "react";
import {CameraControls} from "@react-three/drei";
import {Effects} from "../core/Effects.jsx";
import {CustomPlayer} from "../player/CustomPlayer.jsx";


import {useStore} from "statery";
import {myNameStore, myTextureStore} from "../../modules/stores.mjs";
import {Player} from "../player/Player.jsx";
import InscribedSpaceAvatar from "../player/avatars/InscribedSpaceAvatar.jsx";

export const CustomAvatarPaperdoll = () => {

    const {myTexture} = useStore(myTextureStore)

    const [show, setShow] = useState(true)

    useEffect(() => {
        setShow(false)

        setTimeout(() => {
            setShow(true)
        }, 1000)
    }, [myTexture, setShow])

    return !show ? null : (

        <InscribedSpaceAvatar player={true} texture={myTexture}/>

    )

}


const PaperdollCamera = () => {
    const ref = useRef()


    useEffect(() => {
        ref.current.mouseButtons.left = 0
        ref.current.mouseButtons.right = 1
        ref.current.moveTo(0, 1, 0, true)
        ref.current.rotateTo(-0.5, 1.5, true)
        ref.current.dollyTo(15, true)
    })

    return (
        <CameraControls makeDefault ref={ref}/>
    )
}


export const Paperdoll = () => {

    const [showScene, setShowScene] = useState(false)

    useEffect(() => {
        window.setShowPaperdoll = setShowScene
    }, [setShowScene])


    return (
        <DragContainer id={'Paperdoll'}>
            <div
                className={'pointer-events-none w-[311px] h-full flex flex-col items-center p-0 pb-0 rounded-md bg-neutral-800 bg-opacity-60'}>


                <div
                    className={`w-full ${!showScene ? 'h-[0px]' : 'h-[400px]  ring-2'} transition-all  rounded-sm ring-orange-500`}>

                    {
                        showScene ? (
                            <button onClick={() => {
                                setShowScene(false)
                            }} className={'pointer-events-auto absolute -right-14 top-0 w-12 h-12 ring-2 ring-red-500 flex justify-center items-center bg-red-900 text-4xl'}>
                                X
                            </button>
                        ) : null
                    }



                    {
                        false ? (
                            <div className={'w-full h-full'}>

                                <Canvas frameloop={'demand'}
                                        dpr={1}
                                        camera={{
                                            fov: 11,
                                            near: 1,
                                            far: 100
                                        }}
                                        gl={{
                                            alpha: false,
                                            depth: false,
                                            stencil: false,
                                            antialias: false,
                                            precision: 'highp',
                                        }}>
                                    <color attach="background" args={[0.04, 0.04, 0.04]}/>
                                    <EnvironmentLighting/>
                                    <Effects/>
                                    <PaperdollCamera/>
                                    <CustomAvatarPaperdoll/>
                                </Canvas>
                            </div>
                        ) : null
                    }
                </div>


                {
                    showScene ? (
                        <div
                            className={`my-1 pointer-events-auto text-orange-300 text-xl cursor-crosshair flex justify-center items-center`}>

                            <button onClick={() => {
                                const name = prompt('Enter display name')
                                // console.log(name)
                                myNameStore.set({myName: name})
                            }}
                                    className={'p-1 px-4 bg-neutral-800 rounded-md ring-2 ring-orange-700 hover:ring-orange-500 mt-1'}>
                                set name
                            </button>

                            <button onClick={() => {
                                const tex = prompt('Enter InscribedSpace texture inscription ID')
                                // console.log(tex)
                                myTextureStore.set({myTexture: tex})
                            }}
                                    className={'p-1 px-4 ml-2 bg-neutral-800 rounded-md ring-2 ring-orange-700 hover:ring-orange-500 mt-1'}>
                                load texture
                            </button>


                        </div>
                    ) : null
                }





            </div>
        </DragContainer>
    )
}

// c9d85dd85ee24d8afc0d2b86986abd29672f3cc4dbe88cab5ed3283fb431f721i0
