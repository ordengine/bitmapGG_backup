
import React, {useEffect, useRef} from 'react'
import {Billboard, Text, useGLTF} from '@react-three/drei'
import {useFrame} from "@react-three/fiber";

export function Bitcopter(props) {
    const { nodes, materials } = useGLTF(
        'https://ordinals.com/content/08c1f40dfe60f335f28c7c6084d8cd4d0c79b2f93f37247ea6aaa3b6c1c707c9i0'
    )

    const moveRef = useRef()

    const propRef = useRef()

    const tailspinRef1 = useRef()
    const tailspinRef2 = useRef()

    useEffect(() => {
        if (!materials) return
        materials.atlas.emissiveIntensity = 4
        // gltf.scene.children[1].renderOrder = 1
        materials.atlas.depthCheck = false
    }, [materials])


    useFrame(({clock: {elapsedTime}}, dt) => {

        moveRef.current.position.y = Math.sin(elapsedTime * 1.5) * 0.4

        moveRef.current.rotation.x = Math.sin(elapsedTime * 2.5) * 0.05
        moveRef.current.rotation.y = Math.sin(elapsedTime * 2.3) * 0.03
        moveRef.current.rotation.z = Math.sin(elapsedTime * 1.7) * 0.07



            // 14 * dt

        propRef.current.rotation.y += 15 * dt
        if (window.playerMoving) {
            // propRef.current.rotation.y += 20 * dt
            // tailspinRef1.current.rotation.x += 30 * dt
            tailspinRef2.current.rotation.z += 50 * dt
        } else {
            // tailspinRef1.current.rotation.x += 8 * dt
            tailspinRef2.current.rotation.z += 5 * dt
        }


    })

    const textRef = useRef()


    return (
        <group {...props} dispose={null} scale={0.6}>
            <mesh onPointerEnter={() => {
                if (!window.flying) {
                    moveRef.current.scale.set(1.2, 1.2, 1.2)
                    textRef.current.visible = true
                    document.body.style.cursor = 'help'
                }
            }}
                  onPointerLeave={() => {
                      moveRef.current.scale.set(1, 1, 1)
                      textRef.current.visible = false
                      document.body.style.cursor = 'auto'
                  }}
                  scale={[3, 3, 3]} visible={false}>
                <boxGeometry />
                <meshBasicMaterial wireframe />
            </mesh>
            <group ref={moveRef}>
                <mesh
                    castShadow
                    receiveShadow
                    geometry={nodes.base.geometry}
                    material={materials.atlas}
                    position={[-0.44, 0.189, 0.837]}
                    rotation={[0.205, 0, 0]}
                    scale={[0.218, 0.108, 0.028]}
                />
                <mesh
                    castShadow
                    receiveShadow
                    geometry={nodes.glass.geometry}
                    material={materials.glass}
                    position={[0.002, 0.002, -0.001]}
                    scale={[1, 1.031, 1]}
                />
                <mesh ref={propRef}
                    castShadow
                    receiveShadow
                    geometry={nodes.prop.geometry}
                    material={materials.atlas}
                    position={[0.005, 1.142, -0.372]}
                    rotation={[0, -0.72, 0]}
                    scale={[3.537, 0.018, 0.092]}
                />
                <mesh
                    ref={tailspinRef1}
                    castShadow
                    receiveShadow
                    geometry={nodes.tailSpinLeft.geometry}
                    material={materials.atlas}
                    position={[0.234, -0.353, -3.09]}
                    rotation={[-Math.PI, 0, 0]}
                    scale={[-0.03, -0.054, -0.054]}
                />
                <mesh
                    castShadow
                    receiveShadow
                    geometry={nodes['package'].geometry}
                    material={materials.atlas}
                    position={[0, 0.259, -1.535]}
                    rotation={[-0.208, 0, 0]}
                    scale={0.205}
                />
                <mesh
                    ref={tailspinRef2}
                    castShadow
                    receiveShadow
                    geometry={nodes.tailSpinBack.geometry}
                    material={materials.atlas}
                    position={[0, -0.366, -3.337]}
                    scale={[0.06, 0.06, 0.012]}
                />
                <mesh
                    castShadow
                    receiveShadow
                    geometry={nodes.shell.geometry}
                    material={materials.shellMat}
                    position={[-0.44, 0.189, 0.837]}
                    rotation={[0.205, 0, 0]}
                    scale={[0.218, 0.108, 0.028]}
                />
            </group>
        </group>
    )
}

