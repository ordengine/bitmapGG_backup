export const getUncommon = (blockHeight) => {
    const initialReward = 5000000000; // 50 BTC in Satoshis
    const halvingInterval = 210000;   // Halving occurs every 210,000 blocks
    let totalSatoshis = 0;
    let currentReward = initialReward;

    for (let i = 0; i < blockHeight; i += halvingInterval) {
        const blocksInThisEra = Math.min(halvingInterval, blockHeight - i);
        totalSatoshis += blocksInThisEra * currentReward;
        currentReward /= 2;
    }

    return totalSatoshis;
};
