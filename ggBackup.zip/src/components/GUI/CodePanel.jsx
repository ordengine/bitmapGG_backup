import {DragContainer} from "./DragContainer.jsx";
import {codeOpenStore, componentBuildStore, currentBitmapStore, transformModeStore} from "../../modules/stores.mjs";
import {getBitmapFromCoordinates} from "../../modules/utils.mjs";
import {useStore} from "statery";
import React, {useEffect, useMemo, useRef, useCallback} from "react";
import * as THREE from "three";
import {setSelectedComponent} from "../bitmap/ComponentBuilds.jsx";

import {useFrame, useThree} from '@react-three/fiber'


export const CodePanel = () => {

    useEffect(() => {

        window.React = React
        window.useRef = useRef
        window.useEffect = useEffect
        window.useMemo = useMemo
        window.useCallback = useCallback
        window.useFrame = useFrame
        window.useThree = useThree
    }, [])

    const {componentBuilds} = useStore(componentBuildStore)

    const {transformMode} = useStore(transformModeStore)

    const {currentBitmap} = useStore(currentBitmapStore)

    const selectedComponent = useMemo(() => {
        return componentBuilds.find((b) => b.selected)
    }, [componentBuilds])

    const presetComponents = [
        {
            name: 'torus',
            jsx: `// a torus/donut

export const Component1 = () => (
  <mesh>
    <torusGeometry args={[1, 0.4, 16, 100]} />
    <meshNormalMaterial />
  </mesh>
)`
        },{
            name: 'box',
            jsx: `// plain box

export const Component1 = () => (
  <mesh>
    <boxGeometry args={[1, 1, 1]} />
    <meshNormalMaterial />
  </mesh>
)`
        },
    ]

    const position = useMemo(() => {
        if (transformMode === 'translate') {
            return selectedComponent?.position
        } else if (transformMode === 'rotate') {
            return selectedComponent?.rotation
        }
        if (transformMode === 'scale') {
            return selectedComponent?.scale
        }
    }, [selectedComponent, transformMode])
    const formattedPosition = position
        ? {
            x: parseFloat(position.x?.toFixed(3)) || 0,
            y: parseFloat(position.y?.toFixed(3)) || 0,
            z: parseFloat(position.z?.toFixed(3)) || 0,
        }
        : null;


    useEffect(() => {
        // console.log(selectedComponent)
    }, [selectedComponent])


    useEffect(() => {
        // console.log(selectedComponent)

        const intt = setInterval(() => {

            const componentsString = JSON.stringify(componentBuildStore.state)

            // console.log(componentsString)
        }, 3000)


        return () => clearInterval(intt)
    }, [])

    const {codeOpen} = useStore(codeOpenStore)

    const ref = useRef()


    useEffect(() => {

        const startEditor = async () => {
            var modeText = await fetch('/content/ace98f59871f43dc73db7a65849811fce5bd9aeecca5ee6fad0f99a7793271aci1').then(r => r.text())
            var blob = new Blob([modeText], {type: 'application/javascript'});
            var blobUrl = URL.createObjectURL(blob);

            var themeText = await fetch('/content/ace98f59871f43dc73db7a65849811fce5bd9aeecca5ee6fad0f99a7793271aci2').then(r => r.text())

            var blob2 = new Blob([themeText], {type: 'application/javascript'});
            var blobUrl2 = URL.createObjectURL(blob2);

            var editor = ace.edit("editor", {
                wrap: false,
                autoScrollEditorIntoView: true
            });

            // console.log('SAACEE')
            // console.log(editor)
            ace.config.setModuleUrl("ace/theme/bop-theme", blobUrl2);
            editor.setOption("theme", "ace/theme/bop-theme");

            ace.config.setModuleUrl("ace/mode/tsx", blobUrl);
            editor.setOption("mode", "ace/mode/tsx");

            editor.container.style.lineHeight = 1.18
            editor.container.style.fontSize = '16px'
            editor.renderer.updateFontSize()

            window.editor = editor

            const defaultCode = "export const Component1 = (props) => (\n  <mesh>\n    <torusGeometry args={[1, 0.4, 16, 100]} />\n    <meshNormalMaterial />\n  </mesh>\n)"

            editor.setValue(defaultCode)

            editor.moveCursorTo(0, 0);

            // buildCodeToIframe()
        }

        startEditor()

    }, [])

    return (
        <div style={{zIndex: 11}}
             className={`${codeOpen ? '' : 'hidden'} -mt-10 mb-10 w-full  bg-neutral-900 h-full text-xl flex flex-col text-lime-400`}>

            <div className={'w-full h-full flex border-2 border-b-0 border-orange-500 border-opacity-50'}>

                <div
                    className={'bg-neutral-900 w-32 min-w-32 h-[337px] flex flex-col items-center py-2 overflow-y-scroll'}>

                    <div className={'flex text-center font-mono text-sm'}>
                        components
                    </div>

                    {
                        presetComponents.map(p => {
                            return (
                                <div onClick={() => {
                                    window.setSelectedComponent('')

                                    window.editor.setValue('\n   ' + p.name + ' 🟧')
                                    editor.moveCursorTo(0, 0);

                                    setTimeout(() => {
                                        window.editor.setValue('\n   ' + p.name + ' 🟧 🟧')
                                        editor.moveCursorTo(0, 0);
                                    }, 100)

                                    setTimeout(() => {
                                        window.editor.setValue('\n   ' + p.name + ' 🟧 🟧 🟧')
                                        editor.moveCursorTo(0, 0);
                                    }, 200)

                                    setTimeout(() => {
                                        window.editor.setValue(p.jsx)
                                        editor.moveCursorTo(0, 0);
                                    }, 400)
                                }} key={Math.random()}
                                     className={'text-sm w-16 h-16 ring-2 rounded-sm ring-orange-500 my-2'}>
                                    {p.name}
                                </div>
                            )
                        })
                    }
                </div>


                <div className={'flex flex-col w-full h-full'}>

                    <div className={'w-full h-[65px] flex items-center p-1'}>

                        <div className={`${selectedComponent ? '' : 'hidden'} h-full flex`}>
                            <button onClick={() => {
                                const selectedComponent = componentBuilds.find((b) => b.selected);
                                if (selectedComponent) {
                                    const code = window.editor.getValue()
                                    console.log(code)
                                    if (code) {
                                        componentBuildStore.set((prev) => ({
                                            componentBuilds: prev.componentBuilds.map((comp) => {
                                                if (comp.id === selectedComponent.id) {
                                                    sendComponentBuilds([{...comp, jsx: code,}])
                                                    return {
                                                        ...comp,
                                                        jsx: code,
                                                    }
                                                } else {
                                                    return comp
                                                }
                                            })

                                        }))


                                    }

                                }
                            }}
                                    className={`m-1 p-1 gloww px-4 ring-2 ring-lime-400 rounded-sm opacity-80 hover:opacity-100`}>
                                update
                            </button>


                            <div className={'ml-2 flex flex-col text-[22px]'}>

                                <div className={'flex w-full font-mono'}>

                                    <button onClick={() => {
                                        if (transformMode === 'translate') {
                                            transformModeStore.set({transformMode: 'rotate'})
                                            transformControlsRef.current.setMode('rotate');
                                            transformControlsRef.current.enabled = true
                                            transformControlsRef.current.setSize(1)
                                        } else if (transformMode === 'rotate') {
                                            transformModeStore.set({transformMode: 'scale'})
                                            transformControlsRef.current.setMode('scale');
                                            transformControlsRef.current.enabled = true
                                            transformControlsRef.current.setSize(1)
                                        } else {
                                            transformModeStore.set({transformMode: 'translate'})
                                            transformControlsRef.current.setMode('translate');
                                            transformControlsRef.current.enabled = true
                                            transformControlsRef.current.setSize(1)
                                        }
                                    }}
                                            className={'pr-2 text-sm text-cyan-400 hover:scale-[110%] hover:text-orange-400 hover:text-orange-300'}>
                                        [<b className={'text-cyan-300'}>{transformMode}</b>]
                                    </button>

                                    <span className={'pr-2 text-sm text-orange-400'}>
                                id: <span className={'font-bold gloww'}>{selectedComponent?.name || ''}</span>
                                </span>

                                    <div className={'ml-auto'}>

                                    </div>
                                </div>
                                <div className={'flex text-[14px] font-sans pt-1'}>

                                    <button className={' flex items-center'}>


                                        <div
                                            className={'ring-2 ring-blue-400 h-6 flex items-center font-bold text-blue-200 rounded-md px-0.5'}>
                                            <div className={'text-blue-400 mr-1 text-xl w-[9px]'}>
                                                X
                                            </div>
                                            {formattedPosition?.x || '?'}
                                        </div>


                                        <div
                                            className={'ml-2 ring-2 ring-lime-500 h-6 flex items-center px-2 font-bold text-lime-200 rounded-md px-0.5'}>
                                            <div className={'text-lime-500 mr-1 text-xl w-[9px]'}>
                                                Y
                                            </div>
                                            {formattedPosition?.y || '?'}
                                        </div>


                                        <div
                                            className={'ml-2 ring-2 ring-orange-600 h-6 flex items-center px-2 font-bold text-orange-300 rounded-md px-0.5'}>
                                            <div className={'text-orange-600 mr-1 text-xl w-[9px]'}>
                                                Z
                                            </div>
                                            {formattedPosition?.z || '?'}
                                        </div>
                                    </button>
                                </div>


                            </div>
                        </div>


                        <button onClick={() => {

                            // console.log(window.playerRef)

                            const defaultComponent = {
                                id: Date.now(), // Unique ID,
                                name: 'comp' + componentBuilds.length,
                                position: new THREE.Vector3(
                                    window.playerTileX,
                                    window.playerTileY + 0.5,
                                    window.playerTileZ
                                ),
                                scale: selectedComponent?.scale || 1,
                                rotation: window.playerRef.current.rotation.clone(),


                                jsx: window.editor.getValue(),
                                // jsx: "export const Component1 = (props) => (\n  <mesh>\n    <torusGeometry args={[1, 0.4, 16, 100]} />\n    <meshNormalMaterial />\n  </mesh>\n)",

                                bitmap: getBitmapFromCoordinates(
                                    Math.floor(window.playerTileX / 100),
                                    Math.floor(window.playerTileZ / 100),
                                )

                            }

                            componentBuildStore.set((prev) => ({
                                componentBuilds: [...prev.componentBuilds, defaultComponent],
                            }))

                            setTimeout(() => {
                                sendComponentBuilds([defaultComponent])
                                setSelectedComponent(defaultComponent.id)
                            }, 200)


                        }}
                                className={`ml-3 w-fit truncate m-1 p-1 px-2 ring-2 gloww bg-neutral-800 text-orange-400 ring-orange-400 rounded-sm opacity-80 hover:opacity-100 active:opacity-90`}>
                            {'+ add new'}
                        </button>


                        <div className={' ml-auto'}>

                        </div>


                        <button onClick={() => {

                            // console.log(window.playerRef)

                            const defaultComponent = {
                                id: Date.now(), // Unique ID,
                                name: 'comp' + componentBuilds.length,
                                position: new THREE.Vector3(
                                    window.playerTileX,
                                    window.playerTileY + 0.5,
                                    window.playerTileZ
                                ),
                                rotation: window.playerRef.current.rotation.clone(),


                                jsx: window.editor.getValue(),
                                // jsx: "export const Component1 = (props) => (\n  <mesh>\n    <torusGeometry args={[1, 0.4, 16, 100]} />\n    <meshNormalMaterial />\n  </mesh>\n)",

                                bitmap: getBitmapFromCoordinates(
                                    Math.floor(window.playerTileX / 100),
                                    Math.floor(window.playerTileZ / 100),
                                )

                            }

                            componentBuildStore.set((prev) => ({
                                componentBuilds: [...prev.componentBuilds, defaultComponent],
                            }))

                            setTimeout(() => {
                                sendComponentBuilds([defaultComponent])
                                setSelectedComponent(defaultComponent.id)
                            }, 200)


                        }}
                                className={`hidden w-fit truncate m-1 p-1 px-2 ring-2 gloww bg-neutral-800 text-lime-400 ring-lime-400 rounded-sm opacity-80 hover:opacity-100 active:opacity-90`}>
                            {selectedComponent ? 'save' : 'save'}
                        </button>


                        <div className={`${!selectedComponent ? '' : 'hidden'} h-full font-mono text-sm flex`}>
                            <div className={'p-1'}>
                                <span>{componentBuilds.length}</span> component(s) - on {currentBitmap}
                            </div>
                        </div>


                    </div>


                    <div style={{zIndex: 20000000000000000000}} id={'editor'} className="h-full w-full flex">

                    </div>
                </div>
            </div>
        </div>
    );
};
