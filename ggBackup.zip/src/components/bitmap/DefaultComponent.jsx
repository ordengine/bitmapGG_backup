
export const Component1 = () => {

    const ref = useRef()

    useFrame(() => {
        ref.current.rotation.y += 0.1
    })
    return (
        <mesh ref={ref}>
            <torusGeometry />
            <meshNormalMaterial />
        </mesh>
    )
}
