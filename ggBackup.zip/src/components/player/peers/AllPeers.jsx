import { useEffect, useRef } from "react";
import { useStore } from "statery";
import { peerStore } from "../../../modules/stores.mjs";
import PeerPlayer from "./PeerPlayer.jsx";

export const AllPeers = () => {
    const ref = useRef();
    const { peers } = useStore(peerStore);

    useEffect(() => {
        // console.log(peers);
        // console.log("peers update");

        if (peers.length > 0) {

            // sendChat(peers.length, '>')
        }
    }, [peers]);

    return (
        <group ref={ref}>
            {Object.entries(peers).map(([peerId]) => (
                <PeerPlayer
                    key={peerId} // Key ensures proper tracking by React
                    peerId={peerId}
                />
            ))}
        </group>
    );
};
