import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

if ('serviceWorker' in navigator) {
    navigator.serviceWorker
        .register('./sw5.mjs', { scope: '/', type: 'module' })
        .then(function (registration) {
            console.log('Service Worker registered with scope:', registration.scope);

            function waitForServiceWorkerReady() {
                if (navigator.serviceWorker.controller) {
                    return Promise.resolve();
                }

                return new Promise((resolve) => {
                    navigator.serviceWorker.addEventListener('controllerchange', () => {
                        resolve();
                    });
                });
            }

            return waitForServiceWorkerReady();
        })
        .then(() => {
            ReactDOM.createRoot(document.getElementById('root')).render(
                <React.StrictMode>
                    <App />
                </React.StrictMode>
            );
        })
        .catch(function (error) {
            console.error('Service Worker registration failed:', error);
        });
} else {
    ReactDOM.createRoot(document.getElementById('root')).render(
        <div>no service worker</div>
    );
}
