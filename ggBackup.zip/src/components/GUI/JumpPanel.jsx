import React, {useRef} from 'react';
import { DragContainer } from './DragContainer';
import {useControls} from "leva";

export const JumpPanel = () => {
    const handleSpaceDown = () => {
        const event = new KeyboardEvent('keydown', { key: ' ' });
        window.dispatchEvent(event);
    };

    const handleSpaceUp = () => {
        const event = new KeyboardEvent('keyup', { key: ' ' });
        window.dispatchEvent(event);
    };

    const handleControlDown = () => {
        const event = new KeyboardEvent('keydown', { key: 'Control' });
        const event2 = new KeyboardEvent('keydown', { key: ' ' });
        window.dispatchEvent(event);
        window.dispatchEvent(event2);
    };

    const handleControlUp = () => {
        const event = new KeyboardEvent('keyup', { key: 'Control' });
        const event2 = new KeyboardEvent('keyup', { key: ' ' });
        window.dispatchEvent(event);
        window.dispatchEvent(event2);
    };



    return (
        <DragContainer id="JumpPanel"  defaultX={0.99} defaultY={0.57}>
            <div className="flex flex-col items-center text-lg p-2 pb-0 border-4 border-opacity-20 hover:border-opacity-80 border-orange-400 bg-neutral-800 bg-opacity-20 rounded-sm">
                {/* Up Button */}


                <div
                    className="boxGlow select-none w-[65px] h-[40px] border-2 border-b-0 border-orange-400 bg-neutral-900 border-opacity-90 hover:border-opacity-70 transition-all bg-opacity-60 rounded-sm flex justify-center items-center cursor-pointer"
                    onPointerDown={handleSpaceDown}
                    onPointerUp={handleSpaceUp}
                    onPointerLeave={handleSpaceUp}
                >
                    <span className="text-orange-300 font-bold gloww ">▲</span>
                </div>

                {/* Down Button */}
                <div
                    className="boxGlow select-none w-[65px] h-[40px] border-2 border-orange-400 bg-neutral-900 border-opacity-90 hover:border-opacity-70 transition-all bg-opacity-60 rounded-sm flex justify-center items-center cursor-pointer"
                    onPointerDown={handleControlDown}
                    onPointerUp={handleControlUp}
                    onPointerLeave={handleControlUp}
                >
                    <span className="text-orange-300 font-bold gloww ">▼</span>
                </div>

                <span className={'gloww pt-0.5'}>
                    🚁
                </span>


            </div>
        </DragContainer>
    );
};
