// src/components/HealthBar.jsx

import React, {useEffect, useMemo, useState} from "react";
import {DragContainer} from "./DragContainer.jsx";
import {useStore} from "statery";
import {healthStore, myNameStore, peerStore, setHealth} from "../../modules/stores.mjs";
import {getBitmapFromCoordinates} from "../../modules/utils.mjs";

export const HealthBar = (props) => {
    const health = useStore(healthStore).health;

    const {myName} = useStore(myNameStore)


    const {peers} = useStore(peerStore)

    const [locations, setLocations] = useState({})

    useEffect(() => {
        const intt = setInterval(() => {
            const locations = {}
            Object.keys(peers).forEach(key => {

                if (window.peerTargets[key]) {

                    const tile = [window.peerTargets[key].position[0], window.peerTargets[key].position[2]]

                    // console.log(tile)

                    const bitmap = getBitmapFromCoordinates(Math.floor(tile[0] / 100), Math.floor(tile[1] / 100))


                    locations[key] = bitmap
                }

            })
            setLocations(locations)
        }, 2000)

        return () => clearInterval(intt)
    }, [peers])

    // Function to handle setting health with clamping
    const handleSetHealth = (value) => {
        setHealth(value);
    };

    // Determine health bar color based on health
    const healthColor = health > 50
        ? 'bg-gradient-to-r from-green-400 to-green-600'
        : 'bg-gradient-to-r from-red-400 to-red-600';


    useEffect(() => {
        // console.log(window)
    }, [])

    return (
        <DragContainer id={"HealthBar"} defaultX={0} defaultY={0} {...props}>
            <div className={'flex flex-col'}>
                <div
                    className="opacity-100 border-4 border-opacity-60 hover:border-opacity-80 border-orange-400 bg-neutral-800 bg-opacity-70 p-1">
                    <div className="flex items-center">
                        {/* Avatar or Icon */}
                        <div onClick={() => {
                            window.setShowPaperdoll(s => !s)
                        }}
                            className="w-11 h-10 hover:opacity-60 hover:ring-2 cursor-pointer ring-orange-500 bg-orange-900 rounded-sm flex justify-center items-center text-white mr-1">
                            <img
                                src={"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAK4AAACfCAYAAABgKuLmAAAABHNCSVQICAgIfAhkiAAAABl0RVh0U29mdHdhcmUAZ25vbWUtc2NyZWVuc2hvdO8Dvz4AAAAtdEVYdENyZWF0aW9uIFRpbWUAU2F0IDA5IE5vdiAyMDI0IDEwOjUyOjU2IEFNIEVTVPDQISoAACAASURBVHic7X1rjC1Jfd+vzunzmjlnnnce9859zC7sGrzAEgUksxiwIhysCMmOjcnjg4nAUiLlYWdtRZDI2PmEkbJXiWzjWOHhjaU4OJAvlrAISIkwLCjSZllYwOuFu3dn7sy9d+7MnJk570d35UO/qqurqqu6+zyu7Z80c/pRXVVd9et//etf/6oia396mRIAoACBC/+XPxaCAJS7FJxXAKxHr/FhsSF+lgqu8cexfO4L7vUpCl+38f6fs3Ht+iiSVr8JjAdAqcZnCihW4td81LeAMgH82EZ9edhiGWgdxq/bA8AeuWkvbsqfN0H7fj7x+CAFgEgIUF2Jprv6iF6cjWK6vIwB9BygfQ8YtQGreMXLJKK/GChiKXthlwC03GOfUM6hGwf14qBMpcVICwD+/SfD9Cnzy0NUjsG1a+5x5F0eEJA1oERtdB/En117vShTYjSs6HnJP6gCPS5sc08dV6Hk/ok+Gl2scc+u7QJ7t9PHx4M6AEkgmglpAaBlu78+gU9bZnnavuLywpJK1AoizOGlHlkCRnsOSK+gTEhHepMrAH3AxO3/bojTFsa3752fRO8RAM4JsLTgCNM+exVY0Sz41jhOXhlWr0fPZUTunQLlujwenpxJuL6rvm/IE1AA1JbfNyEti70fhsf1Lf3nmi2g2gBi1UCDf9w1AFjyXgSAs+eA/qUD8iRH3FOJysHEGdzfiacbURWOwnOyEZI6eMYn6ykXL/f7xGNi0vo4e9X91SGwiLy8tBWBJTJP4vN9YPmaRiQ5oOH96hKYAEDBlb6TQvu+GXn7LZ64NN48k6XIbRctCvqig8IywL4PAYA1gJ5Em3rRMbkCUNEHIkiPbEnUjDPvtwHghJPWzO/2AgXxvi+VdOudANVV+X0AqJSBDgUazBekbnOA1ikwOA/PR93w2B4BixvxZ3yME+LWgWYjIQUhwOmr2fMhk84mpPVh8ZLOh09YX8JG8IoD0gKwIiYn1qMP0VMubiDUbethOgCAC8Q6dLgtIS4ThvDPeHhz0caNxbBTNuqpC0rULMaaa4+0veipFEtrQJPpM1jVhAcYXOiIcw55d9LyQtMjv0/gNIT1YfFSD0CgEgjx/2zgZQqy7lXYkAJlEg3P68Zr7jHhbzcgRBJJTe5tWfE2LqliV3fd3wZccqbgTjzOy0Dzrvx+uRZ8w6nhN/9+/vNA87b7W10G+ufKoInwO6I+gbN8YJbDm2rqcKWeDwqQa4zeuE6AtxEQz7JgDQBaCIJKIZRKJdFFLzxTi5QChJVSTQCMhUBmxhsRigVqY8CYq0Smp9XL4jyYELbFVGpjWRyGTYcncfcMKKwAz90LxfvXjlLajjRBbvAXwsOgLteY+5vCoPiFsz6WhslKzYgr0NVHQhKbgqx+/TKVST4fhXLcLEL3xWGDiBMSpnA/CNk9JUT2Wj7NAcXfv9JDxdPCk2ylMvICUVLmBRG52+fA7762iMINAvoagGMNO3paXA0PSewgGXzQX7rSx0o1D408hIrUFk0gLVkB6DJHpvsAuQrQO+kGLYhfaBJzG/88a02gdyRx8hco4IwBWHoG/uZdNXnzhv8xsAQulgFySEFqBIVa+GHHyljxZUsHgzRAJQLBR+Gq4KKHl5plXC4athBl9e2FXff3QmB/t0gLUl0THmlZELi9fJ+8MYM/zKQE27ljzyPYl1wnivTOHBSvA4vr0cudI3E+lncnI1mTwKZJAJB9AK+LXgNCc6LoXfmPXnWuC75eAMC5wwgdDt/uFvCCXQAV6Fd8nglV3wc848BpfCTVNxZY5NQN4OuUfsaoA9AmQJoA2QXofUEGmMjYAkpTUCIElXYtHi8rHUQDFKQG7K2Xsbca5np4H/KvXDAsCwBYiJ5+ZxiVKrIWIAa+sq4BW/ejSub9rddA4MA5oCjskOAxAgQFHLNlJyRlJIEZUoreK1EgFQFSBgpD8W16oJ8nchjeI/U4t8hv9RrCd/nG92t44Uwg+rkvLvbwVvRe5GW5XmQq3wiIP5Dg2LP5Fr4wBv2ABQgkbN56YzAQwuVl+9Ql5vKRK/YXD10b48IP5faD7mYbnY0LnL/xBADBvbXb2i0ZuSYnbXCcwi/CVBAVDoDiLb2IdePmySsk7jd+UMOLzZC0kQeuccTZjNt6YzZh7pgAAYllaoZIzxXlhycsBYATiuKLDsgTReWz0oENUd4FH93WkUfMw7DrvfjqMhZeSGPYktOy9/o2AODwrW5v5f7a7ViYQBKJWif/YEtwbUIo3AEKmuTVBmPzJ79Do8R9+ayCz/95KfYAhdch49KjQKRA2K9IqFokEFb0HBN17DgmfbcA/B8bhSUCslOQ6kh+npNMeNt3b2B5b801CwJYfGEZNZaYJKsET9eVD8j8pEvmuz6ZvTDBe3k6PtnNmaxnzLHEwlToA0RlUzTNEFvsLHFPYeF3/jQ6rBOTnlfEcbJDw1JQiSKu8aggKul15wUb5PWFYFyWl8rstcs+MT3UX15C7esyiUkih2kJO+h34xcJUKksJiYbvxXe7L6pDRCgff0c55ddb6PDjdvmnjVs/BKTJQFcx6g+YuPSBAC9iHbcM0FQHQFx9y4sfOZr8bFINuHClfi1WA8xicASxpl8fKwfggjDr4+BX3BH6LfvXsfyXmhaWHzZ0zOl5FSlCql/KgshMeVR+jEHl8uVBXCXBI/qU6L7Y220d85xvuWRef229rMy4rp5SLbnF3oI/ER0QQGAp2IFoOcIOssWO0jGk1AYoUCh1pK23rOy4tatBlavpQA2j66DAlg+WAcFUH91CfQQWPhy1gFUJmeG0rVSdUtXRuBKdRHDQSeMX5CkJCfymwosvFzHwst1bGIHIASP4Ul0n3LF8OFPu6rG4eVXjeOlALCiDmN/y0FpjaDQEOdeR/0LVM8luH2q1wDy66+GqsKz341WdoSgVxB4bkWu8x0cCflV+q3qeOPI9QdcOnCb88VXXcNy7QW+Wc3bVkC0pKsMItJWqhJVwMNwED5TrkbtcCYSVozkr6/3lKs3H7zX7VVFyJwieQoA33KAPlB6Y8FIOCWdR4j7X2+JiZvWmgBIOmEMgbc8Yi4fsD3zpWgHSInZEVZXJYjGx6kECWllISz7IfAJ8R9GPIR7xZfM7cfPcX7dVTXuGkhn51sO6D2gsAoU3hjqDAQKGzhDpIhAY9QWa8DoCjKmk6uI+c7CG5AgTO9c1vHiBy9WP1fAoy/9JKq1ekre5U1WAMSMIomkVXW2vPvqW8RLR6BSJD4bopwg5eXRuVcXnmsEv5ve6NRjeBLdR9vovPkc51eOAQD3NsVkpn1PwDUB2qXAI2GHWTnKdhK/Tu+Ew84RH2PRDA3fBCY1VwlG1JJgfYFgD98AQFFfvYa17V0QAJVaUiHHUwor1kVScxyPUl9z1JKwTIeL1WNVHa5hYryRXlwMlQonPTWbDBVhky4Vv19E5fkKNrGDXqcF+13bOP2le8F9X87ZALAFkPsA+QEFPQScJY38lT2yMr7c5IprrQA44r7hCRs/qIYDD2zvnRoOGMjAC+52cx/tpts1ra+6bcH69i5HYv2KGEaInFDhmiQ3JWzsIvhmWxfRSGMEjQXPl7CDQRf9nlue/Y6rMnRaZ7FwPoSq4mWAfB/uHEYAxXM3lIy8FAC5zh0z8xH9Dr61/ZbwoUYH+cwVkSDJ5OUTmCXy+vYuAKBSE+u8PPlc4qoJ64OX1iHMBgVEuqEIrF4pIvig3zFvMYLHk/MsCjHou+21T9Bet4Wugpwq2KIE7gFYBMjYs1oRj7w9wNlyCy/RFOpPbXqAILzlW7Iu4F701eeYU42nSCf1+FTwHXjGH6CwvpBc0K3mPlpN1zWsscZKY3nHjdfpfElXri7EOjpx4ibnyTV1JfaoNG7HA5mrORqJeRj2exFyAkC31YzlKi0G7xhivBWPqfQDgPrfQR1BE14cUtAuQBfj6SbZhlEFrBNmdsD1wxG22qN4wAEAr0wbAp/V5YWomE6acPh/1+r4IZJ9N31VBQBap/uR38ZasjQG1ETjiTLodwMbrDxH5rfiQTKQhMQOAgz6XQx6oUrS67bQuWDIqWyIVEM6ybh24eCpV+Mro5w3CL6JEpz7AFkE0HGTog+A4hHF+G3qNIWCsQ9YZ7fd49IisFIeA2uIL5zhacLLN8xeZpJone5HSAyQiG5MDKSRDzlp0xNWpvMag3l00O9h4EvPThudiORUwGMBlRJY5mWSjGtVisYormc2GgBplQLrE1kEaAfucgMPgOIrDuzHCoktd9DX8n6tYdtdTmeVsZH5awC0j6MPn7+m9xJ9phxXHo3f33zrWEvi6iKUxu6CBY2164E0ri5kGUGbHWEHg5CcANDrtJQdIyN4tS+nqTmBv/mgiLMb9fBpdjEXz5UysFqtRGMnAEgXcBK8yVjyWgBwSbIMUf2S+9s+1idthRv+PfMyIyKwDgg8CWGgTLdO9yIkBoD1y7uu3dgoZf3L4tvJFT/wdE9CciZnEhhuypWElBL4AK7TODPRMqi+BgLPMrZKCQBSBuhQfI+NhwCwNt+UnI9RGkvOnMAncEDkdUYaC4mcP2H7vQ563XZw3m1f4OLMbc4qFYNFFiYBRvrKX1FD/z1BMMMhwCnCpQkaYUzSFLzZKc4gfg9MDigAq6wot6SF20xwxjQDnXvycJNG62QPrZOQxACwvv2ImMRGHS6g3+sGBO22zwNyGkU4CyTqvkwgxTsQUSh/Gs8JgPVoGNHzpOwGcCTTf3xEBiBkRBWtcpgFSzcUq6gJYKgpaMMnMEvkS9uPAAAqEt2YNSsBQPuiKSCoDOk7P1MBQ2A+h4OBKwYrFX/9VckwhkobO0EwgKCqzwIAUgQcydpRBICVJFXzJm1qTIq9DFone7g42QMosHTpOgqFEhaXL6HXERjlvXob9PuRcz1M+EWygrrkHbIrqcRekPsIq5AuxUPY4JLYguvXELjOkiGki+0JOT03ZJ0hLo73ULCq6Pckc0+EvnbioL4eOxgoVoCeN8S+LZV2Kr6v8u8mgNhJnXmmWAYcSZkGxJ0mWRuX/UEOfTHqhxyPXVuhZWVdg1CRjpeYM+4ndksqlWpISEYI6Xe65lx9MAGNnyolq+J5v74LVMyQydT+lDEejydGZCBaAVpSM5UmkI3Afr5maaUQEVXoeHMtXJ42Ep6TY6pitHyHosVNoJMgdWVFWpEs8pY7FHXqS2IfWYjMlt9w6s27msCzVjekUnRDIkUlcYiOASgbYXbqmsWOmJUMfDyS/BEmARNZNGkpnIhsQ/8YDFjdekZqhESEysxmEb6p1r5N2Td1OkDBM4cHNds+jQecJDlf/09t/PAP0g/7TpqYhCA+68MUIss5V9t6EnQ6erCwdVG0/xGz2SqUZI0UJT8UJgojgidYi23AqgFo0dlIUBdTsHNxGI3dzmHJUizQmydEbWMqDs6oIydLlpG+STYH6T0dpZiB7ZHXas3IpEgxxnjswJoWeQQYjUdBQZVK8XykmeWr3TmaAoFz77CJuOJfayO6ug3nSCN6nIiuqx7wYC/O0Kqw9bccvJy47cf0MBqNhOQFHQMkXkxlCRmMVducCTyzzts5IqvER45XAKx6ufSKUuREY9JRy5W4ZzqLnHloK/ZDmLStNoIETaVUqoAUzVqFVFzM1JmbA1vwDoDHxLd0fG2NHkAG4pqQNC3G4zEogNIsrQMZYEynzPzLl8CyVsUUUonK3jdUWa2zC8OevQNcJCxm3OwmE601YtUEtdgbjdUzOC3Litlx5wnG3YhcCGz+cCah30RsKVYemb9HP54twPrc84I9N/kU2vEgIuhkzN9NsjagqIBiPB4pO2hTsTlMybDhS7C455VEL52B+pD2mxleHxg9Y9wKsbgPWPSS4pmWl8Aad4Pd9nQnnhE+U6JM2swWoWPPPKWl0zIkmwbfHHuIoqGOmwQjcqQkb1ZLgmm50rsINjcMsmsYCbstWVK+LCqKvxUNGCPlGgDJ5siE++WPVdeyNPc+6XXiEBJ+Bv0abU4mMD2ZpJPvvBFR7KLkqDwXlNmkpuCP6DIKMltn0X0XuQWAZQM+/uoiPEn5zCeRVxdSyUpc17nICz1kHTkjoUSBSjWLJJ0D6wPRsyLYCWsrhLWsuWo14bazF0lY0TmP8fbkG3pW+vKEnv54nRkm6+WlJnCatH9qZwxnRbAmB4Ca54RV9n1hkjQvL3ubS/KZMhYBpKTlpWxw/kAh7hElhcwUYkqaCNG4BHipK8JUbcOG4M1Oyo8+o/NOPLIwxSwfy+qyg6WdQXJAAHVv4qRE29SCJdU/r3Pl84C5JwBbnvzQvMYoXiqMRmOljVdkJnPPXebzUnc0Hk3Pf0GBxAY99xZfNI41ObS9dTfaAOqej4wpia3CCPH19gGQIyS+g65/REzaSjbDS+pgiZp338Zbsqy5bvrTYPoEnlikUvgkhiGBCwW4Drr8H0n4A9xXNP1zDsNj+++IC8eyrOBPipzKNSkaxx5g1tqw0PJjFGAiqeYKn8A96O1ab/FuLhE9UnRdgtj9DUGYfQBrTNSxpbqSu0yqEGYdLtPumRtWNFhQqWTR1sxykKj/IilQmlRzj1SIdjNUHXzyykrWYqUnoKePSjtaG5Lr+5Lrc4J5tzCw0KJRSq796j/5xcj5f/zD/5E9UgPUBT7hPYjJa9zFFm0kHBwbetSNHgOKACyrFIye6cDvkI3G4zlhXK5d/fxSVATiSWqWMnRS14aIsCxE5I0Ql+00mZivfIllIrn4OfdpHMoDAo/GQeJppWd2qTu/5P3Xv/yP45dtfUEhT90HQesAWLoqDQwgmaAq8OS1HNl294YgAKi3UwpZi5MgUEnYuW0t9k4kJqO0S6W0gwt5KwnTH5kSpSgi6iTwoZ9/H579n18GQFFbjy+OuLqTb3oseVNb40VVLiSnJAx/nAsy8lA4tG6nmVEwXbsom+IkU/vQz7/PKHyTW70xDyL7nTZt4sqIKuKJTuERAPZl8UBAHphUh8t8dCkfEj/9kQ/i5mf+xCi1LPjkH/yROvIUr8IT2RQs8TOPf5oShH/f2c9uSH6DYGE75OXk4qcrx9Mf+WCGdMzwyf/skdSEjDPoFLPEtwjnjxtpcsryUS4WaeSIO5BBIudUcmYcMU2fr+khfL+nP/IPppbqb//eZ+U358B5TBcWyuGJsNm/Et7TfR8dsgPAYCODGeAhxTRJ6kNJVhGmbyAxhqXiTFo+BWSXEFhWJiIOp5pPZvgxmNqRdfH0hzmSTpgMH/7Az+QXmUL6FnKeEZIGSuJOCqYftMnshrSYysIkaXuyAqhJmp9V46O/8UxwfHbrm5ni0kHnSC/crHtGLji9lPIXOUx9QTvJoiD5xC24JuFaOolqJpo++vFnkgMJ0DsBClOskoLIg2sa8NMav3tCKebYLJfKFVSq1YwWBX184lPPiiskdQWJHzp+cBfHx+FfWtICwOLWlLa58iD8RmbduTRRUac2s2FCHZZP/P6zemnLzrXzRLG0Ek7XvvXK96NxzXlnjIeytqfaucxoXRCuepN35jMWyCc+xZA0r7xJhy/D+VpLy2th2CBdjrFaZR8tgJXlJXnQCUNJ3GmQdvQIhfU1EzuDHAShx5jvv1CyrMSVcIxgIO0iRJXFM4mPy7HVc6xSZiROVDoz09nEJK6uLVeGTAKYeB5jyGdkjtpDoCBayTFMjx1dM4s8jCNXGBdehuaOulsxTBPWLD4YaXoGbJVZFvgocpW2Hj78wffHrv3+H30hW6QqAhfy27B7khCZslZ284ufdYu0gMnr52njTeKxyaTKhwXLvj46QbLe+uH3co+ztJAvSUXw56XVV3lHcsRJlkYi+2qCznOjy5x3e4x1KWn4kLD3+MEhXveYxk7gGTAJovJoaaqGlsCiWCjHr7Hg934+BWBhA9HVozOA1Wvzkt4s/0yGf01NatMY0PjYb97Er/2LfzjxdCaJm5/+4+CYrWPeiVwG3XBJcGuLIW8WCetD9/mJ69Yzlrof+82bs0s8J9z85L+T3pulL45FvRm4RGNQiHjWEMot7CzdMVuxrq7yhTnCERBQ70LmVRknBH2Szrnr1YMXg8Obn9VzXJ/F2wTtI6uX8qZK6hPzwjB2/zmGwPxLDjcmTK0c2Evtodnuhckxer/Tm9YjS+k/fPyj4QlDWtP4p42IYhebtiiTpAYgAFAHqOaq5qp4ZjN7d5KIUupHr7zE3Pu5XNOhIHiGJWnOWPDW1JjWZuYWIKjc+hw0ZlNgXO6jajqIiT+KH73yXf5iPvBMas98/GP5xy3BtAgc70orpGyqjhv3jCiO8btVw74+WE3XDKrtTf2RtalKZWFBZlcfPvvFPwMAPJ3b9HSzGl/djR63NX1rz18zyZOLKHEZ0sqynFTBOs9oV9F8t/PZIC0E/Rf2iZo3bn7288yZXm2xpPVR39Qj7/IN3ZyFJI+MnPFIIwNkPiiywQ0RVK6KPpdNp/QkfQMz+0YMhNp0iCpDuhZBl7y68EkeMIP4rD+JB9at0CRimrqRjscjWJH5TfnM/jUN4nCLgmRx53vm9z6PX/vn3Fy0KduU9Igqg3lm8yYv4BO3wWRnPbxJT9JLW4B7to6IWYz9fuWujQRj290omp0T9lfRwvDMv/+NicWdjagimEvfvMlroRHPToB1w++Lk9YxCVsHsCSIT2OFk/F4FHcUNwVB4n4R0yA3BXDzt/7txOK/+en/NrG4owjZ0bn7OBYv/6UydN1zfcyDwFos0FYVGGnNkphwq/hRZiBD66Ng2MQunZ+EudoqlR2RmiBppw+3Yl78l08CeBKPPn2A7aeeUz5Rz8F3Vzk9PY3pK3h2HcCux7n7XFy+ingh/ihkw7qsNBx5jjFJxIzFxUpdiXjNQ+re/G2XnLNYAGSWuHVzB7du/qIWgbMgcQaEDoQE3w3jIFsueWNhPQIPr0lWnQ6ISYVsItD3XTBdm8GEvDf/y2Sb5iD+mY8KiVFbXI5dmzSBycqLl3NR6WLDxbvx+zHJ66F6l2Dpl/ndKKIYj0cBk/wMi3baUW3KFwk3GsPy19WVlAB7ubx4WZk/GbQlLuM4rvwQ5pC8tcVlXLrsmqVk2Vt/XxtX338Li5dfziXNiTihkt34NZqwJXwSLKsEUMSWSuIlo65ea5WSX52N23FGKIjmneWAm58x6PXPuXOZLHsnX67j5MtP4vqvWLj6rmyO7c3bORE3Zr+9HSWvTwCxwQsYGAh9yyphlLDOl7FTuEIviN7KhzVGRBVhus5lxhCVUuv8GGdHt1F6foSr78qeRibiKsvttkteel9NWuMEBerudO2z5qzJTFRVVuaYvKNBF4N+B2dHKZwRJGjedn+FW6L6CaskpQxB2GOAHkfji9zHNMmmgQSpC/DvoEfgiZHWxxxK3/aZu9lznoT1sbqboCoQ7leFSJhjjTAa15MSi3UGMb0PIfoxzwlz5kD6ts8eYNBrodeWbwJy63MlvP1Xs6eVSlWIlY+ErMKwkuvj91JYX81W8pnJq4iA2kMQZjnCOF3ngMAzIm+vc4Y7r0zJgxyu1JWqCkooiAqoyy6PcrVKJYxHI8yD94GcwNGrU8McSN5pwCI1RdXvy26IkUYdIABom6J1dYzG3y7Cel5tz/UhW4h5klJXBTFfZiSF50D4i1AquwsoiNTQ4cAsLnfqjqyiPB8DflYvizTSNXa9CPRWHQze6mB5yULtfz8cSw7xkPNlhgSeA/L6hPUhEk2m6y0UdKQL6yRDuD9heMk92XWn4wT3W+9wcPSMnbzgM4kdxG+lRcYI5DmnyrsTwYw0qVK5HPzxOD+KDxGboqAiIAudcElk1gHtuCV9+rMOzj/qpF6xfNaCRp3rKRN4Bt+LKUz3+Q2kNi9JI1JVoSqwz5re8+87RXGpDjYomj/roPchR/5w9CA/5BBlMlf++hG4ZJVAhMqCGXn1ekIKZLEgEAC0R0GPmLBLcVWk/RaKi486GL/XrNTzpDO1h+me0w41RVbllgwFoTYIs/q5DCWrhFKOOxtNbshX81mn65Wi51z+5JqN7asCCfs6oLgCPP+Vsvs0YUYiJlXfOcVt1jWbUo8qZTLUHgMEKBBJK8hBRNbmK4tY2mwKw9dXw+VEVUgkrsqikKWIgyFlb8EDliOPXBmge/fxIGx33923tfkjgo3rBA/2vg1QAhC2wRCzbPaW3hD6BJ6SLVgjQ5Q6gOOAUhuUOrCsZItPqVzOJF19lUFF4HDtMNHdBN3Wfy7J38HH5sk1AMDSg3D3F3obqHeWgAJQu18Hnge++6w8veV1oLrQQPP+a2g39xFIXwU7M5F3Asw3l8D6oVOBqyhn2AYKViBUAHiEVZNWZEEQwSqIpg3EoZK+0qk7rKRVFVnliOD6yVvCcARYPHCnNtRe0V0oTpxCqST+akulVdSXVtE83sC9W8+70hcFzJd8TYZZizU5FaLRWMDFxQWoMwZGF4AzhIMSFpa3gjCjkVrHL5WSSVuv+3zQH22QkVe8zxknaVUN18LXCJb2l1Cp5bmaIZuyvLJWL+0AgEte2FDZMDJL3QkhnfTVf0KGRmMBALC44K4ve34WdYxJtdC1pLpCwrIB9SFSHVyJq6ESiJIkAEpfJdjHc9i49iYsr11OWZ7i6huNxiiVLFSq0aaF3eFm9dIOaovLOLl7CxfHt4Xx5AFqp9xVRzd+mOba7IlGwy3DxQW9ZtoZ94xyMxoNXanrZWs0HmF1ZUUY9vTFRey8wyh6AFECW+ghsggID9WiICyJH+y7S2Qur3lzs1Jyh51S40fBV5FP5EHfLdxqrY6dR9+ChaV1T/pSLKxcQ/csumDDvEpdH+barFoCv/Pd7wUAPPro4/jKn/13rRgLhQIcPYOBFHmavUSor2rsnk54UvvrJVyNF1WEvKn6FDQyidGPYtjvASCoVKvK/cRWL+0AFLj36vPonu1jYeUqABIh8MOgBafrm+Z4YgAAC4xJREFUjlG8890/DcAlaloQjFC0irDHUdtsqVRW6rmlUjZLgimSzWHMMdkFsOsdA6h8O160R/svodtq4vKNH49GYFALkRm4TBQ6m+CtbuygVl/G8eEttE5uAwAWVlxrBi+B5x06ykAeZBWhWCzCsYcoFNWdLmGnbAqmaKHEjaW5G79GAeCSONL22QHuAljduoFqdZF5QBQ5D/etefIC7qraqihGI3cSZdGqYOv6G0EdB+3mXiB916++CSd3XnoopK4Pvtieeuo9IFZZi6i66oEQBCDEL6l4iSdaERQFfP+LVbz5n6XPGpCwezrgSVno885/1XbzAO3mAa694amQvCYRwZW8MlilUiyKUqkUkBcAtnefwHljDQ/2vo1u8w66zTvY+bF3onm0h+7ZwUND3nc+9R4AwO7u6wEAxbJ6p5mvfMkjbG5SLySvjtlrGjC2ebC8K91KLpn9v3gOG9ffFHTagieUBE5ua8YeQVlbL0taH8vrl1FdWELz/m20T/dw8PI3sH7tLVjdvI7m0R46BuoDtUcgxcnrcT/z4+57PH5liJPNf5U+Io0m+/AwuteXVShg7PXOotOVqNSuboqs67k1DzRUBRm/KIDSd9QJFIsF2LaD04Pvg4BgaW07Hl9GfUhEVh6V2iK2d5/APQDt0z2c7H8HC6tXsbp5A7X6Ko7vvJQYx6TBkjVXSMqXJ2yWCKWdMq6y0xK2KZAtSlWBJ3AafhWLrj/ByYG7esnS2nY8DeHXkb+GH6gOr4WqA6msoVBqgNp9UCf5I8gL73zqPWicfVWLqOvD342cn5V/3Syx3EeN3brRtSLkSVgfltLBAunISwAUiqEDjG9eOTn4HobdM1y6+oZInP4z0xiW51UHN70iiLWIzUvruDg7Rq97nnu6jz3+BDYvXcLq6iUsL7uG+fWjLyU+x5M2ExIqsIBk98RoZGqMbTlhW0cbaGzKZwY3D8S7sftI1nFf835vxG+Vno2XgmvAjluwi1YRoED34h6O7wBLl66hzHTaIh3CoIAnY1dhVYdOJ1wmvVSuYH1zB+3WIs5O0jalIX6SM1XZw8mOvgWdMhUMitTdmHAhn8g4dI4AohDYKtICCcSNZMkjMCsUZSQtFOT+6bZto3txD92Le9h+9O0R8vqgQDiBc4LSd3v3CVw0H+DB4a3I9XpjBZVKzVj6Pvb4E9javoL19Q0sLxvORckALcKySBCWlld/egNo+VfU2e3kMIkr2cju1e65IVjysoS1rCLGY3HTY9s2isUi7rzyLVx97Cfk5AUASkOn8ZQY9t0ppP1eJ7jW716g25KvuOJL39HwUkBg6sStCrxUVSHXZj8lDu/qtyQFatJRnJIDvIcYcXXstDxkkjdGXuZh23av33nlW7i080TQaWMRfMuKMhl4pBwYkNIErPpwcdFGpVzC23/ip7C2voGVKUrVLDAhazboS9/W7QbqO+lXv9FeySYpnEw98D3mKRAb//ZxfCdqcfAhkpS9zjn6nTONHGtCtuUkh3pjBfWG26nKe3j1YcVoPJJYFpKlr6OQ5iu7yepCYudMlnxlL05UlXogi9unzfGd76HXOUfnIpmURY3pI/OJKSjuwmQzqFvOGCjojVNFiSwWCP2e4ZI1EghzJH3FFnMsWXlERV6R1xGAQM3onJ8AZLqk1BS4EfyvL/1x5Pzv/r1/ZJoqZkJeELU5jKazt8oW2u73+qjWqt5xPoT1YbFkNFEbyt+VhxZNqPOlq4y8wEyqE+m2tc4n5XTI4iybv8RPWh2+32NNgPrpJqkLwUo2Wp2yU/ePZuz3FIshsdl0yZSl7cMBh/szw+EhN/xEYdTMpB1NHI1HAlKH6R6/lG0XB/WCIKeIkVWH5DKwz7HknTbK5XLwRxWjO2nBqxLTxuHhQfAnBaWYhHOnmLCRhBOltA7c1RqhlqIiopb+nGSe8l0sFgOzGEj+GwCVNadLZ8WsiZpaBQhGeiLtHgAK2+t35Cle8iCsDwun8u/OpBh0ForIA3laFOwcC9IYZ5PQrVPEGRmm9BHWPKU0s0achrDJ5rA1+U1hMZwCtQck1eStYqGIsRPvmBWLBdiM+latuZMhk+byP3TIStYz4Ozqv8knLwJQOoJNbRSZzQJl/gojgT+0CDLSHn6xjCclsyD0hnwN9X2ygsQ+QrFoweZ0R78wLJ+8HPEr1RqKJbVnvwnKGp76TsJCdoeHh7hy5UpeWUqHHMdapOC+J1sgXHzo+D+ngQ5ZWVgkRcEQb6YvAVCU7OQoIq8KhYgPQPZmlHr/VHZ3ao/Am7LTO1jPB7Lkv0AKMYODv56EDmFHo5HRLAlTsrJI1SMq33ONEUVvtROZfltfXES704ldn9ZkxaRC5OXtw0ratPn+lfdeACD4T19tKMMlkXZSUliFVMQtCtR1mYStL7qeX72ewBc1Jzu4aAJfXvOjJofZzDV2ycoizINDHeMpgCrSJkngzv06Frfa0vsqaBGXz3P5djGYksOiWJRHV6tVI+QNRtI8kxjhxsOn8RWPR10Qa0k7vC/Z0uu90x4XdBEnqyHoGIClnf1pSOgIW9IXq96TPHl9zGIwwh7rWSweVvUhM1kBjMd2VA3UGJOfOGm99NNt0JcBtVo1qvcSgBSyNusz8rqaU6QlLaFxUo3HNtyG1CtjqnbUkUFEWEIQXZvbAMrJkgBABK1i6bn0W0f0en0UC0XYjp2LlhfVocQioV6vx66Nhn10cpoTmd5sNgu3Ihedxz8Rnnw1PB7bNiy/BfQqyLGHKFj+Ko/UiLwqCdu6U8Xidg46roikWpEUi8YE9MkL5CFxox00EVF5DAfeMpq+/maI/FSI6bUWEbIqECNvDNT75mbXwrm+CgaErd4jsO1xrCOWVnqaOO2IeqhplwQa9ONmOl1MRu+dDIF1ycpjbGtMCMhhPmBaWGmlrIi8qSHwsJ9/c9akkF19SE/WFL6+lHrZnS6Bc3XJYqVurVrJM2pDJFd+fwKLfgB5SWN96fvsp59JncqnP6VJcGcEQLGSudDLbLIwJm75jjdqliBtbcdBUTSBUqBTTMaBXF75owkszPGwqA8qsrpVk6XLrE/e8XiM07+wsP22dCkZE7f0cjxjEWXeA4GCvFPFPJrKTJvkbO+gJVm9+WYi8lJHY76Y5upDWVdq9KFN3KRv0Ccv/73aTtRNjkcai0K6Dlm08mcz4JpyvtiK+cevrQYIkFryKsibF2F9aBE3bQX7BSAjb7FQ1K5KXbLGtybiQQNT2DzJYCmmQNraQg2OPcKwHQ5c5EXevAnrI7FU+GyXvuRWt8plUUQI27HR8/dwYAKo1hmbFLKYwv46gTD/qROv77FtK81mSaS9+yWz1nZlN/xTStykb03HJEaSJoDrzjWLLOeo94gItj2ObPX5N1AjlLwhkmy8JovCiLCymxzGqHNWvTeBxjWNRSGhr5LkwD7sZXdASQ226T/LuKFYDqhpbNjnF7OMsH7/RmvQgoMOSUWQttP5ySQi5lce3wBl/jyYzLqYOlLoq7OALVjA0BmrLQtpSJsFEynJcnkGo16aywSMhpw7Y8plh/4qgJW2DufmGSfvfHVlhcSV1X/lTjw4+zqqr0762nkPPvyN+qpEdaEW/LEQ6f224wilb564uJNu83JtiavLB3WTQZSnMhhvtamQvnmPmg37fQw1drx8GOA4jnCd40mTNw2M7LjiUbO4ZWE4HHHqgsQeaLR6TbJZoVbj/CMEgzjDgWSZSQPME1Fl41QHd14DAOxcFWzekQBRbVF7CBRn6X8SRYw5sQxrRCIyi8XJmycMhkCFQWczbjYpsOT1CWv6HI95LyGzzlmyf3YEw2Ho/T4Yhp2gNOuF+YupRRdVE5gVZJjnWpgy+t1e8KcLarQfhD7OXk0nxZXEjdT1BlD6E7mEk91hycuGtA3MJ3prT+mRd9j3FwSer17ytCAjqy0wd81zCf1/4eL4QIlGKV8AAAAASUVORK5CYII="}/>
                        </div>

                        {/* Health Information */}
                        <div className="flex-1 leading-3">
                            <div className="gloww text-[18px] text-blue-300 my-1 pl-1 flex">
                                <div className={'w-32 truncate'}>{myName}</div>
                                <span className="text-lime-400">[GUILD]</span>
                            </div>

                            {/* Health Bar Background */}
                            <div className="w-full h-2.5 bg-gray-300 rounded-md overflow-hidden">
                                {/* Health Bar Filled */}
                                <div
                                    className={`${healthColor} h-full transition-all duration-300`}
                                    style={{width: `${health}%`}}
                                ></div>
                            </div>


                            {/* Health Bar Background */}
                            <div className="w-full h-2 bg-gray-300 rounded-md overflow-hidden mt-0.5">
                                {/* Health Bar Filled */}
                                <div
                                    className={`bg-orange-400 h-full transition-all duration-300`}
                                    style={{width: `${health}%`}}
                                ></div>
                            </div>


                            {/* Health Percentage */}
                            <div className="hidden text-sm text-white">
                                {health}%
                            </div>
                        </div>

                    </div>

                </div>

                <div className={'flex hidden'}>

                    <div
                        className={'w-10 h-10 mt-1 ml-0 border-4 border-opacity-60 hover:border-opacity-80 border-orange-400 bg-neutral-700'}>

                    </div>


                    <div
                        className={'w-10 h-10 mt-1 ml-1 border-4 border-opacity-60 hover:border-opacity-80 border-orange-400 bg-neutral-700'}>

                    </div>


                    <div
                        className={'w-10 h-10 mt-1 ml-1 border-4 border-opacity-60 hover:border-opacity-80 border-orange-400 bg-neutral-700'}>

                    </div>


                    <div
                        className={'w-10 h-10 mt-1 ml-1 border-4 border-opacity-60 hover:border-opacity-80 border-orange-400 bg-neutral-700'}>

                    </div>


                    <div
                        className={'w-10 h-10 mt-1 ml-1 border-4 border-opacity-60 hover:border-opacity-80 border-orange-400 bg-neutral-700'}>

                    </div>


                    <div
                        className={'gloww flex justify-center items-center text-orange-400 w-10 h-10 mt-1 ml-1 border-4 border-opacity-60 hover:border-opacity-80 border-orange-400 bg-neutral-700'}>
                        +56
                    </div>

                </div>



                <div className={'text-sm w-fit max-h-64 overflow-y-scroll'}>
                    peers:
                    {
                        Object.keys(peers).map(key => {
                            return (
                                <div key={key} onClick={() => {
                                    console.log(window.peerTargets[key])
                                    sendChat(JSON.stringify(window.peerTargets[key]))

                                    const tile = [window.peerTargets[key].position[0], window.peerTargets[key].position[2]]

                                    console.log(tile)

                                    window.playerRef.current.position.x = tile[0];
                                    window.playerBoxRef.position.x = tile[0];
                                    window.playerRef.current.position.z = tile[1];
                                    window.playerBoxRef.position.z = tile[1];



                                }} className={'w-fit px-1 my-1 bg-neutral-800 bg-opacity-70 flex'}>
                                    <div>
                                        id: <span className={'text-orange-400 gloww'}>{key}</span>
                                    </div>

                                    <div className={'pl-2 gloww'}>
                                        @ <span className={'text-orange-300 font-mono'}>{locations[key]}</span>.bitmap
                                    </div>
                                </div>
                            )
                        })
                    }
                </div>
            </div>
        </DragContainer>
    );
};


export const HealthControl = () => {
    const health = useStore(healthStore).health;

    const increaseHealth = () => {
        setHealth((current) => Math.min(current + 10, 100));
    };

    const decreaseHealth = () => {
        setHealth((current) => Math.max(current - 10, 0));
    };

    return (
        <DragContainer id={'HealthControl'}>
            <div className="flex space-x-4 mt-4">
                <button
                    onClick={decreaseHealth}
                    className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600 transition-colors"
                    aria-label="Decrease Health"
                >
                    Decrease Health
                </button>
                <button
                    onClick={increaseHealth}
                    className="px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 transition-colors"
                    aria-label="Increase Health"
                >
                    Increase Health
                </button>
            </div>
        </DragContainer>
    );
};
