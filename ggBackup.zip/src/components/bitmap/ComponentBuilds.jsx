import {componentBuildStore, currentBitmapStore, transformModeStore} from "../../modules/stores.mjs";
import {useStore} from "statery";

import {boxelGeometry} from 'boxels-shader';
import {Billboard, Bvh, Outlines, Text, TransformControls} from "@react-three/drei";
import React, {useEffect, useRef, useCallback, useMemo, useState} from "react";
import {useThree} from "@react-three/fiber";
// import {getBitmapFromCoordinates} from "../../modules/utils.mjs";
import * as THREE from 'three'
import {DynamicComponent} from "./DynamicComponent.jsx";


window.transformSettings = {
    translationSnap: 0.001,
    rotationSnap: 0.001,
    scaleSnap: 0.001,
};
let throttleTimeout = null; // To manage the throttle period
let pendingComponents = null; // To store the latest components during the throttle period

window.sendComponentBuilds = (components) => {
    pendingComponents = components; // Always update the latest components

    // pendingComponents.forEach(c => c.selected = false)

    if (!throttleTimeout) {
        // Send immediately if not throttling
        Object.values(window.connections).forEach((conn) => {
            console.log('sending builds to ' + conn.peer);
            console.log(pendingComponents);

            let s = JSON.stringify({
                type: 'buildUpdate',
                components: pendingComponents,
            })

            conn.send(
               s
            );
        });

        // Start the throttle timer
        throttleTimeout = setTimeout(() => {
            // Send the latest components after the throttle period
            if (pendingComponents) {
                Object.values(window.connections).forEach((conn) => {
                    console.log('sending builds to ' + conn.peer);
                    console.log(pendingComponents);

                    conn.send(
                        JSON.stringify({
                            type: 'buildUpdate',
                            components: pendingComponents,
                        })
                    );
                });
            }

            throttleTimeout = null;
            pendingComponents = null;
        }, 100);
    }
};

window.updateComponentBuilds = (components) => {

    componentBuildStore.set((prev) => {
        // Create a map of existing components for quick lookup
        const existingComponentsMap = new Map(
            prev.componentBuilds.map((comp) => [comp.id, comp])
        );

        const updatedComponents = components.map((comp) => {
            // If the component exists, merge it with the updated data
            if (existingComponentsMap.has(comp.id)) {
                return {...existingComponentsMap.get(comp.id), ...comp};
            }
            // Otherwise, it's a new component
            return comp;
        });

        // Combine and ensure no duplicates
        const updatedComponentSet = new Map(
            [...prev.componentBuilds, ...updatedComponents].map((comp) => [comp.id, comp])
        );

        return {
            componentBuilds: Array.from(updatedComponentSet.values()),
        };
    });
}

export const setSelectedComponent = (id) => {
    const arr = Array.from(componentBuildStore.state.componentBuilds);
    for (let i = 0; i < arr.length; i++) {
        arr[i].selected = arr[i].id === id;

        if (arr[i].selected && arr[i].jsx) {

            window.editor.setValue('\n   🟧')
            editor.moveCursorTo(0, 0);

            setTimeout(() => {
                window.editor.setValue('\n   🟧 🟧')
                editor.moveCursorTo(0, 0);
            }, 100)

            setTimeout(() => {
                window.editor.setValue('\n   🟧 🟧 🟧')
                editor.moveCursorTo(0, 0);
            }, 200)

            setTimeout(() => {
                window.editor.setValue(arr[i].jsx)
                editor.moveCursorTo(0, 0);
            }, 300)
        }
    }

    componentBuildStore.set({componentBuilds: arr});

    if (id && window.transformControlsRef?.current) {
        window.transformControlsRef.current.enabled = true
        window.transformControlsRef.current.size = 0.8
    }

};

window.setSelectedComponent = setSelectedComponent


const ScriptedComponent = ({c}) => {

    return (
        <mesh
            onClick={(e) => {
                e.stopPropagation();
                setSelectedComponent(c.id);
                // console.log(c)
            }}
            position={[0, 0, 0]}
            geometry={boxelGeometry}
        >
            <meshStandardMaterial color={'#ff9900'} flatShading/>
            {c.selected ? <Outlines/> : null}
        </mesh>
    )
}


// // Custom Scripted Component Rendering
// const DynamicComponent = ({ c }) => {
//     const { Component, error } = useMemo(() => {
//         try {
//
//             const cc = `const DefaultComponent = () => {
//     return (
//         <mesh>
//             <torusGeometry />
//             <meshNormalMaterial />
//         </mesh>
//     )
// }
// `
//
//             const transpiledCode = Babel.transform(cc, {
//                 presets: ["react"],
//             }).code;
//
//             console.log('transpiledCode')
//             console.log(transpiledCode)
//
//             // Dynamically create a functional React component
//             const Component = new Function(
//                 "React",
//                 "THREE",
//                 `return ${transpiledCode}`
//             )(React, THREE);
//
//             console.log(Component)
//             return { Component };
//         } catch (e) {
//             console.error("Error transpiling code:", e);
//             return { error: e };
//         }
//     }, [c]);
//
//     if (error) return <mesh><boxGeometry /><meshBasicMaterial color="red" /></mesh>;
//     return <Component />;
// };


export const ComponentBuilds = () => {
    const {componentBuilds} = useStore(componentBuildStore);

    const transformControlsRef = useRef();
    const {camera, gl, controls} = useThree();
    const groupRef = useRef();

    useEffect(() => {
        window.transformControlsRef = transformControlsRef
    }, [])


    const saveComponentTransform = useCallback(() => {
        const selectedComponent = componentBuilds.find((b) => b.selected);
        if (selectedComponent && transformControlsRef.current) {
            const object = transformControlsRef.current.object;
            if (object) {
                const {position, rotation, scale} = object;
                componentBuildStore.set((prev) => ({
                    componentBuilds: prev.componentBuilds.map((comp) => {

                            let compFinal = comp.id === selectedComponent.id
                                ? {
                                    ...comp,
                                    position,
                                    rotation,
                                    scale,
                                    // bitmap: getBitmapFromCoordinates(
                                    //     Math.floor(position.x / 100),
                                    //     Math.floor(position.z / 100),
                                    // )
                                }
                                : comp


                            sendComponentBuilds([compFinal])

                            return compFinal
                        }
                    ),
                }));

            }
        }
    }, [componentBuilds]);

    const lastComponentId = useRef('')

    // Attach the TransformControls to the selected mesh after it's fully mounted
    useEffect(() => {
        const selectedComponent = componentBuilds.find((b) => b.selected);

        if (selectedComponent && transformControlsRef.current) {

            if (lastComponentId.current !== selectedComponent.id) {
                lastComponentId.current = selectedComponent.id
                transformControlsRef.current.size = 0.2
                setTimeout(() => {
                    transformControlsRef.current.size = 0.4
                }, 100)
                setTimeout(() => {
                    transformControlsRef.current.size = 0.6
                }, 200)
                setTimeout(() => {
                    transformControlsRef.current.size = 0.8
                }, 300)
                setTimeout(() => {
                    transformControlsRef.current.enabled = true
                }, 400)
            }


            const object = groupRef.current.getObjectByName(selectedComponent.id.toString());
            if (object?.parent) {
                transformControlsRef.current.attach(object);

                // Disable orbit controls while transforming
                const callback = (event) => (controls.enabled = !event.value);
                transformControlsRef.current.addEventListener('dragging-changed', callback);

                return () => {
                    transformControlsRef.current.removeEventListener('dragging-changed', callback);
                };
            }
        } else if (transformControlsRef.current) {
            transformControlsRef.current.enabled = false
            transformControlsRef.current.size = 0
            transformControlsRef.current.detach();
        }
    }, [componentBuilds, controls]);

    // Add keyboard event listeners to change TransformControls mode
    useEffect(() => {
        const handleKeyDown = (e) => {
            const key = e.key.toLowerCase();
            if (transformControlsRef.current) {
                if (key === 'm' || key === 'g') {
                    transformControlsRef.current.setMode('translate');
                    transformModeStore.set({transformMode: 'translate'})
                } else if (key === 'r') {
                    transformControlsRef.current.setMode('rotate');
                    transformModeStore.set({transformMode: 'rotate'})
                } else if (key === 's') {
                    transformControlsRef.current.setMode('scale');
                    transformModeStore.set({transformMode: 'scale'})
                }
            }
        };

        window.addEventListener('keydown', handleKeyDown);

        return () => {
            window.removeEventListener('keydown', handleKeyDown);
        };
    }, []);

    return (
        <group ref={groupRef}>
            <Bvh>

                <TransformControls
                    size={0}
                    ref={transformControlsRef}
                    args={[camera, gl.domElement]}
                    {...transformSettings}
                    onObjectChange={saveComponentTransform}
                />

                {componentBuilds.map((c) => (
                    <>
                        <group
                            key={c.id}
                            name={c.id.toString()}
                            position={[c.position?.x || 0, c.position?.y || 0, c.position?.z || 0]}
                            rotation={[c.rotation?._x || 0, c.rotation?._y || 0, c.rotation?._z || 0]}
                            scale={[c.scale?.x || 1, c.scale?.y || 1, c.scale?.z || 1]}
                            onClick={(e) => {
                                e.stopPropagation()
                                setSelectedComponent(c.id)
                            }}
                        >
                            {c.selected ? (
                                <Billboard>
                                    <Text
                                        outlineOpacity={1}
                                        renderOrder={6}
                                        outlineColor={'#111'}
                                        color={'#9aec15'}
                                        outlineWidth={0.05}
                                        font={'https://ordinals.com/content/74eed71c46430c38e056ef1bc69ad2c521293a8941d2177b52e7d447b42d5522i0'}
                                        fontSize={0.35}
                                        position={[0, 1.7, 0]}
                                    >
                                        {'component ' + c.name}
                                    </Text>
                                </Billboard>
                            ) : null}

                            <DynamicComponent {...c} />
                        </group>


                    </>

                ))}

            </Bvh>
        </group>
    );
};
