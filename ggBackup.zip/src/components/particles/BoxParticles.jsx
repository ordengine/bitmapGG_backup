import {useFrame} from "@react-three/fiber"
import {composable, modules} from "material-composer-r3f"
import {chance, upTo} from "randomish"
import {forwardRef, useEffect, useImperativeHandle, useRef, useState} from "react"
import {OneMinus} from "shader-composer"
import {Color, Mesh, NormalBlending, Vector3} from "three"
import {
    Emitter,
    InstancedParticles,
    useParticleAttribute,
    useParticleLifetime
} from "vfx-composer-r3f"
import {useControls} from "leva";

const tmpVec3 = new Vector3()


export const BoxParticles = () => {
    // const mesh = useRef(null)
    // const mesh2 = useRef(null)
    //
    // const emit1 = useRef(null)
    // const emit2 = useRef(null)
    //
    // useEffect(() => {
    //     window.particleMesh1 = mesh
    //     window.particleMesh2 = mesh2
    //
    //     window.emit1 = emit1
    //     window.emit2 = emit2
    // }, [])

    const lifetime = useParticleLifetime()
    const velocity = useParticleAttribute(() => new Vector3())
    const color = useParticleAttribute(() => new Color())

    useFrame(({clock}) => {
        const t = clock.elapsedTime
        // mesh.current.position.set(
        // Math.sin(t * 5) * Math.cos(t) * 2.5,
        // 6 + Math.cos(t * 3) * Math.abs(Math.sin(t) * 5),
        // Math.sin(t * 3.3) * 1.5
        // )

        // mesh.current.rotation.set(
        //     Math.sin(t * 5) * Math.cos(t) * 1.5,
        //     3 + Math.cos(t * 3) * Math.sin(t),
        //     Math.sin(t * 3.3) * 1.5
        // )
    })


    const Emit = forwardRef(({}, ref) => {

        const emitterRef = useRef()

        const [rate, setRate] = useState(222)

        useImperativeHandle(ref, () => {
            return {
                setRate,
                ref,
                emitterRef
            };
        }, []);

        const [{particleSize, strength}] = useControls('particle trail', () => ({
            particleSize: {
                value: 1,
                min: 0,
                max: 10,
                step: 0.1
            },
            strength: {
                value: 1,
                min: 0,
                max: 10,
                step: 0.1
            }
        }))

        return (
            <Emitter
                ref={emitterRef}
                rate={rate}
                setup={({mesh, position, scale}) => {
                    /*
                    The position automatically inherits the emitter's position, but let's
                    add a little random offset to spice things up!
                    */
                    position.add(tmpVec3.randomDirection().multiplyScalar(upTo(0.12)))

                    scale.set(particleSize * 0.25, particleSize * 0.25, particleSize * 0.25)

                    color.write(mesh, (v) =>
                        chance(0.5) ? v.setRGB(3, 1, 0) : v.setRGB(22.3, 11.3, 0.3)
                    )
                    lifetime.write(mesh, 3)
                    velocity.write(mesh, (v) =>
                        v.randomDirection().multiplyScalar(upTo(strength * 0.5))
                    )
                }}
            />
        )
    })


    function EmitMesh({id}) {

        const ref = useRef()
        const emitRef = useRef()

        useEffect(() => {
            window[id] = emitRef
            // console.log(id)
            // console.log(window[id])
        }, [id])

        return (
            <group ref={ref} position={[0, 0, 0]}>
                <boxGeometry args={[0.1, 0.1, 0.1]}/>
                <meshStandardMaterial color="#ff9900"/>
                <Emit ref={emitRef} />
            </group>
        );
    }

    useEffect(() => {
        // window.particle
    }, [])



    return (
        <InstancedParticles frustumCulled={false} capacity={1000}>
            <boxGeometry args={[0.22, 0.22, 0.22]}/>

            <composable.meshStandardMaterial
                color={new Color(0.5, 0.5, 0.5)}
                blending={NormalBlending}
                transparent
            >
                {/*<modules.Billboard />*/}
                <modules.Velocity direction={velocity} time={lifetime.age}/>
                <modules.Acceleration
                    direction={new Vector3(0, 0, 0)}
                    time={lifetime.age}
                />
                <modules.Alpha alpha={OneMinus(lifetime.progress)}/>
                {/*<modules.Scale scale={OneMinus(lifetime.progress)} />*/}
                <modules.Color color={color}/>
                <modules.Lifetime {...lifetime} />

                <modules.SurfaceWobble amplitude={0.1} frequency={2.1}/>
            </composable.meshStandardMaterial>

            {
                new Array(3).fill(1).map((a, i) => {
                    return <EmitMesh id={'emit' + i} key={'emit' + i} />
                })
            }



        </InstancedParticles>
    )
}
