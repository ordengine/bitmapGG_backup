import {useStore} from "statery";
import {myTextureStore} from "../../modules/stores.mjs";
import {Player} from "./Player.jsx";
import InscribedSpaceAvatar from "./avatars/InscribedSpaceAvatar.jsx";
import {useEffect, useState} from "react";
import {BoxelAvatar} from "./avatars/BoxelAvatar.jsx";
import {Box} from "@react-three/drei";

export const CustomPlayer = () => {

    const {myTexture} = useStore(myTextureStore)

    const [show, setShow] = useState(true)

    useEffect(() => {
        setShow(false)

        setTimeout(() => {
            setShow(true)
        }, 200)
    }, [myTexture, setShow])

    return !show ? null : (

        <Player>
            {/*<Box />*/}
            {/*<BoxelAvatar />*/}
            <InscribedSpaceAvatar player={true} texture={myTexture} />
        </Player>
    )

}
