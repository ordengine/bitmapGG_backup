import {useCallback, useEffect, useMemo, useRef} from "react";
import {shaderMaterial} from "@react-three/drei";
import * as THREE from 'three'
import {useFrame, useThree, extend} from "@react-three/fiber";

import {getElevation, getMaterial} from '../../modules/getElevation.mjs'
import {currentTileStore, getHeightMap, getTileHeight} from "../../modules/stores.mjs";


// Cache for loaded spots
window.tileCache = new Map();

function makeGeometry() {
    const vertices = [
        // top
        {pos: [0.5, 0.5, -0.5], uvn: [0, 0, 0]},
        {pos: [-0.5, 0.5, -0.5], uvn: [1, 0, 0]},
        {pos: [0.5, 0.5, 0.5], uvn: [0, 1, 0]},
        {pos: [-0.5, 0.5, 0.5], uvn: [1, 1, 0]},
        // bottom
        {pos: [0.5, -0.5, 0.5], uvn: [0, 0, 5]},
        {pos: [-0.5, -0.5, 0.5], uvn: [1, 0, 5]},
        {pos: [0.5, -0.5, -0.5], uvn: [0, 1, 5]},
        {pos: [-0.5, -0.5, -0.5], uvn: [1, 1, 5]},
        // left
        {pos: [-0.5, -0.5, 0.5], uvn: [0, 0, 2]},
        {pos: [-0.5, -0.5, -0.5], uvn: [1, 0, 2]},
        {pos: [-0.5, 0.5, 0.5], uvn: [0, 1, 2]},
        {pos: [-0.5, 0.5, -0.5], uvn: [1, 1, 2]},
        // right
        {pos: [0.5, -0.5, -0.5], uvn: [0, 0, 1]},
        {pos: [0.5, -0.5, 0.5], uvn: [1, 0, 1]},
        {pos: [0.5, 0.5, -0.5], uvn: [0, 1, 1]},
        {pos: [0.5, 0.5, 0.5], uvn: [1, 1, 1]},
        // front
        {pos: [0.5, -0.5, 0.5], uvn: [0, 0, 3]},
        {pos: [-0.5, -0.5, 0.5], uvn: [1, 0, 3]},
        {pos: [0.5, 0.5, 0.5], uvn: [0, 1, 3]},
        {pos: [-0.5, 0.5, 0.5], uvn: [1, 1, 3]},
        // back
        {pos: [-0.5, -0.5, -0.5], uvn: [0, 0, 4]},
        {pos: [0.5, -0.5, -0.5], uvn: [1, 0, 4]},
        {pos: [-0.5, 0.5, -0.5], uvn: [0, 1, 4]},
        {pos: [0.5, 0.5, -0.5], uvn: [1, 1, 4]},
    ]
    const positions = []
    const uvn = []
    for (const vertex of vertices) {
        positions.push(...vertex.pos)
        uvn.push(...vertex.uvn)
    }
    const geometry = new THREE.BufferGeometry()
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(new Float32Array(positions), 3).setUsage(35044)) // 35044 = StaticDrawUsage
    geometry.setAttribute('uvn', new THREE.Float32BufferAttribute(new Float32Array(uvn), 3).setUsage(35044))
    geometry.setIndex([
        // top
        0, 1, 2, 2, 1, 3,
        // bottom
        // 4, 5, 6, 6, 5, 7,
        // left
        9, 8, 10, 9, 10, 11,
        // right
        13, 12, 14, 13, 14, 15,
        // front
        17, 16, 18, 17, 18, 19,
        // back
        21, 20, 22, 21, 22, 23,
    ])

    window.geometry = geometry
}

makeGeometry()


function generateRings(spotX, spotY, lod) {
    const spots = [];

    // Add the center spot
    spots.push([spotX, spotY, 1, 9]);

    // Loop over each level (ring)
    for (let level = 1; level <= lod; level++) {
        let range = level;

        for (let x = -range; x <= range; x++) {
            for (let y = -range; y <= range; y++) {
                // Check if the current position is on the edge of the square ring
                if (
                    x === -range || x === range ||
                    y === -range || y === range
                ) {
                    spots.push([
                        spotX + x,
                        spotY + y,
                        level < 2 ? 1 : level < 5 ? 2 : 8
                    ]);
                }
            }
        }
    }

    // Adjust the level of detail (LOD) for outermost ring spots
    spots.forEach(spot => {
        const [x, y] = spot;
        if (
            x === spotX - lod || x === spotX + lod ||
            y === spotY - lod || y === spotY + lod
        ) {
            spot[2] = lod;
        }
    });

    return spots;
}

export const Terrain = ({zoneSize = 50}) => {
    const meshRef = useRef()
    const instancedGeometry = useRef()


    useEffect(() => {
        if (meshRef.current) {
            window.terrainMesh = meshRef.current
        }
    }, [])

    const TerrainMaterial = shaderMaterial(
        {
            time: 0,
            zoom: 1,
            playerPos: new THREE.Vector3(),
            playerLagPos: new THREE.Vector3()
        },
        `
        precision mediump int;
        precision mediump float;
    uniform float time;
    attribute vec4 worldPos;
    attribute vec4 level1;
    attribute vec4 level2;
    attribute vec3 uvn;
    varying vec2 vUv;
    varying float vNormal;
    varying vec4 vWorldPos;
    varying vec3 vPos;
    varying vec4 vLevel1;
    varying vec4 vLevel2;
    uniform vec3 playerLagPos;
    uniform vec3 playerPos;
    
    
    float random (in vec2 st) {
    return fract(sin(dot(st.xy,vec2(12.9898,78.233))) * 43758.5453123);
}
float snoise (in vec2 st) {
    vec2 i = floor(st);
    vec2 f = fract(st);
    float a = random(i);
    float b = random(i + vec2(1.0, 0.0));
    float c = random(i + vec2(0.0, 1.0));
    float d = random(i + vec2(1.0, 1.0));
    vec2 u = f*f*(3.0-2.0*f);

    return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}

    
    void main() {
      vUv = uvn.xy;
      vNormal = uvn.z;
      vLevel1 = level1;
      vLevel2 = level2;
      vec3 finalPosition = worldPos.xyz;
      //
      // finalPosition.y -= 1. - lodScale;
      float lodScale = worldPos.w;
      if (lodScale > 1.) {
        finalPosition.x += 0.5;
        finalPosition.z += 0.5;
      }
      
      vec3 scale = vec3(lodScale, 1.0, lodScale);
      
      
      finalPosition += position * scale;
      
      // if (worldPos.y > 4. && position.y < 0.) {
      //   scale.y = worldPos.y * 1.5;
      // }
      
      
      if (position.y > 0.) {
        finalPosition.y = level1.y;
      }
      
      if (position.y < 0.) {
        finalPosition.y = level1.x;
         // - ((1.+lodScale) * 0.5);
      }
      
      if (lodScale > 4.) {
        // finalPosition.xz += 50.;
      }
      
      vWorldPos = worldPos;
      
      
    float dist = distance(vWorldPos.xz, playerPos.xz);
      
    float distLag = distance(vWorldPos.xz, playerLagPos.xz);

if (worldPos.y < 0.5) {
    // finalPosition.y += sin(dist + time * 0.005) * 0.2 + (distLag - dist) * 1. ;
}

    



if (worldPos.y <= 0.5 && position.y > 0.) {

    if (distLag < 2.) {
        finalPosition.y += sin(dist - time * 0.003) * 0.5;
    }
    
finalPosition.y +=  (-0.6 + 0.5 * snoise(-worldPos.zx * vec2(2., 1.) * 0.2 + (time * 0.001)) * 1.5 + 0.7) * smoothstep(0.5, 0.0, worldPos.y);

// finalPosition.y -=  -0.6 + 0.8 * snoise(worldPos.xz * 1.1 + (time * 0.001));
}

//       if (worldPos.y < 0.01 && position.y < 0.) {
// finalPosition.y -= (smoothstep(1.2, 0., distLag) - smoothstep(1.2, 0., dist)) * 1.5 + 0.7;
//       }


      
      vPos = finalPosition;
      gl_Position = projectionMatrix * modelViewMatrix * vec4((finalPosition.xyz), 1.0);
    }
  `,
        `
        precision mediump int;
        precision mediump float;
    uniform float time;
    uniform float zoom;
    uniform vec3 playerPos;
    uniform vec3 playerLagPos;
    varying vec2 vUv;
    varying vec4 vWorldPos;
    varying float vNormal;
    varying vec3 vPos;
    varying vec4 vLevel1;
    
    float random (in vec2 st) {
    return fract(sin(dot(st.xy,vec2(12.9898,78.233))) * 43758.5453123);
}

float snoise (in vec2 st) {
    vec2 i = floor(st);
    vec2 f = fract(st);
    float a = random(i);
    float b = random(i + vec2(1.0, 0.0));
    float c = random(i + vec2(0.0, 1.0));
    float d = random(i + vec2(1.0, 1.0));
    vec2 u = f*f*(3.0-2.0*f);

    return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}

vec4 toLinear(vec4 sRGB)
{
    bvec3 cutoff = lessThan(sRGB.rgb, vec3(0.04045));
    vec3 higher = pow((sRGB.rgb + vec3(0.055))/vec3(1.055), vec3(2.4));
    vec3 lower = sRGB.rgb/vec3(12.92);
    return vec4(mix(higher, lower, cutoff), sRGB.a);
}

float roundedSquare(vec2 uv, vec2 center, float size, float radius) {
    vec2 p = abs(uv - center) - size + radius;
    float dist = length(max(p, 0.0)) + min(max(p.x, p.y), 0.0) - radius;
    return dist;
}

    void main() {
    float height = vWorldPos.y;
    
    vec2 world = vWorldPos.xz + vUv;
   
       if (vNormal > 2.) {
       
       world = vWorldPos.xz + vUv * vec2(1.0, height / 2.);
    } else if (vNormal > 0.) {
       
       world = vWorldPos.zx + vUv * vec2(1.0, height / 2.);
    }
    
    float tree = vWorldPos.w;
    
    vec3 c = vec3(1.0);
    vec3 grass = vec3(0.486, 0.988, 0.0);
    vec3 sand = vec3(1.0, 0.6, 0.0);
    // vec3 sand = vec3(0.3761, 0.3698, 0.3502);
    vec3 water = vec3(0.282, 0.733, 1.1);
    
    float dist = distance(vWorldPos.xz, playerPos.xz);
    
    float distSmooth = smoothstep(200., 0., dist);
    
    float noise5x = snoise(vec2(mod(world.x, 200.) * -3.2, mod(world.y, 200.) * -3.2));
    float noise8x = snoise(vec2(mod(world.x, 200.) * -2.76, mod(world.y, 200.) * -2.76));
    float noise12x = snoise(vec2(mod(world.x, 200.) * 1.36, mod(world.y, 200.) * 1.36));
    float noiseSmallgrass = snoise(vec2(mod(world.x, 40.) * -5., mod(world.y, 40.) * -5.) * 0.);
   
    if (height < 0.) {
        // ROCK //
        
        c = sand/2.;
        if (noise5x > 0.5) {c *= 0.93;}
        if (noise8x > 0.6) {c *= 0.95;}
            
        c.b += abs(sin(world.x/2.)) * 0.1;
        c.r += abs(sin(world.y/4.)) * 0.1;
        
    } else if (height >= 2.2) {
        // GRASS //
        
        c = grass;
        //main
        
    if (noise5x > 0.5) {
    float fadeFactor = mix(1.0, 0.86, distSmooth); 
    c *= fadeFactor;
}
        if (noise8x > 0.4) {c *= 0.9;}
        if (noise12x > 0.5) {c *= 0.93;}
        if (noiseSmallgrass > 0.5) {c *= 0.86;}

        // elevation green/yellow stuff
        if (height < 3.) {
            c *= height * 0.4;
        } else {
                 // c = mix(c, vec3(1.2, 0.5, 0.), min(0.1, smoothstep(-1.5, 15.0, vPos.y))); 

            c.r *= height * abs(noise8x)*0.1 * smoothstep(-144., 200.0, vPos.y);
            c.g += height * abs(noise12x)*abs(sin(time * 0.0005)*0.011) * smoothstep(-144., 200.0, vPos.y);
            c.b += height * 0.043 * smoothstep(-144., 200.0, vPos.y);
        
        } 
        
        if (height > 5. && vPos.y > height - 25.) {
        if (vNormal == 0.) {
                 c = mix(c, vec3(3.0, 1.0, 0.), smoothstep(height-25., height, vPos.y) * 0.1); 

        } else {
                 c = mix(c, vec3(3.0, 1.0, 0.), smoothstep(height-25., height, vPos.y) * 0.25); 

        }
        }
        
        c *= 1. - (vNormal * 0.1);

   if (height > 9. && vPos.y < 20.) {

    // Create a square grid pattern
    float gridSize = 1.1; // Adjust this value for larger or smaller grid squares
    float lineWidth = 0.1; // Thickness of the grid lines

    // Calculate the grid lines with hard edges
    float gridX = step(lineWidth, abs(mod(vPos.y, gridSize) - gridSize * 0.5));
    float gridY = step(lineWidth, abs(mod(vPos.z + vPos.x, gridSize) - gridSize * 0.5));
    

    // Combine grid lines to form a grid
    float gridPattern = gridX * gridY;
    
    c = mix(c, vec3(0.0, 0.5, 0.), step(-0.5, vPos.y) * 0.22 * smoothstep(20., 0., vPos.y));

}

        if (height == 10.5) {
         c = mix(c, vec3(0.7, 0.4, 1.2), smoothstep(0.5, 15.0, vPos.y) * 0.8); 
        }
        
        
        c.g += smoothstep(3., 10., height) * 0.03;
        c.b += smoothstep(3., 10., height) * 0.02;
        c.r += smoothstep(3., 10., height) * 0.01;
        
        c *= 0.9;

    } else if (height > 0.4) {
        // SAND //
        c = sand;

        //main
        if (noise5x > 0.5) {c *= 0.93;}
        if (noise8x > 0.6) {c *= 0.95;}

        // closer to water big darkening
        float sandNoiseBig = snoise(world * 2.);
        float sandDarkenDown = 0.85;
        sandDarkenDown += height / 9.;
        if (sandDarkenDown > 1.) {
            sandDarkenDown = 1.;
        }
        if (sandNoiseBig > 0.4) {
            c *= sandDarkenDown;
        }
        
        c *= 0.6 + (height) * 0.2;

    } else {
        // WATER
        c = water;

        //underwater sand
        if (height > 0.) {
            c  *= (0.1 - (height * 0.6)) + 0.9;
            if (noise5x > 0.5) {c *= 0.93;}
            if (noise8x > 0.6) {c *= 0.95;}
        }

        float waterNoise = fract(time * 0.00004 + noise5x);
        float smallWaterNoise = fract(time * 0.000111 + noise8x);
        float waves = abs(sin((world.x / 2.) * (world.y / 12.) - (1. - time) * 0.0003));

        if (smallWaterNoise > 0.5) {
            // c /= 0.94;
        }

        if (waves > 0.5) {
            if (waterNoise > 0.2) {c *= 0.995;}
            if (waterNoise > 0.5) {c *= 0.995;}
            if (waterNoise > 0.92) {c *= 1.2;}
        } else {
            if (waterNoise > 0.2) {c /= 0.995;}
            if (waterNoise > 0.5) {c /= 0.995;}
            if (waterNoise > 0.92) {c *= 1.4;}
        }

        if (waves > 0.998) {
            if (smallWaterNoise > 0.7) {
                // c *= 4.4;
            }
            // c += waves/40.;

        } else {
            // c -= waves/40.;
        }
        c *= 0.8;
    }
    
    // darken
    // c /= (dist * 0.09 + 0.8);       
   
    
    float d2 = distance(vWorldPos.xz - (vUv*-vec2(-1., 1.) + vec2(-0.4, 0.4)), playerPos.xz);
    
    if (vNormal == 0. && d2 < 0.99) {
        c *= smoothstep(-0.3, 0.99, d2);
    } 
   
    float a = 1.0;
    
     a -= smoothstep(300.0, 350.0, vWorldPos.x - playerPos.x);
     a -= smoothstep(300.0, 350.0, playerPos.x - vWorldPos.x);
     //
     a -= smoothstep(300.0, 350.0, vWorldPos.z - playerPos.z);
     a -= smoothstep(300.0, 350.0, playerPos.z - vWorldPos.z);
     
   c -= (1. - a) * 0.2;
   
   
    a -= smoothstep(100., 3000., zoom);
    
    if (height > 4.5 && height < 6.5) {
        c *= 0.86;
    }
    
    if (a < 0.0) {
        a = 0.0;
    }
        
    if (tree < 0.) {
        c *= 0.4;
        c.r += 2.8;
        c.g += 1.1;
        c.b += 0.1;
    }
    
    if (tree > 1.) {
    // c *= 0.9;
    }
    
    // a=1.;
    
    float material = vLevel1.z;
    
    if (material == 1.) {
        c.r += 0.5;
    } else if (material == 2.) {
        c.b += 1.2;
        c.g -= 0.4;
        c.r -= 0.3;
        c *= 1.4;
    } 
    
    if (material == 3.) {
   
        c.b += 0.3;
        c.g -= 0.2;
    }
    
    c *= 0.82;
    
    gl_FragColor = toLinear(vec4(c, a));
    }
  `,
        (mat) => {
            mat.transparent = true
        }
    );

    extend({TerrainMaterial})

    const tileGeometry = useMemo(() => window.geometry, [])

    const lastTileX = useRef(-1)
    const lsatTileY = useRef(-1)

    // NEW: Cache for loaded spots
    const loadedSpotsRef = useRef(new Set());

    const printTiles = useCallback(() => {
        const spotX = Math.floor(currentTileStore.state.currentTile.x / 50);
        const spotY = Math.floor(currentTileStore.state.currentTile.y / 50);

        const spots = generateRings(spotX, spotY, 7);

        let num = 0;

        // console.log('print')
        // const bitmap = parseInt((spotX * 1000) + spotY);

        // console.log('BIMAP: ' + bitmap)





        spots.forEach((spot) => {
            if (spot === null) return;


            let index = 0;
            for (let i = 0; i < zoneSize; i += 1) {
                for (let j = 0; j < zoneSize; j += 1) {
                    index += 1;

                    const x = i + spot[0] * zoneSize;
                    const y = j + spot[1] * zoneSize;

                    let lod = spot[2] || 1;

                    if (x % lod === 0 && y % lod === 0) {
                        const key = `${x},${y},${lod}`;

                        // Check if tile data is already cached


                        // let ind = xyToIndex(i, j, 100)


                        // initializeBitmap(bitmap)
                        // const height = getTileHeight(bitmap, ind)


                        // let buildHeight = height || 0

                        // if (buildHeight) {
                            // console.log(buildHeight)
                        // }


                        if (!tileCache.has(key)) {

                            const material = getMaterial(x, y);
                            const elev = getElevation(x, y);

                            let lowestNearElev = elev;
                            const elevations = [
                                getElevation(x + lod, y),
                                getElevation(x - lod, y),
                                getElevation(x, y - lod),
                                getElevation(x, y + lod),
                            ];
                            elevations.forEach((e) => {
                                if (e < lowestNearElev) {
                                    lowestNearElev = e;
                                }
                            });

                            const tileData = {
                                worldPos: [x, elev, y, lod],
                                level1: [lowestNearElev, elev, material, 0],
                            };

                            // Cache the tile data
                            tileCache.set(key, tileData);
                        } else {
                            // console.log('cache')
                        }

                        const tileData = tileCache.get(key);


                        // if (buildHeight) {
                        //     tileData.worldPos[1] += buildHeight
                        //     tileData.level1[1] += buildHeight
                        // }


                        // Update geometry attributes
                        instancedGeometry.current.attributes.worldPos.array[num] = tileData.worldPos[0];
                        instancedGeometry.current.attributes.worldPos.array[num + 1] = tileData.worldPos[1];
                        instancedGeometry.current.attributes.worldPos.array[num + 2] = tileData.worldPos[2];
                        instancedGeometry.current.attributes.worldPos.array[num + 3] = tileData.worldPos[3];

                        instancedGeometry.current.attributes.level1.array[num] = tileData.level1[0];
                        instancedGeometry.current.attributes.level1.array[num + 1] = tileData.level1[1];
                        instancedGeometry.current.attributes.level1.array[num + 2] = tileData.level1[2];
                        instancedGeometry.current.attributes.level1.array[num + 3] = tileData.level1[3];

                        num += 4;
                    }
                }
            }
        });

        if (!instancedGeometry.current) return;

        instancedGeometry.current.attributes.worldPos.needsUpdate = true;
        instancedGeometry.current.attributes.level1.needsUpdate = true;
        instancedGeometry.current.instanceCount = num / 4;
    }, [zoneSize]);

    const lastSize = useRef({width: -1, height: -1})

    const lastUpdateRef = useRef(0);

    useFrame((state) => {
        const currentTime = state.clock.getElapsedTime();

        // Throttle the update to every second
        if (currentTime - lastUpdateRef.current >= 1) {
            lastUpdateRef.current = currentTime;

            if (state.size.width !== lastSize.current.width || state.size.height !== lastSize.current.height) {
                lastSize.current = state.size
                printTiles()
            }


        }
    });


    useEffect(() => {
        // setTimeout(() => {
        //     printTiles()
        // }, 3000)

        const intt = setInterval(() => {

            const xx = Math.floor(currentTileStore.state.currentTile.x / 50)
            const yy = Math.floor(currentTileStore.state.currentTile.y / 50)

            if (xx === lastTileX.current && yy === lsatTileY.current) {
                return
            }


            lastTileX.current = xx
            lsatTileY.current = yy

            printTiles()
        }, 1000 / 3)
        window.printTiles = printTiles
        return () => clearInterval(intt)
    }, [printTiles]);


    useFrame((s) => {
        const u = meshRef.current.material.uniforms
        u.zoom.value = s.controls.distance
        u.time.value = s.clock.elapsedTime * 1000

        if (s.controls.distance < 3000) {
            if (!meshRef.current.visible) {
                meshRef.current.visible = true
            }
        } else {
            if (meshRef.current.visible) {
                meshRef.current.visible = false
            }

        }

        // console.log(s.size)
    })


    return (
        <mesh ref={meshRef} raycast={() => null} frustumCulled={false} renderOrder={3}>
            <instancedBufferGeometry
                ref={instancedGeometry}
                index={tileGeometry.index}
                attributes-position={tileGeometry.attributes.position}
                attributes-uvn={tileGeometry.attributes.uvn}
                instanceCount={1}
            >
                <instancedBufferAttribute
                    attach={'attributes-worldPos'}
                    args={[new Float32Array(new Array(300000).fill(0)), 4]}
                />

                <instancedBufferAttribute
                    attach={'attributes-level1'}
                    args={[new Float32Array(new Array(300000).fill(0)), 4]}
                />

                <instancedBufferAttribute
                    attach={'attributes-level2'}
                    args={[new Float32Array(new Array(300000).fill(0)), 4]}
                />
            </instancedBufferGeometry>
            <terrainMaterial/>
        </mesh>
    )
}
