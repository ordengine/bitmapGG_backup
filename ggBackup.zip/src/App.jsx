import {Canvas} from "@react-three/fiber";
import {Suspense, useEffect, useRef} from "react";

import {EnvironmentLighting} from "./components/core/EnvironmentLighting.jsx";
import {Cam} from "./components/core/Cam.jsx";
import {Box, Bvh} from "@react-three/drei";
import {Effects} from "./components/core/Effects.jsx";
import {BigMap} from "./components/world/BigMap.jsx";
import {Terrain} from "./components/world/Terrain.jsx";
import {CustomPlayer} from "./components/player/CustomPlayer.jsx";
import {BoxParticles} from "./components/particles/BoxParticles.jsx";
import {InscriptionWall} from "./components/bitmap/InscriptionWall.jsx";
import {LoadingScreen} from "./components/GUI/LoadingScreen.jsx";
import {Chat} from "./components/GUI/Chat.jsx";
import {HealthBar} from "./components/GUI/HealthBar.jsx";
import {Joystick} from "./components/GUI/Joystick.jsx";
import {CurrentBitmapPanel} from "./components/GUI/CurrentBitmapPanel.jsx";
import {HoveredBitmap} from "./components/GUI/HoveredBitmap.jsx";
import {LevaComponent} from "./components/GUI/LevaComponent.jsx";
import {JumpPanel} from "./components/GUI/JumpPanel.jsx";
import {BuildPanel} from "./components/GUI/BuildPanel.jsx";
import {ComponentBuilds} from "./components/bitmap/ComponentBuilds.jsx";
import {Paperdoll} from "./components/GUI/Paperdoll.jsx";
import {HealthBars} from "./components/GUI/HealthBars.jsx";
import {useControls} from "leva";
import {BigMapLabels} from "./components/world/BigMapLabels.jsx";
import {Peers} from "./components/player/Peers.jsx";
import {UncommonClouds} from "./components/bitmap/UncommonClouds.jsx";
import {CodePanel} from "./components/GUI/CodePanel.jsx";
import {codeOpenStore} from "./modules/stores.mjs";
import {useStore} from "statery";

const SceneComponents = () => {


    return (
        <group>
            <BigMap/>
            <Terrain/>
            <CustomPlayer/>

            <Peers />

            <BigMapLabels />
            <HoveredBitmap/>

            {/*<InscriptionWall />*/}
            <UncommonClouds />

            <BoxParticles/>



            <ComponentBuilds/>


        </group>
    )
}

const GUI = () => {

    const {build, joystick, flight, healthBar, map} = useControls('UI Panels', {
        build: {
            value: false
        },
        joystick: {
            value: true
        },
        flight: {
            value: true
        },
        healthBar: {
            value: true
        },
        map: {
            value: true
        },
    })

    return (
        <>
            <LoadingScreen/>

            <LevaComponent/>

            <Chat/>
            {/**/}
            {/*<HealthBars/>*/}

            {/*{healthBar ? <HealthBar/> : null}*/}

            {joystick ? <Joystick/> : null}

            {flight ? <JumpPanel/> : null}

            {build ? <BuildPanel/> : null}


            {map ? <CurrentBitmapPanel/> : null}


            <CodePanel/>

            <Paperdoll/>

        </>
    )
}

const Scene = () => {

    const {codeOpen} = useStore(codeOpenStore)

    const sceneDivRef = useRef()

    useEffect(() => {
        window.sceneDiv = sceneDivRef
    }, [])

    return (
        <div ref={sceneDivRef} className={`w-full h-full pb-10 ${codeOpen ? 'h-2/3' : ''} transition-all `}>
            <Canvas
                onPointerMissed={() => {
                    window.setSelectedComponent('')
                }}
                dpr={1}
                camera={{
                    fov: 21,
                    position: [-4, 2, 2],
                    near: 0.1,
                    far: 500000
                }}
                gl={{
                    alpha: false,
                    depth: false,
                    stencil: false,
                    antialias: false,
                    precision: 'mediump',
                }}
            >
                <color attach="background" args={[0.02, 0.02, 0.022]}/>
                <Suspense>
                    {/*<Bvh>*/}
                    <EnvironmentLighting/>
                    <Cam/>
                    <Effects/>


                    <SceneComponents/>
                    {/*</Bvh>*/}
                </Suspense>
            </Canvas>
        </div>
    )
}

export function App() {

    return (
        <div className={`w-full h-full flex flex-col overflow-hidden border-y-2 border-orange-500 bg-neutral-600`}>
            <Scene/>
            <GUI/>
        </div>
    )
}

export default App
