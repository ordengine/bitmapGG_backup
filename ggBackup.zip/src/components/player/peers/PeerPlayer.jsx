import React, {memo, useEffect, useRef, useState} from "react";
import { useFrame } from "@react-three/fiber";
import InscribedSpaceAvatar from "../avatars/InscribedSpaceAvatar.jsx";
import * as THREE from "three";
import {Billboard, Text, TorusKnot} from "@react-three/drei";
import {Bitcopter} from "../companions/Bitcopter.jsx";
import {getElevation} from "../../../modules/getElevation.mjs";
import {PlayerChat} from "../PlayerChat.jsx";
import {bitmapStore, healthBarStore} from "../../../modules/stores.mjs";

const PeerPlayer = ({ peerId }) => {
    const ref = useRef();
    const avatar = useRef()

    const companionRef = useRef()


    const hoverRef = useRef()

    useEffect(() => {
        window.peers = window.peers || {};
        window.peers[peerId] = ref;
    }, [peerId]);

    const isWalking = useRef(false);

    const mount = useRef(null)

    useFrame(() => {
        // return
        if (window.peerTargets[peerId]) {
            const targetPosition = new THREE.Vector3(
                parseFloat(window.peerTargets[peerId].position[0]),
                parseFloat(window.peerTargets[peerId].position[1]),
                parseFloat(window.peerTargets[peerId].position[2])
            );

            const targetRotation = new THREE.Euler(
                parseFloat(window.peerTargets[peerId].rotation[0]),
                parseFloat(window.peerTargets[peerId].rotation[1]),
                parseFloat(window.peerTargets[peerId].rotation[2])
            );

            // Interpolate position
            const currentDistance = targetPosition.distanceTo(ref.current.position);
            ref.current.position.lerp(targetPosition, 0.06);

            companionRef.current.position.lerp(targetPosition, 0.02);

            // Slerp rotation
            const targetQuaternion = new THREE.Quaternion().setFromEuler(targetRotation);
            ref.current.quaternion.slerp(targetQuaternion, 0.1);


            companionRef.current.quaternion.slerp(targetQuaternion, 0.05);

            // Handle animation state change
            if (currentDistance > 0.6) {
                if (!isWalking.current) {
                    window.peerWalk[peerId]?.(); // Start walking animation
                    isWalking.current = true;
                }
            } else {
                if (isWalking.current) {
                    window.peerIdle[peerId]?.(); // Switch to idle animation
                    isWalking.current = false;
                }
            }

            if (ref.current.position.y - 2 > getElevation(targetPosition.x, targetPosition.z)) {
                mount.current.scale.set(0.9, 0.9, 0.9)
                mount.current.visible = true
                avatar.current.visible = false
                companionRef.current.scale.set(0, 0, 0)
            } else {
                mount.current.position.set(0, 1, 0)
                mount.current.scale.set(0.0, 0.0, 0.0)
                mount.current.visible = false
                companionRef.current.scale.set(1, 1, 1)
                avatar.current.visible = true

                avatar.current.scale.set(1, 1, 1)

            }
        }
    });

    const [latestChat, setLatestChat] = useState('')

    useEffect(() => {
        const intt = setInterval(() => {
            if (window.peerChats[peerId] !== latestChat) {
                // console.log('got chat ' + window.peerChats[peerId])
                setLatestChat(window.peerChats[peerId])

                const lat = latestChat + ''
                setTimeout(() => {
                    if (window.peerChats[peerId] === lat)
                    window.peerChats[peerId] = ''
                    setLatestChat('')
                }, 2000)
            }
        }, 500)

        return () => clearInterval(intt)
    }, [setLatestChat])

    return (
        <>
            <group ref={ref}>

                <group onPointerEnter={() => {
                    hoverRef.current.visible = true
                    // ref.current.position.y += 0.03
                }} onPointerLeave={() => {
                    hoverRef.current.visible = false
                }} onClick={() => {
                    // jump()
                    ref.current.position.y += 0.06


                    // Update store with new bitmaps
                    healthBarStore.set((prev) => {

                        if (prev.healthBars.find(b => b.peerId === peerId)) {
                            return {
                                healthBars: prev.healthBars
                            }
                        } else {
                            return (
                                {
                                    healthBars: [...prev.healthBars, {
                                        peer: true,
                                        peerId: peerId,

                                    } ],
                                }
                            )
                        }


                    });

                }}>
                    <mesh ref={hoverRef} visible={false} scale={[1.0, 1.8, 0.7]} position-y="1">
                        <boxGeometry/>
                        <meshBasicMaterial wireframe/>
                    </mesh>
                </group>

                <Billboard>
                    <Text outlineOpacity={1} renderOrder={6} outlineColor={'#111'} color={'#ff9900'} outlineWidth={0.1} font={'https://ordinals.com/content/74eed71c46430c38e056ef1bc69ad2c521293a8941d2177b52e7d447b42d5522i0'} fontSize={0.6} position={[0, 2.5, 0]}>
                        {latestChat}
                    </Text>
                </Billboard>

                <group ref={avatar}>
                    <InscribedSpaceAvatar peerId={peerId} />
                </group>

                <group ref={mount} scale={[0.9, 0.9, 0.9]} visible={false}>
                    <Bitcopter />
                </group>

            </group>

            <group ref={companionRef}>

                <group scale={0.2} position={[1, 2, 0]}>
                    <Bitcopter />
                </group>
            </group>
        </>
    );
};

export default memo(PeerPlayer);
