import {makeStore, useStore} from "statery";
import React, {useEffect, useRef, useState} from "react";
import * as THREE from "three";
import {useFrame, useThree} from "@react-three/fiber";
import {boxelGeometry} from 'boxels-shader'
import CustomShaderMaterial from "three-custom-shader-material";
import {Html, Wireframe} from "@react-three/drei";
import {hoveredBitmapStore} from "../../modules/stores.mjs";



export const HoveredBitmap = () => {
    const ref = useRef()
    const htmlRef = useRef()
    const materialRef = useRef()

    const [isBitmon, setIsBitmon] = useState(false)

    const bitmonDivRef = useRef(null);


    const {controls} = useThree()

    const {hoveredBitmap} = useStore(hoveredBitmapStore)

    const target = useRef(new THREE.Object3D())

    useEffect(() => {
        if (hoveredBitmap[1]) {
            target.current.position.set(hoveredBitmap[1][0]*100+50, 0, hoveredBitmap[1][1]*100+50)

            // console.log(target.current.position)
            // ref.current.position.lerp(target.current.position, 0.1)


            let mondrian = window.bitmaps[hoveredBitmap[0]]?.bitmon?.mondrian


            if (mondrian?.slots?.length > 0) {
                const padd = 0.7
                const mondrianSize = mondrian.getSize();

                const scaleX = bitmonDivRef.current.clientWidth / (mondrianSize.width - padd);
                const scaleY = bitmonDivRef.current.clientHeight / (mondrianSize.height - padd);
                const scale = Math.min(scaleX, scaleY);

                const offsetX = (bitmonDivRef.current.clientWidth - (mondrianSize.width - padd) * scale) / 2;
                const offsetY = (bitmonDivRef.current.clientHeight - (mondrianSize.height - padd) * scale) / 2;

                // bitmonDivRef.current.style.width = '32px';

                bitmonDivRef.current.innerHTML = '';

                for (let i = 0; i < mondrian.slots.length; i++) {
                    const slot = mondrian.slots[i];
                    const x = slot.position.x * scale;
                    const y = slot.position.y * scale;
                    const size = (slot.size - padd) * scale;

                    const childDiv = document.createElement('div');
                    childDiv.style.position = 'absolute';
                    childDiv.style.left = `${offsetX + x + 4}px`;
                    childDiv.style.top = `${offsetY + y + 4}px`;
                    childDiv.style.width = `${size}px`;
                    childDiv.style.height = `${size}px`;
                    childDiv.style.backgroundColor = '#ff9900';

                    childDiv.className += 'ring-2 ring-black text-orange-900 gloww flex justify-center items-center text-sm font-mono'

                    childDiv.onmouseover = () => {
                        childDiv.style.backgroundColor = 'limegreen';
                        childDiv.textContent = `${i}`;
                    };
                    childDiv.onmouseout = () => {
                        childDiv.style.backgroundColor = '#ff9900';
                        childDiv.textContent = '';
                    };
                    childDiv.onclick = () => {
                        console.log(`Clicked on parcel ${i}`);
                    };

                    bitmonDivRef.current.appendChild(childDiv);
                }
                setIsBitmon(true)
            } else {
                // bitmonDivRef.current.replaceChildren()
                // bitmonDivRef.current.style.width = '5px';
                // setIsBitmon(false)
            }
        }

    }, [hoveredBitmap, setIsBitmon])


    useFrame((state) => {

        // console.log(hoveredBitmap)

        if (hoveredBitmap[1]) {
            ref.current.position.lerp(target.current.position, 0.7)
        }

        const uniforms = materialRef.current.uniforms;
        uniforms.zoom.value = state.controls.distance;
        uniforms.time.value = state.clock.elapsedTime;

        // console.log(uniforms.zoom.value)

        // if (hoveredBitmap[0] === currentBitmapStore.state.currentBitmap) {
        //     ref.current.visible = false
        //     htmlRef.current.style.visibility = 'hidden'
        // } else {
        //     ref.current.visible = true
        //     htmlRef.current.style.visibility = 'visible'
        // }

        ref.current.visible = uniforms.zoom.value >= 300;

        if (htmlRef.current) {
            htmlRef.current.style.visibility = uniforms.zoom.value <= 300 ? 'hidden' : 'visible';
        }
    });



    return (
        <mesh ref={ref} scale={[100, 12, 100]} geometry={boxelGeometry} renderOrder={5}>
            <CustomShaderMaterial
                ref={materialRef}
                baseMaterial={THREE.MeshBasicMaterial}
                color={'#ff9900'}
                transparent
                wireframe
                uniforms={{
                    playerPos: {value: new THREE.Vector3()},
                    zoom: {value: 0},
                    time: {value: 0}
                }}
                vertexShader={`
varying vec3 vPos;
varying vec2 vUv;

void main() {

vUv = uv;

vPos = csm_Position;
}

                `}
                fragmentShader={`
            varying vec3 vPos;

            uniform float time;
            uniform float zoom;
    uniform vec3 playerPos;

varying vec2 vUv;


            void main() {
            vec3 c = vec3(2.1, 0.3, 0.0);
            
            float a = 1.0;
            
           
            
            if (a < 0.) {
                a = 0.;
            }

            csm_DiffuseColor = vec4(c, a);
        }`}
            />


            <Html ref={htmlRef} center style={{pointerEvents: 'none', opacity: 0.9}}>
                <div className={'-mt-8 h-24 leading-6 text-2xl text-orange-400 gloww flex flex-col items-center'}>


                    <div className={'flex items-end text-sm py-1 '}>


                        {
                            window.bitmaps[hoveredBitmap[0]]?.bitmon?.parcelCount === 1 ? (
                                <button className={'h-fit -mt-10 leading-4 pt-1 pb-0.5 w-12 min-w-12  gloww mx-1 ring-2 ring-neutral-300 text-neutral-300 bg-neutral-800 bg-opacity-70 px-1 rounded-md'}>
                                    <div>
                                        🟧
                                    </div>
                                    <div>
                                        1 tx
                                    </div>
                                </button>
                            ) : null
                        }

                        {
                            window.bitmaps[hoveredBitmap[0]]?.prime ? (
                                <button className={'-mt-10 h-fit leading-4 pt-1 w-14 min-w-14 pb-0.5 px-2 gloww mx-1 ring-2 ring-lime-500 text-lime-400 bg-neutral-800 bg-opacity-70 px-1 rounded-md'}>

                                    <div>
                                        🔥
                                    </div>
                                    <div>
                                        prime
                                    </div>
                                </button>
                            ) : null
                        }

                        {
                            window.bitmaps[hoveredBitmap[0]]?.rare ? (
                                <button className={'-mt-10 h-fit  leading-4 pt-1 pb-0.5 px-2  w-12 min-w-12 gloww mx-1 ring-2 ring-red-400 text-red-300 bg-neutral-800 bg-opacity-70 px-1 rounded-md'}>


                                    <div>
                                        🥩
                                    </div>
                                    <div>
                                        rare
                                    </div>
                                </button>
                            ) : null
                        }


                        {
                            window.bitmaps[hoveredBitmap[0]]?.palindrome ? (
                                <button className={'-mt-10 h-fit leading-4 pt-1 pb-0.5 px-2  w-12 min-w-12 gloww mx-1 ring-2 ring-purple-400 text-purple-300 bg-neutral-800 bg-opacity-70 px-1 rounded-md'}>
                                    <div>
                                        🦋
                                    </div>
                                    <div>
                                        pali
                                    </div>


                                </button>
                            ) : null
                        }

                        {
                            window.bitmaps[hoveredBitmap[0]]?.fibonacci ? (
                                <button className={'-mt-10 h-fit leading-4 pt-1 pb-0.5 px-2  w-22 min-w-22 gloww mx-1 ring-2 ring-yellow-400 text-yellow-300 bg-neutral-800 bg-opacity-70 px-1 rounded-md'}>
                                    <div>
                                        🐚
                                    </div>
                                    <div>
                                        fibonacci
                                    </div>


                                </button>
                            ) : null
                        }

                        {
                            window.bitmaps[hoveredBitmap[0]]?.minerMessage ? (
                                <button className={'-mt-10 h-fit leading-4 pt-1 pb-0.5 px-2  gloww mx-1 ring-2 ring-neutral-300 text-neutral-300 bg-neutral-800 bg-opacity-70 px-1 rounded-md'}>
                                    ⛏️ miner
                                </button>

                            ) : null
                        }


                        {
                            hoveredBitmap[0] === 0 ? (
                                <button className={'-mt-10 h-fit leading-4 pt-1 pb-0.5 px-2  gloww mx-1 ring-2 ring-neutral-300 text-neutral-300 bg-neutral-800 bg-opacity-70 px-1 rounded-md'}>
                                    ⛏️ bitoshi
                                </button>

                            ) : null
                        }


                        {/*{*/}
                        {/*    window.bitmaps[hoveredBitmap[0]]?.bitmon?.parcelCount === 1 ? (*/}
                        {/*        <button className={'-mt-12 h-fit leading-4 pt-1 pb-0.5 w-18 min-w-18  gloww mx-1 ring-2 ring-orange-500 text-orange-400 bg-neutral-800 bg-opacity-70 px-1 rounded-md'}>*/}

                        {/*            <div>*/}
                        {/*                🧡*/}
                        {/*            </div>*/}
                        {/*            <div>*/}
                        {/*                patoshi*/}
                        {/*            </div>*/}
                        {/*        </button>*/}
                        {/*    ) : null*/}
                        {/*}*/}

                        <button className={`${isBitmon ? 'opacity-90' : 'absolute -top-12 opacity-0'} transition-all -mt-14 h-fit flex flex-col justify-evenly items-center leading-4 pt-1 pb-0.5 px-2  w-20 min-w-20 gloww mx-1 ring-2 ring-orange-300 text-orange-300 bg-neutral-800 bg-opacity-70 px-1 rounded-md`}>



                            <div ref={bitmonDivRef} className={'  mb-2 -ml-2 relative w-10 h-10 brg-orange-400 rounded-md'}>


                            </div>
                            <div>
                                bitmon
                            </div>

                        </button>







                    </div>

                    <div className={'bg-neutral-800 bg-opacity-50 px-2 pt-0.5 rounded-md'}>
                        <span className={'font-sans text-orange-400 gloww'}><b>{hoveredBitmap[0]}</b></span><span className={'text-orange-300 text-xl'}>.bitmap</span>
                    </div>


                    {/*<div className={'mt-4 ring-2 text-[18px] px-2 py-1 w-fit text-lime-400 gloww hover:text-lime-400'}>*/}
                    {/*    fly here*/}
                    {/*</div>*/}

                    {/*<div className={'mt-2 text-[14px] px-2 py-1 w-fit text-lime-400 gloww hover:text-lime-400'}>*/}
                    {/*    5 blocks away*/}
                    {/*</div>*/}

                </div>

            </Html>

        </mesh>
    )
}
