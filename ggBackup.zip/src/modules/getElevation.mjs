// import {isPalindrome, isPrime, isRare} from "./utils.mjs";

window.xyToIndex = (x, y, numColumns) => {
    return y * numColumns + x;
}

let totalSats = 500000000


window.getSatSpace = ({x, z}) => {


    const zoneSize = 100; // Size of the grid, 10x10x10
    const totalCells = zoneSize * zoneSize; // Total cells in the 3D grid

    const chuckAmount = totalSats / totalCells

    // Calculate the linear index for the given (x, y, z) coordinate

    const linearIndex = (x + (z * zoneSize)) * chuckAmount;

    return linearIndex
    // return 'sats# ' + (linearIndex) + ' - ' + (linearIndex + chuckAmount); // +1 to start the count from 1 instead of 0
}

function getSatSign(x, y) {

    let sat = window.getSatSpace({x: x, y: 0, z: y})

    let ind = xyToIndex(x % 100, y % 100, 100)

    return Math.sin(sat * ind) * 0.1
}


window.bitmapElevations = {}

export const getMaterial = (x, y) => {

    // Calculate the tile and bitmap elevation
    const tile = [Math.floor(x / 100), Math.floor(y / 100)];
    const bitmap = parseInt((tile[1] * 1000) + tile[0]);

    // console.log(bitmap)

    if (bitmap < 10) {
        return 0
    }

    // if (isRare(bitmap) || tile[0] < 0 || tile[1] < 0) {
    //     return 3
    // }
    //
    // if (isPalindrome(bitmap)) {
    //     return 2
    // }



    return 0
}


window.bitmapTerraforms = {}

window.arr = new Float32Array(100 * 100).fill(0)

export const indexToXY = (index, width = 100) => {
    const x = index % width;
    const y = Math.floor(index / width);
    return { x, y };
};

window.bitmapIdToWorldXY = (bitmapId, index, bitmapWidth = 100, bitmapHeight = 100) => {
    const { x: x_in_bitmap, y: y_in_bitmap } = indexToXY(index, bitmapWidth);
    const bitmapX = bitmapId % 1000;
    const bitmapY = Math.floor(bitmapId / 1000);
    const worldX = bitmapX * bitmapWidth + x_in_bitmap;
    const worldY = bitmapY * bitmapHeight + y_in_bitmap;
    return { worldX, worldY };
};
const deleteTileCacheEntries = (worldX, worldY, lods = [1, 2, 8]) => {
    lods.forEach((lod) => {
        const key = `${worldX},${worldY},${lod}`;
        if (window.tileCache.has(key)) {
            window.tileCache.delete(key);
            // console.log(`Deleted tileCache for key: ${key}`);
        }
    });
};

/**
 * Deletes tileCache entries for neighboring tiles at specified LODs.
 * @param {number} centerX - The central tile's global x-coordinate.
 * @param {number} centerY - The central tile's global y-coordinate.
 * @param {Array<number>} lods - Array of Levels of Detail to delete (default: [1, 2, 8]).
 */
const deleteNeighboringTileCacheEntries = (centerX, centerY, lods = [1, 2, 8]) => {
    // Define the relative positions of neighboring tiles
    const neighbors = [
        { dx: -1, dy: -1 }, // Top-Left
        { dx: 0, dy: -1 },  // Top-Center
        { dx: 1, dy: -1 },  // Top-Right
        { dx: -1, dy: 0 },  // Middle-Left
        { dx: 1, dy: 0 },   // Middle-Right
        { dx: -1, dy: 1 },  // Bottom-Left
        { dx: 0, dy: 1 },   // Bottom-Center
        { dx: 1, dy: 1 },   // Bottom-Right
    ];

    neighbors.forEach(({ dx, dy }) => {
        const neighborX = centerX + dx;
        const neighborY = centerY + dy;

        // Optional: Add boundary checks if your world has limits
        /*
        if (neighborX < 0 || neighborY < 0 || neighborX >= WORLD_WIDTH || neighborY >= WORLD_HEIGHT) {
            // Skip invalid coordinates
            return;
        }
        */

        deleteTileCacheEntries(neighborX, neighborY, lods);
    });
};


/**
 * Retrieves all tile indices within a specified brush size around a center tile.
 * Applies a gradient influence based on distance from the center.
 * @param {number} centerX - The central tile's x-coordinate within the bitmap (0-99).
 * @param {number} centerY - The central tile's y-coordinate within the bitmap (0-99).
 * @param {number} brushSize - The radius of the brush.
 * @returns {Array<{index: number, influence: number}>} Array of tile indices with their respective influence.
 */
export const getBrushAffectedTiles = (centerX, centerY, brushSize, intensity = 0.8) => {
    const affectedTiles = [];
    const minX = Math.max(centerX - brushSize, 0);
    const maxX = Math.min(centerX + brushSize, 99);
    const minY = Math.max(centerY - brushSize, 0);
    const maxY = Math.min(centerY + brushSize, 99);

    for (let y = minY; y <= maxY; y++) {
        for (let x = minX; x <= maxX; x++) {
            const distance = Math.sqrt(Math.pow(x - centerX, 2) + Math.pow(y - centerY, 2)) * intensity;
            if (distance <= brushSize) {
                // Linear gradient: influence decreases linearly with distance
                const influence = (1 - (distance / brushSize)) * 0.5;
                const index = y * 100 + x;
                affectedTiles.push({ index, influence });
            }
        }
    }

    return affectedTiles;
};


/**
 * Sets the terraform height for a specific tile and manages cache invalidation.
 * @param {number|string} bitmapId - The unique identifier for the bitmap.
 * @param {number} index - The index within the bitmap (0 to 9999).
 * @param {number} up - The value to increase the height by.
 */
// src/modules/setTerraform.mjs
/**
 * Sets the terraform height for a specific tile and manages cache invalidation with a gradient brush.
 * @param {number|string} bitmapId - The unique identifier for the bitmap.
 * @param {number} index - The index within the bitmap (0 to 9999).
 * @param {number} up - The value to increase the height by.
 * @param {number} [brushSize=1] - The radius of the brush affecting surrounding tiles.
 */
window.setTerraform = (bitmapId, index, up, brushSize = 4, spread = 5) => {
    // Input Validation
    if (typeof bitmapId !== 'number' && typeof bitmapId !== 'string') {
        console.error('Invalid bitmapId. It should be a number or string.');
        return;
    }

    if (typeof index !== 'number' || index < 0 || index >= 100 * 100) {
        console.error('Invalid index. It should be a number between 0 and 9999.');
        return;
    }

    if (typeof up !== 'number') {
        console.error('Invalid up value. It should be a number.');
        return;
    }

    if (typeof brushSize !== 'number' || brushSize < 0) {
        console.error('Invalid brushSize. It should be a non-negative number.');
        return;
    }

    // Initialize bitmapTerraforms for the given bitmapId if not present
    if (!window.bitmapTerraforms[bitmapId]) {
        window.bitmapTerraforms[bitmapId] = [];
    }

    // Convert bitmapId and index to global worldX and worldY
    const coords = bitmapIdToWorldXY(bitmapId, index);
    if (!coords) {
        console.error('Failed to convert bitmapId and index to world coordinates.');
        return;
    }

    const { worldX, worldY } = coords;

    // Get x and y within the bitmap
    const { x: centerX, y: centerY } = indexToXY(index);

    // Get all affected tiles within the brush
    const affectedTiles = getBrushAffectedTiles(centerX, centerY, brushSize, spread);

    affectedTiles.forEach(({ index: tileIndex, influence }) => {
        // Calculate the height increment based on influence
        const heightIncrement = up * influence;

        // Update the height for the specified index
        window.bitmapTerraforms[bitmapId][tileIndex] = (window.bitmapTerraforms[bitmapId][tileIndex] || 0) + heightIncrement;
        // console.log(`Updated bitmapTerraforms[${bitmapId}][${tileIndex}] to ${window.bitmapTerraforms[bitmapId][tileIndex]}`);

        // Convert tileIndex to global worldX and worldY
        const tileCoords = bitmapIdToWorldXY(bitmapId, tileIndex);
        if (!tileCoords) {
            console.error(`Failed to convert index ${tileIndex} to world coordinates.`);
            return;
        }

        const { worldX: tileWorldX, worldY: tileWorldY } = tileCoords;

        // Define the Levels of Detail (LODs) to invalidate
        const lodsToInvalidate = [1, 2, 8];

        // Invalidate cache for the updated tile
        deleteTileCacheEntries(tileWorldX, tileWorldY, lodsToInvalidate);

        // Invalidate cache for neighboring tiles
        deleteNeighboringTileCacheEntries(tileWorldX, tileWorldY, lodsToInvalidate);
    });

    // Optionally, send a chat message (uncomment if sendChat is defined)
    /*
    if (typeof sendChat === 'function') {
        sendChat(`build ${bitmapId}.bitmap ind: ${index} to ${window.bitmapTerraforms[bitmapId][index]}, ${Math.random().toFixed(2)}`);
    }
    */

    // Print updated tiles (ensure window.printTiles is defined)
    if (typeof window.printTiles === 'function') {
        window.printTiles();
    } else {
        console.warn('window.printTiles is not defined.');
    }
};

window.arr[0] = 5

window.arr[1] = 10

export const getElevation = (x, y) => {
    // Return 0 if the coordinates are out of bounds
    if (x < 0 || y < 0 || x > 100000 || y > 100000) {
        return 0;
    }

    let h = 3;


    // Calculate the tile and bitmap elevation
    const tile = [Math.floor(x / 100), Math.floor(y / 100)];
    const bitmap = parseInt((tile[1] * 1000) + tile[0]);

    let ind = xyToIndex(x % 100, y % 100, 100)

    let buildHeight = 0

    if (window.bitmapTerraforms[bitmap]?.[ind]) {
        buildHeight = window.bitmapTerraforms[bitmap][ind]
    }

    if (bitmapElevations[bitmap]?.[ind]) {
        return Math.max(0, bitmapElevations[bitmap][ind] + buildHeight);
    } else {
        if (!bitmapElevations[bitmap]) {
            bitmapElevations[bitmap] = new Float32Array(100 * 100).fill(0)
        }
    }

    // const prime = isPrime(bitmap)
    // let isPrimeTouching = isPrime(bitmap)
    // lete isPrimeTouching2 = isPrime(bitmap)

    const prime = window.bitmaps[bitmap]?.prime;
    const isPrimeTouching = window.bitmaps[bitmap]?.primeTouching;
    const isPrimeTouching2 = window.bitmaps[bitmap]?.primeTouching2;


    if (isRare(bitmap)) {
        h = 2
    }  else if (isPalindrome(bitmap)) {
        h = 1;
    } else if (prime) {
        h += 3;
    } else if (window.bitmaps[bitmap]?.bitmon?.m.slots.length === 1) {
        if (prime || isPrimeTouching || isPrimeTouching2) {
            h = 3
        } else {
            h = 0
        }

    } else if (window.bitmaps[bitmap]?.bitmon?.m.slots.length > 1) {
        h = 2
    } else if (isPrimeTouching || isPrimeTouching2) {
        h = 3.5;
    } else {
         h = 0;
    }



    // if (window.bitmaps[bitmap].bitmon?.mondrian) {
    //     h += window.bitmaps[bitmap].bitmon?.m.slots.length
    // }
    if (window.bitmaps[bitmap]?.bitmon?.m.slots.length > 1 && window.bitmaps[bitmap]?.bitmon?.m.slots.length < 21) {

        window.bitmaps[bitmap]?.bitmon?.m?.slots?.forEach((parcel, i) => {

            // Calculate x and y from the index
            const x = ind % 100;
            const y = Math.floor(ind / 100);

// Retrieve the mondrian object and its slots
            const mondrian = window.bitmaps[bitmap]?.bitmon?.m;
            const slots = mondrian?.slots;

            if (slots && slots.length > 0) {
                const w = Math.floor(100 / mondrian.width);
                const he = Math.floor(100 / mondrian.height);
                const ss = Math.min(w, he);
                const padding = ss * 0.0; // Gap between parcels

                h = slots.length <= 3 ? 2 : 3

                // Loop through each parcel to check if (x, y) is within its boundaries
                slots.forEach((parcel, i) => {
                    // return
                    const size = ss * parcel.size - padding;
                    const offset = ss * parcel.size / 2;
                    const posX = ss * parcel.position.x + offset;
                    const posZ = ss * parcel.position.y + offset;

                    const startX = posX - offset;
                    const endX = posX - offset + size;
                    const startY = posZ - offset;
                    const endY = posZ - offset + size;

                    // Check if (x, y) falls within the current parcel
                    if (x >= startX && x < endX && y >= startY && y < endY) {
                        // h = 2
                        h += Math.max(0, 3
                            + (prime ? ((slots.length-i)*10) : ((slots.length-i)*5))

                        )

                        if (h > 50) {
                            h = 50

                            if (i % 2 === 0) {
                                h -= 5
                            }
                        }
                            // - ((x === 0 || y === 0) ? 0.8 : 0)
                            // - ((x === endX || endY === 0) ? 0.8 : 0)
                            // - ((x === endX - 2) ? 4 : 0)
                            // - ((y === endY - 2) ? 4 : 0)
                            // - ((x === endX - 1) ? 4 : 0)
                            // - ((y === endY - 1) ? 4 : 0))

                        // Additional calculations if needed
                        // h += (((slots.length - i) + 1) * parcel.size * 0.75) * 0.25;

                        // Use 'h' as needed in your code
                    }
                });
            }

        })
    }



    //
    //

    //
    // if (bitmap > 210000) {
    //     h += 1
    // }
    //
    // if (bitmap > 420000) {
    //     h += 1
    // }
    //
    // if (bitmap > 630000) {
    //     h += 1
    // }
    //
    // if (bitmap > 840000) {
    //     h += 1
    // }


    if (bitmap < 10) {
        h = 2
    }

    if (x % 100 > 96 || y % 100 > 96) {
        const satSin = getSatSign(x, y);
        if (h === 2) {
            h -= satSin * 2
        } else if (h < 1) {

        } else {
            h = 3.1 + satSin * 1
        }

        if (window.bitmaps[bitmap]?.bitmon?.m?.slots?.length > 1) {
            if (x % 100 > 94 ) {
                if (h < 3) {
                    h = 0
                }
            } else {
            }
            // h = 2
        }
        // Edge logic based on percentage within tile
    } else if (h > 0) {
        const satSin = getSatSign(x, y);
        h += satSin;
    }

    if (bitmap > window.currentBlockHeight) {
        h = 2
    }

    // Slope elevation to zero at edges where x < 10 or y < 10


    // let beachNum = 20 + h*3
    //
    //
    //
    // if (x < beachNum) {
    //     h *= x / beachNum;
    // }
    // if (y < beachNum) {
    //     h *= y / beachNum;
    // }

    // Further reduce height for very close proximity to the origin
    if (x < 2 || y < 2) {
        // h = 0.5;
    }


    // Save the calculated elevation
    bitmapElevations[bitmap][ind] = h;

    return Math.max(0, bitmapElevations[bitmap][ind] + buildHeight);
};
