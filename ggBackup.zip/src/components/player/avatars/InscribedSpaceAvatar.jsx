import React, { useCallback, useEffect, useRef } from 'react';
import { useGLTF, useAnimations, useTexture } from '@react-three/drei';
import * as THREE from 'three';
import {useFrame} from "@react-three/fiber";
import {myTextureStore} from "../../../modules/stores.mjs";
import {useStore} from "statery";

function InscribedSpaceAvatar(props) {
    const group = useRef();
    const { nodes, materials, animations } = useGLTF(
        'https://ordinals.com/content/5e2d04efb32bc584af0f86ca9d0744186c680ced298a33235dc913a5f13e2f34i0'
    );
    const { actions } = useAnimations(animations, group);

    const walking = useRef(false);
    const fadeDuration = 0.2;


    const texture = useTexture(
        'https://ordinals.com/content/' + (props.texture || '75e3588e2fad36befc0fbbf7a21354340dee290f2839d19c35db68a79648d5aei0')
    );

    useFrame(({clock}) => {
        if (walking.current) {
            group.current.position.y = Math.abs(Math.sin(clock.elapsedTime * 5) * Math.cos(clock.elapsedTime * 5)) * 0.4
        } else {
            group.current.position.y = 0
        }
    })


    const walk = useCallback(() => {
        // console.log('walkkkkk')
        if (walking.current) return;
        walking.current = true;

        const idleAction = actions[Object.keys(actions)[1]];
        const walkAction = actions[Object.keys(actions)[2]];

        idleAction?.fadeOut(fadeDuration);
        walkAction?.reset().fadeIn(fadeDuration).play();
        walkAction.timeScale = 1.5;
    }, [actions, fadeDuration, props]);

    const idle = useCallback(() => {
        if (!walking.current) return;
        walking.current = false;

        const walkAction = actions[Object.keys(actions)[2]];
        const idleAction = actions[Object.keys(actions)[1]];

        walkAction?.fadeOut(fadeDuration);
        idleAction?.reset().fadeIn(fadeDuration).play();
        idleAction.timeScale = 0.5;
    }, [actions, fadeDuration]);

    useEffect(() => {
        texture.flipY = false;
        texture.encoding = THREE.sRGBEncoding;
        texture.minFilter = THREE.NearestFilter;
        texture.magFilter = THREE.NearestFilter;
        texture.needsUpdate = true;

        // Set up material texture and properties
        const material = materials['Material.002'];
        if (material) {
            material.map = texture;
            material.transparent = true;
            material.alphaTest = 0.5;
            material.depthWrite = true;
            material.depthTest = true;
            material.side = THREE.DoubleSide;
            material.premultipliedAlpha = true;
            material.needsUpdate = true;
        }

        // Ensure the animation resets to idle when the texture changes
        idle();

        const idleAction = actions[Object.keys(actions)[1]];
        const walkAction = actions[Object.keys(actions)[2]];

        setTimeout(() => {
            if (idleAction) {
                idleAction.timeScale = 0.5;
                idleAction.play();
            }

            if (walkAction) {
                walkAction.timeScale = 1;
            }
        }, 1500);
    }, [props, texture, idle]);



    useEffect(() => {
        if (props.player) {
            window.playerWalk = walk;
            window.playerIdle = idle;
        } else if (props.peerId) {
            window.peerWalk = window.peerWalk || {};
            window.peerIdle = window.peerIdle || {};

            window.peerWalk[props.peerId] = walk;
            window.peerIdle[props.peerId] = idle;
        }
    }, [walk, idle, props]);

    return (
        <group
            ref={group}
            {...props}
            dispose={null}
            scale={1}
            renderOrder={0}
        >
            <group name="Scene" position={[0, 1, 0]}>
                <group name="Armature">
                    <primitive object={nodes.Body.clone()} />
                    <primitive object={nodes.BottomL.clone()} />
                    <primitive object={nodes.BottomR.clone()} />
                </group>
            </group>
        </group>
    );
}

export default React.memo(InscribedSpaceAvatar);
