import {makeStore} from "statery";

export const startedStore = makeStore({started: false})

export const myTextureStore = makeStore({myTexture: '75e3588e2fad36befc0fbbf7a21354340dee290f2839d19c35db68a79648d5aei0'})

export const myNameStore = makeStore({myName: 'new name'})



export const healthBarStore = makeStore({healthBars: []})



export const latestChatStore = makeStore({latestChat: ''})

export const currentTileStore = makeStore({currentTile: {x: -1, y: -1}})

export const hoveredBitmapStore = makeStore({hoveredBitmap: -1, selected: false})

export const currentBitmapStore = makeStore({currentBitmap: -1, zoneX: -1, zoneY: -1})

export const showSettingsStore = makeStore({showSettings: false})


export const peerStore = makeStore({
    peers: {}, // Structure: { peerId: { position: [x, y, z], rotation: [x, y, z] } }
});


export const bitmapStore = makeStore({
    bitmaps: {}, // Stores data for all nearby bitmaps
});

// Health Store
export const healthStore = makeStore({
    health: 100, // Initial health set to 100%
});


// Updated setHealth to accept a value or a function
export const setHealth = (update) => {
    healthStore.set((prev) => ({
        health: typeof update === 'function'
            ? Math.max(0, Math.min(100, update(prev.health)))
            : Math.max(0, Math.min(100, update)),
    }));
};
// New Terraform Store


export const terraformStore = makeStore({
    tiles: [],
});

// Function to initialize a bitmap's height map
export const initializeBitmap = (bitmapId) => {
    // console.log('init?')
    if (!terraformStore.state.tiles[bitmapId]) {
        // console.log('init')
        const newTiles = {
            ...terraformStore.state.tiles,
            [bitmapId]: {
                heights: new Float32Array(100 * 100).fill(0),
            },
        };
        terraformStore.set({ tiles: newTiles });
    }
};

// Function to set a specific tile's height
export const setTileHeight = (bitmapId, x, y, height) => {
    const index = y * 100 + x;

    terraformStore.set((prev) => {
        const bitmap = prev.tiles[bitmapId];
        if (!bitmap) {
            console.warn(`Bitmap ID "${bitmapId}" not found. Initializing...`);
            initializeBitmap(bitmapId);
            return prev; // Early return; the height will be set in the next call
        }

        const newHeights = new Float32Array(bitmap.heights);
        newHeights[index] = Math.max(0, Math.min(100, height)); // Clamping

        const newTiles = {
            ...prev.tiles,
            [bitmapId]: {
                ...bitmap,
                heights: newHeights,
            },
        };


        return {
            tiles: newTiles,
        };
    });
};

// Function to set multiple tiles at once (bulk update)
export const setMultipleTileHeights = (bitmapId, tiles) => {
    terraformStore.set((prev) => {
        const bitmap = prev.tiles[bitmapId];
        if (!bitmap) {
            console.warn(`Bitmap ID "${bitmapId}" not found. Initializing...`);
            initializeBitmap(bitmapId);
            return prev; // Early return; the heights will be set in the next call
        }

        const newHeights = new Float32Array(bitmap.heights);
        tiles.forEach(({ x, y, height }) => {
            const index = y * 100 + x;
            newHeights[index] = Math.max(0, Math.min(100, height)); // Clamping
        });

        const newTiles = {
            ...prev.tiles,
            [bitmapId]: {
                ...bitmap,
                heights: newHeights,
            },
        };


        return {
            tiles: newTiles,
        };
    });
};

// Function to get a specific tile's height

export const getTileHeight = (bitmapId, index) => {

    return 5
    const bitmap = terraformStore.state.tiles[bitmapId];
    if (!bitmap) {
        console.warn(`Bitmap ID "${bitmapId}" not found.`);
        return null;
    }

    if (index === 0) {
        return bitmap.heights[index]
    } else {
        return 0
    }

    return bitmap.heights[index];
};


// Function to get the entire height map for a bitmap
export const getHeightMap = (bitmapId) => {
    const bitmap = terraformStore.state.tiles[bitmapId];
    if (!bitmap) {
        console.warn(`Bitmap ID "${bitmapId}" not found.`);
        return null;
    }

    return bitmap.heights;
};

// **New Function: Increase Tile Height**
export const increaseTileHeight = (bitmapId, x, y, increment = 10) => {
    const index = y * 100 + x;

    terraformStore.set((prev) => {
        const bitmap = prev.tiles[bitmapId];
        if (!bitmap) {
            console.warn(`Bitmap ID "${bitmapId}" not found. Initializing...`);
            initializeBitmap(bitmapId);
            return prev; // Early return; the height will be set in the next call
        }

        const currentHeight = bitmap.heights[index];
        const newHeight = Math.max(0, Math.min(100, currentHeight + increment));

        const newHeights = new Float32Array(bitmap.heights);
        newHeights[index] = newHeight;

        const newTiles = {
            ...prev.tiles,
            [bitmapId]: {
                ...bitmap,
                heights: newHeights,
            },
        };


        return {
            tiles: newTiles,
        };
    });
};


export const componentBuildStore = makeStore({componentBuilds: [
    // {
    //     "name": "CustomTorus",
    //     id: 'waaat',
    //     "position": [0, 0, 0],
    //     "jsx": "export const Component1 = (props) => (\n  <mesh>\n    <torusGeometry args={[1, 0.4, 16, 100]} />\n    <meshNormalMaterial />\n  </mesh>\n)"
    // }
    ]

})


export const buildOutStore = makeStore({})


export const codeOpenStore = makeStore({codeOpen: false})


export const transformModeStore = makeStore({transformMode: 'translate'})

