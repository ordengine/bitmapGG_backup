import {Html} from "@react-three/drei";
import React, {useEffect, useMemo, useState} from "react";
import {getCoordinates, numberWithCommas} from "../../modules/utils.mjs";
import {useFrame} from "@react-three/fiber";
import {useControls} from "leva";
import {useStore} from "statery";
import {startedStore} from "../../modules/stores.mjs";


export const BigMapLabels = () => {

    const [currentHeight, setCurrentHeight] = useState(-1)

    const { started } = useStore(startedStore);

    useEffect(() => {

        const getHeight = async () => {

            const height = await fetch('https://ordinals.com/r/blockheight').then(r => r.json())


            const blockinfo = await fetch('https://ordinals.com/r/blockinfo/' + height).then(r => r.json())


            setCurrentHeight(height)

            window.currentBlockHeight = height


            sendChat('⚔️ welcome to Gladion!  this is an experimental live build, expect bugs!', 'system')


            setTimeout(() => {
                sendChat('latest block: ' + numberWithCommas(height), 'system')

            }, 150)

            setTimeout(() => {
                sendChat('fee rate: ' + (blockinfo.average_fee_rate) + ' sats/vB', 'system')

            }, 300)
        }
        if (started) {
            setTimeout(() => {
                getHeight()
            }, 500)
        }
    }, [setCurrentHeight, started])


    const Label = ({bitmapNumber, position}) => {
        return (
            <Html position={position} center style={{pointerEvents: 'none', opacity: 0.9}}>
                <div className={'-mt-8 h-24 leading-6 text-2xl text-orange-400 gloww flex flex-col items-center'}>
                    <div className={'bg-neutral-800 bg-opacity-10 px-2 pt-0.5 rounded-md'}>
                        <span className={'font-sans text-orange-400 gloww'}><b>{bitmapNumber}</b></span><span className={'text-orange-300 text-xl'}>.bitmap</span>
                    </div>
                </div>
            </Html>
        )
    }

    const LatestBlockLabel = ({bitmapNumber, position}) => {
        return (
            <Html position={position} center style={{pointerEvents: 'none', opacity: 0.9}}>
                <div className={'-mt-8 h-24 leading-6 text-2xl text-orange-400 gloww flex flex-col items-center'}>
                    <div className={'bg-neutral-800 bg-opacity-20 ring-orange-500 ring-2 ring-opacity-60 px-2 pt-0.5 rounded-md'}>

                        <span className={'font-sans text-orange-400 gloww'}><b>{bitmapNumber}</b></span><span className={'text-orange-300 text-xl'}>.bitmap</span>


                        <div className={'-mt-1 flex justify-center text-sm'}>
                            <span className={'pr-1.5'}>🟧</span> latest block <span className={'pl-1'}>⛏️</span>
                        </div>

                    </div>
                </div>
            </Html>
        )
    }

    const {showLabels} = useControls({
        showLabels: true
    })

    return !showLabels ? null : (
        <group>

            <Label bitmapNumber={0} />

            <LatestBlockLabel bitmapNumber={currentHeight} position={[getCoordinates(currentHeight).x * 100, 1500, getCoordinates(currentHeight).y * 100]} />

        </group>
    )
}
