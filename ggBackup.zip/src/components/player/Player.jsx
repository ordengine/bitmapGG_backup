import React, {useCallback, useEffect, useMemo, useRef, useState} from "react";
import * as THREE from "three";
import {useFrame} from "@react-three/fiber";
import {componentBuildStore, currentBitmapStore, currentTileStore} from "../../modules/stores.mjs";
import {getElevation} from "../../modules/getElevation.mjs";
import {Bitcopter} from "./companions/Bitcopter.jsx";
import {useControls} from "leva";

import {Billboard, Text} from '@react-three/drei'
import {PlayerChat} from "./PlayerChat.jsx";
import {setSelectedComponent} from "../bitmap/ComponentBuilds.jsx";
// import {setSelectedComponent} from "../bitmap/ComponentBuilds.jsx";


window.dir = ''
export const useWASDcontroller = () => {

    const flying = useRef(false)


    const ref = useRef()
    const moveRef = useRef()

    const forward = useRef(false);
    const back = useRef(false);
    const left = useRef(false);
    const right = useRef(false);
    const up = useRef(false);
    const shift = useRef(false);
    const control = useRef(false);
    const tab = useRef(false);
    const alt = useRef(false);
    const keyR = useRef(false);
    const keyF = useRef(false);

    const lagRef = useRef(new THREE.Object3D())

    const primaryPointerDown = useRef(false)
    const secondaryPointerDown = useRef(false)

    const isMoving = useRef(false);

    const rotationTarget = useRef(new THREE.Object3D())

    const targetHeight = useRef(2)

    const lastMessage = useRef('')

    const lastBuilds = useRef('')



    function sendUpdateToAllPeers(force) {

        // console.log('SENDUPDATE')

        const x = parseInt(Math.round(ref.current?.position.x))
        const y = parseInt(Math.round(ref.current?.position.y))
        const z = parseInt(Math.round(ref.current?.position.z))

        // console.log(x + ', ' + z)
        //
        const elev = getElevation(x, z) + 0.0
        //
        //
        // console.log(elev)
        if (!elev) return
        // window.currentElev = elev
        targetHeight.current = elev
        window.currentElev = elev

        window.playerTileX = x
        window.playerTileY = y
        window.playerTileZ = z

        let message = JSON.stringify({
            type: "update",
            position: [window.playerTileX, window.playerTileY, window.playerTileZ],
            rotation: [parseFloat(ref.current?.rotation.x.toFixed(1)),
                parseFloat(ref.current?.rotation.y.toFixed(1)),
                parseFloat(ref.current?.rotation.z.toFixed(1))],
        })

        if (force || message !== lastMessage.current) {
            lastMessage.current = message

            // Send position and rotation to peers
            if (window.connections) {
                Object.values(window.connections).forEach((conn) => {
                    // console.log('sending to ')
                    // console.log(conn.peer)
                    // console.log([x, elev, y])

                    conn.send(message);
                });
            }

        }
    }


    //
    // useEffect(() => {
    //     setInterval(() => {
    //
    //         sendUpdateToAllPeers(true)
    //
    //         // elev + 0.46
    //     }, 1000 / 1)
    // }, [])


    useEffect(() => {
        const intt = setInterval(() => {



            sendUpdateToAllPeers()

            // elev + 0.46
        }, 1000 / 3)

        return () => clearInterval(intt)
    }, [])

    useEffect(() => {
        const intt = setInterval(() => {



            sendUpdateToAllPeers(true)

            // elev + 0.46
        }, 3000 / 1)

        return () => clearInterval(intt)
    }, [])

    useEffect(() => {
        window.forward = forward
        window.back = back
        window.left = left
        window.right = right
    }, [])

    useEffect(() => {
        const handleKeyDown = (e) => {
            switch (e.key.toLowerCase()) {  // use toLowerCase() to simplify case handling
                case 'w':
                case 'arrowup':
                    forward.current = true;
                    isMoving.current = true;
                    window.playerMoving = true
                    break;
                case 's':
                case 'arrowdown':
                    back.current = true;
                    isMoving.current = true;
                    window.playerMoving = true
                    break;
                case 'a':
                case 'arrowleft':
                    left.current = true;
                    isMoving.current = true;
                    window.playerMoving = true
                    break;
                case 'd':
                case 'arrowright':
                    right.current = true;
                    isMoving.current = true;
                    window.playerMoving = true
                    break;
                case ' ':
                    up.current = true;
                    flying.current = true
                    if (window.jumpDown === false) {
                    //     window.jump()
                        window.jumpDown = true
                    }

                    break;
                case 'shift':
                    shift.current = true;

                    // flying.current = false
                    break;
                case 'r':
                    keyR.current = true
                    break
                case 'tab':
                    e.stopPropagation()
                    e.preventDefault()
                    tab.current = true;
                    break;
                case 'control':
                    control.current = true;
                    break;
                case 'escape':
                    setSelectedComponent(null)
                    break;
                case '1':
                    window.castingSpell = true

                    setTimeout(() => {
                        window.castingSpell = false
                    }, 1000)
                    break;
                default:
                    break;
            }
        };

        const handleKeyUp = (e) => {
            switch (e.key.toLowerCase()) {
                case 'w':
                case 'arrowup':
                    forward.current = false;
                    window.playerMoving = false
                    break;
                case 's':
                case 'arrowdown':
                    back.current = false;
                    break;
                case 'a':
                case 'arrowleft':
                    left.current = false;
                    break;
                case 'd':
                case 'arrowright':
                    right.current = false;
                    break;
                case ' ':
                    up.current = false;
                    window.jumpDown = false
                    break;
                case 'r':
                    keyR.current = false
                    break
                case 'shift':
                    shift.current = false;
                    break;
                case 'tab':
                    tab.current = false;
                    break;
                case 'control':
                    control.current = false;
                    break;
                default:
                    break;
            }
            isMoving.current = forward.current || back.current || left.current || right.current || up.current;
            window.playerMoving = forward.current || back.current || left.current || right.current || up.current;
        };

        window.addEventListener('keydown', handleKeyDown);
        window.addEventListener('keyup', handleKeyUp);

        return () => {
            window.removeEventListener('keydown', handleKeyDown);
            window.removeEventListener('keyup', handleKeyUp);
        };
    }, []);

    useEffect(() => {
        const handlePointerDown = (e) => {
            switch (e.key) {
                case '0':
                    primaryPointerDown.current = true
                    break;
                case '2':
                    secondaryPointerDown.current = true
                    break;
                default:
                    break;
            }
        };

        const handlePointerUp = (e) => {
            switch (e.key) {
                case '0':
                    primaryPointerDown.current = false
                    break;
                case '2':
                    secondaryPointerDown.current = false
                    break;
                default:
                    break;
            }
        };

        // Attach event listeners
        window.addEventListener('pointerdown', handlePointerDown);
        window.addEventListener('pointerup', handlePointerUp);

        return () => {
            window.removeEventListener('pointerdown', handlePointerDown);
            window.removeEventListener('pointerup', handlePointerUp);
        };
    }, []);

    const yTarget = useRef(0)

    const lastX = useRef()
    const lastY = useRef()

    // useEffect(() => {
    //     const raycaster = new THREE.Raycaster();
    //     const down = new THREE.Vector3(0, -1, 0);
    //
    //     const intervalId = setInterval(() => {
    //         if (ref.current) {
    //             raycaster.set(ref.current.position.clone().add(new THREE.Vector3(0, 10, 0)), down);
    //             const intersects = raycaster.intersectObject(window.terrain);
    //
    //             if (intersects.length > 0) {
    //                 const terrainHeight = intersects[0].point.y - 0.03;
    //                 yTarget.current = terrainHeight;
    //             }
    //         }
    //     }, 240);
    //
    //     return () => clearInterval(intervalId);
    // }, []);

    const {sss} = useControls('player',{
        sss: {
            label: 'moveSpeed',
            value: 5,
            min: 1,
            max: 10,
            step: 1,
        }
    })

    useFrame((state, dt) => {
        // let flyy = fly || copter
        // console.log(flyy)
        let speed = sss * dt * (flying.current ? 3 : 1) * (shift.current ? 2 : 1)
        const camera = state.camera;
        const direction = new THREE.Vector3();
        camera.getWorldDirection(direction);
        // if (!flyy) {


        let ground = false

        if (!up.current && !flying.current) {


            // if (window.currentHeight < window.currentElev + 0.1) {
            direction.y = 0
            // ground = true
            // } else {

            // }


        }

        // if (keyR.current) {
        //     speed *= 1;
        //     window.attacking = true
        // } else {
        //     window.attacking = false
        // }

        if (up.current && flying.current) {
            //     // direction.y = 1;
            ref.current.position.y += speed * 1.6 * (control.current ? -1 : 1)
        }
        //
        //
        // if (ref.current.position.y > 0) {
        //     speed *= 2.5
        // }

        // const dist = ref.current.position.distanceTo(window.playerBox.position)
        //
        // // console.log(dist)
        // if (dist > 0.52) {
        //     window.playerMoving = true
        // } else {
        //     window.playerMoving = false
        // }


        const rightVector = new THREE.Vector3();
        rightVector.crossVectors(camera.up, direction).normalize();

        const moveDirection = new THREE.Vector3();
        if (forward.current || window.dir.includes('up')) moveDirection.add(direction.normalize());
        if (back.current || window.dir.includes('down')) moveDirection.add(direction.normalize().negate());
        if (right.current || window.dir.includes('right')) moveDirection.add(rightVector.negate());
        if (left.current || window.dir.includes('left')) moveDirection.add(rightVector);

        if (window.playerMoving) {
            // window.playerIdle?.()
        }
        window.playerMoving = false
        // console.log(window.playerMoving)
        if (moveDirection.length() > 0) {

            // console.log(!window.playerMoving + ', ' +  window.playerWalk)
            if (!window.playerMoving) {
                // console.log('walkt')
                // console.log(window.playerWalk)
                window.playerWalk?.()
            }
            window.playerMoving = true

            moveDirection.normalize();
            ref.current.position.addScaledVector(moveDirection, speed);
            // console.log(ref.current.position)

            const targetPosition = rotationTarget.current.position.clone().add(moveDirection);
            rotationTarget.current.lookAt(targetPosition);
        } else {
            window.playerIdle?.()
            window.playerMoving = false

        }

        if (rotationTarget.current) {
            const step = 0.2;
            ref.current.quaternion.slerp(new THREE.Quaternion().setFromEuler(rotationTarget.current.rotation), step);
        }


        if (ref.current.position.y < 0) {
            ref.current.position.y = 0
        }

        // if (ref.current.position.y > 0) {
        //     ref.current.position.y = 0
        // }

        if (state.controls) {
            let num = 1.0;

            const refForward = new THREE.Vector3(0, 0, -1).applyQuaternion(ref.current.quaternion);

            const cameraForward = new THREE.Vector3(0, 0, -1).applyQuaternion(state.controls.camera.quaternion);

            const dot = refForward.dot(cameraForward);

            let dist = state.controls.distance * 0.02


            if (dot > 0 && dist < 2) {
                num = 1.2;
            }

            state.controls.moveTo(
                ref.current.position.x + 0.0,
                ref.current.position.y + num + dist,
                ref.current.position.z, true
            );
        }


        if (!window.dir && !window.playerMoving) {
            // console.log(window.dir)
            const step = 0.02;

            const currentEuler = new THREE.Euler().setFromQuaternion(ref.current.quaternion, 'YXZ');
            const targetEuler = new THREE.Euler(0, currentEuler.y, 0, 'YXZ');
            const targetQuaternion = new THREE.Quaternion().setFromEuler(targetEuler);
            rotationTarget.current.quaternion.slerp(targetQuaternion, step);


            if (!flying.current && window.playerBox) {
                ref.current.position.lerp(new THREE.Vector3(playerBox.position.x, ref.current.position.y, playerBox.position.z), 0.2)

                // console.log(ref.current.position)
            }


        } else {

        }

        // console.log(targetHeight.current)

        // console.log(fly)
        if (!flying.current) {


            const targetH = new THREE.Vector3(ref.current.position.x, targetHeight.current, ref.current.position.z)
            // console.log(targetHeight.current)
            if (targetHeight.current && targetHeight.current < 0.5) {
                ground = true
                targetH.y = targetHeight.current - Math.sin(state.clock.elapsedTime * 4) * 0.5
                const targetH = new THREE.Vector3(ref.current.position.x, targetHeight.current - Math.sin(state.clock.elapsedTime * 4) * 0.5 - (((window.dir || window.playerMoving) ? 2 : 1)), ref.current.position.z)
                ref.current.position.lerp(targetH, 0.4)
            }
            // console.log(targetH.y)

            // console.log(targetHeight.current)

            ref.current.position.lerp(targetH, targetHeight.current > ref.current.position.y ? 0.5 : 0.1)

        }
        // }

        if (flying.current && ref.current.position.y < targetHeight.current) {
            // console.log('down')
            flying.current = false
        }


        if (!flying.current && window.playerBox) {
            // console.log(ref.current.position)
            window.playerBox.position.lerp(new THREE.Vector3(Math.round(ref.current.position.x), ref.current.position.y + 0.5, Math.round(ref.current.position.z)), 0.3)
        }

        lagRef.current.position.lerp(ref.current.position, 0.03)

        lagRef.current.quaternion.slerp(rotationTarget.current.quaternion, 0.02)


        // lagRef.current.rotation.set(ref.current.rotation)

        window.playerPosition = ref.current.position
        window.playerLagPosition = lagRef.current.position
        window.playerLagQuaternion = lagRef.current.quaternion

        if (window.terrainMesh) {
            // console.log('ter')
            window.terrainMesh.material.uniforms.playerPos.value = ref.current.position


        }

        if (window.bigMapMaterial) {
            window.bigMapMaterial.current.uniforms.playerPos.value = ref.current.position
        }

        if (window.bitmonMountainsMesh) {
            window.bitmonMountainsMesh.material.uniforms.playerPos.value = ref.current.position
        }

        if (window.boxelInstancesMesh) {
            window.boxelInstancesMesh.material.uniforms.playerPos.value = ref.current.position
        }

        const newX = Math.round(ref.current.position.x)
        const newY = Math.round(ref.current.position.z)

        if (newX !== lastX.current || newY !== lastY.current) {
            lastX.current = newX
            lastY.current = newY
            currentTileStore.set({
                currentTile: {
                    x: Math.round(ref.current.position.x),
                    y: Math.round(ref.current.position.z)
                }
            })


            const zoneX = Math.floor((ref.current.position.x) / 100)
            const zoneY = Math.floor((ref.current.position.z) / 100)


            const bitmap = parseInt((zoneY * 1000) + zoneX)

            // console.log('set current bitmap')
            // console.log(bitmap)
            currentBitmapStore.set({currentBitmap: bitmap, zoneX, zoneY})


            if (window.midMesh) {
                window.midMesh.position.set(zoneX * 100 + 100, -1, zoneY * 100 + 100)
            }


            window.currentHeight = ref.current.position.y
        }


        if (window.playerMoving && !window.currentlyMoving) {
            // console.log('start move')
            window.currentlyMoving = true

            if (!window.setShowDust) return
            window.setShowDust(true)
        } else if (window.currentlyMoving && !window.playerMoving) {
            // console.log('end move')
            window.currentlyMoving = false

            if (!window.setShowDust) return
            window.setShowDust(false)
        }


    });

    return {ref}
}

window.useWASDcontroller = useWASDcontroller

const PlayerBox = () => {
    const ref = useRef()

    const hover = useRef(false)

    useEffect(() => {
        window.playerBox = ref.current
    }, [])

    return (
        <group onClick={() => {
            // window.jump()
        }} ref={ref}>
            <mesh visible={false} scale={[1, 1.5, 1]} position-y="0.25">
                <boxGeometry/>
                <meshBasicMaterial wireframe/>
            </mesh>


        </group>
    )
}

export const Player = (props) => {

    const hoverRef = useRef()

    const [copter, setCopter] = useState(false)


    useEffect(() => {
        // console.log(copter)
    }, [copter])

    useEffect(() => {
        window.setCopter = setCopter
        window.copter = copter
    }, [setCopter, copter])

    const {ref} = useWASDcontroller()

    const jump = useCallback(() => {


        window.jumping = true

        ref.current.position.y += 3.4

        setTimeout(() => {
            // ref.current.position.y += 1
        }, 50)


        setTimeout(() => {
            window.jumping = false
        }, 1100)

    }, [])

    useEffect(() => {
        window.jump = jump
        window.playerRef = ref
        window.playerBoxRef = playerBox

        setTimeout(() => {
            return
            ref.current.position.x = 333 * 100 + 99
            playerBox.position.x = 333 * 100 + 99


            ref.current.position.z = 333 * 100 + 99
            playerBox.position.z = 333 * 100 + 99

            window.cam.rotateTo(1, 1.3, true)

            window.dir = 'up'

            setTimeout(() => {
                window.dir = ''
                window.cam.rotateTo(1, 1.6, true)
                window.cam.dollyTo(15, true)
            }, 1200)


        }, 3000)

    }, [ref, jump])


    const eyeColor = useMemo(() => {
        return new THREE.Color(Math.random() * 2 + 0.5, Math.random() * 2 + 0.5, Math.random() * 2 + 0.5)
    }, [])

    const Companion = ({offsetX = 0, offsetY = 0, offsetZ = 0}) => {
        const companionRef = useRef()


        useFrame(() => {
            if (window.playerPosition) {

                let x = 1
                let y = 2
                let z = 0

                let scale = [0.2, 0.2, 0.2]

                if (ref.current.position.y - 1 > window.currentElev) {
                    x = 0
                    y = 0.5
                    z = 0

                    scale = [0.8, 0.8, 0.8]

                    ref.current.scale.set(0.0, 0.0, 0.0)

                    companionRef.current.scale.set(...scale)

                    companionRef.current.position.set(window.playerPosition.x + x, window.playerPosition.y + y, window.playerPosition.z + offsetZ)

                    companionRef.current.quaternion.copy(window.playerLagQuaternion)

                    window.emit1?.current?.emitterRef?.current?.position.copy(companionRef.current.position.clone().add(new THREE.Vector3(0, -0.4, 0)))

                    window.emit1?.current.setRate(100)

                    window.flying = true
                } else {

                    window.flying = false

                    scale = [0.2, 0.2, 0.2]

                    ref.current.scale.set(1, 1, 1)

                    companionRef.current.scale.set(...scale)

                    companionRef.current.position.set(window.playerLagPosition.x + x, window.playerLagPosition.y + y, window.playerLagPosition.z + offsetZ)

                    companionRef.current.quaternion.copy(window.playerLagQuaternion)


                    window.emit1?.current?.emitterRef?.current?.position.copy(companionRef.current.position)

                    window.emit1?.current.setRate(12)
                }

            }
        })

        return (
            <group ref={companionRef}>
                <Bitcopter/>
            </group>
        )
    }

    return (
        <group>
            <Companion offsetX={0}/>
            <PlayerBox/>


            <group ref={ref} position-x={0} position-z={0} scale="0.9">




                <group onPointerEnter={() => {
                    // hoverRef.current.visible = true
                    // ref.current.position.y += 0.03
                }} onPointerLeave={() => {
                    // hoverRef.current.visible = false
                }} onClick={() => {
                    // jump()
                    ref.current.position.y += 0.06
                }}>
                    <PlayerChat />
                    <mesh ref={hoverRef} visible={false} scale={[1.0, 1.8, 0.7]} position-y="1">
                        <boxGeometry/>
                        <meshBasicMaterial wireframe/>
                    </mesh>
                </group>

                <group>
                    {props.children}
                </group>

            </group>
        </group>
    )
}
