import {codeOpenStore, showSettingsStore} from "../../modules/stores.mjs";

export const BottomButtons = () => {
    return (
        <div
            className="flex -mr-3 text-xl text-white"
            onClick={(e) => {
                e.stopPropagation();
            }}
        >
            {/* Settings Button */}
            <div className="relative group">
                <button
                    onClick={() => {
                        showSettingsStore.set((s) => ({
                            showSettings: !s.showSettings,
                        }));
                    }}
                    className="ml-1 pt-1 w-12 h-9 opacity-70 hover:opacity-100 active:opacity-50 bg-neutral-800 flex justify-center items-center"
                >
                    ⚙️
                </button>
                <div className="transition-all truncate absolute -ml-0 bottom-11 left-1/2 -translate-x-1/2 text-xl text-orange-400 gloww bg-black bg-opacity-80 rounded-md px-2 py-1 opacity-0 group-hover:opacity-100 pointer-events-none">
                   settings
                </div>
            </div>

            {/* Fullscreen Button */}
            <div className="relative group">
                <button
                    className="ml-1 pt-1 w-12 h-9 text-neutral-400 opacity-70 active:opacity-50 hover:opacity-100 bg-neutral-800 flex justify-center items-center"
                    onClick={() => {
                        if (!document.fullscreenElement) {
                            document.documentElement
                                .requestFullscreen()
                                .catch((err) => {
                                    console.error(
                                        `Error attempting to enable fullscreen mode: ${err.message} (${err.name})`
                                    );
                                });
                        } else {
                            document.exitFullscreen().catch((err) => {
                                console.error(
                                    `Error attempting to exit fullscreen mode: ${err.message} (${err.name})`
                                );
                            });
                        }
                    }}
                >
                    🖥️
                </button>
                <div className="transition-all truncate absolute bottom-11 left-1/2 -translate-x-1/2 text-xl text-orange-400 gloww bg-black bg-opacity-80 rounded-md px-2 py-1 opacity-0 group-hover:opacity-100 pointer-events-none">
                    fullscreen
                </div>
            </div>

            {/* Code Button */}
            <div className="relative group">
                <button onClick={() => {
                    codeOpenStore.set({codeOpen: !codeOpenStore.state.codeOpen})
                }} className="ml-1 -mr-0.5 pt-1 w-14 h-9 opacity-70 hover:opacity-100 active:opacity-50 bg-neutral-800 flex justify-center items-center">
                    <div className="flex text-[18px] font-mono text-orange-400 gloww font-bold justify-center text-orange-100">
                        {'code'}
                    </div>
                </button>
                <div className="transition-all truncate absolute -ml-14 bottom-11 left-1/2 -translate-x-1/2 text-xl text-orange-400 gloww bg-black bg-opacity-80 rounded-md px-2 py-1 opacity-0 group-hover:opacity-100 pointer-events-none">
                    open code editor
                </div>
            </div>
        </div>
    );
};
