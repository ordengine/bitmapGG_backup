import {DragContainer} from "./DragContainer.jsx";
import React, {useEffect, useRef, useState} from "react";
import {useStore} from "statery";
import {currentBitmapStore, hoveredBitmapStore, startedStore} from "../../modules/stores.mjs";
import {useThree} from "@react-three/fiber";
import * as THREE from "three";
import {getCoordinates} from "../../modules/utils.mjs";

export const CurrentBitmapPanel = (props) => {

    const ref = useRef()
    const htmlRef = useRef()
    const materialRef = useRef()

    const [isBitmon, setIsBitmon] = useState(false)

    const bitmonDivRef = useRef(null);


    const [flyToPanelOpen, setFlyToPanelOpen] = useState(false)

    const target = useRef(new THREE.Object3D())


    const {currentBitmap} = useStore(currentBitmapStore)


    useEffect(() => {

            let mondrian = window.bitmaps[currentBitmap]?.bitmon?.mondrian


            if (mondrian?.slots?.length > 0) {
                const padd = 0.7
                const mondrianSize = mondrian.getSize();

                const scaleX = bitmonDivRef.current.clientWidth / (mondrianSize.width - padd);
                const scaleY = bitmonDivRef.current.clientHeight / (mondrianSize.height - padd);
                const scale = Math.min(scaleX, scaleY);

                const offsetX = (bitmonDivRef.current.clientWidth - (mondrianSize.width - padd) * scale) / 2;
                const offsetY = (bitmonDivRef.current.clientHeight - (mondrianSize.height - padd) * scale) / 2;

                // bitmonDivRef.current.style.width = '32px';

                bitmonDivRef.current.innerHTML = '';

                for (let i = 0; i < mondrian.slots.length; i++) {
                    const slot = mondrian.slots[i];
                    const x = slot.position.x * scale;
                    const y = slot.position.y * scale;
                    const size = (slot.size - padd) * scale;

                    const childDiv = document.createElement('div');
                    childDiv.style.position = 'absolute';
                    childDiv.style.left = `${offsetX + x + 4}px`;
                    childDiv.style.top = `${offsetY + y + 4}px`;
                    childDiv.style.width = `${size}px`;
                    childDiv.style.height = `${size}px`;
                    childDiv.style.backgroundColor = '#ff9900';

                    childDiv.className += 'ring-2 ring-black text-orange-900 gloww flex justify-center items-center text-sm font-mono'

                    childDiv.onmouseover = () => {
                        childDiv.style.backgroundColor = 'limegreen';
                        childDiv.textContent = `${i}`;
                    };
                    childDiv.onmouseout = () => {
                        childDiv.style.backgroundColor = '#ff9900';
                        childDiv.textContent = '';
                    };
                    childDiv.onclick = () => {
                        console.log(`Clicked on parcel ${i}`);
                    };

                    console.log(childDiv)
                    bitmonDivRef.current.appendChild(childDiv);
                }
                setIsBitmon(true)
            } else {
                bitmonDivRef.current.replaceChildren()
                // bitmonDivRef.current.style.width = '5px';
                setIsBitmon(false)
            }

    }, [setIsBitmon, currentBitmap])



    return (
        <>
            <DragContainer id={"MacroButton" + Math.random()} defaultX={1} defaultY={0} {...props}>
                <div className="text-sm p-0 opacity-80 hover:opacity-100 border-4 border-opacity-60 hover:border-opacity-80 border-orange-400 bg-neutral-800 bg-opacity-40 rounded-sm">
                    {/* Up Button */}
                    <div onClick={() => {
                        setFlyToPanelOpen(s => !s)
                    }}
                         className="hover:ring-2 ring-orange-500 boxGlow select-none w-[90px] h-[111px] border-orange-400 bg-neutral-900 border-opacity-90 hover:border-opacity-70 transition-all bg-opacity-80 rounded-sm flex flex-col justify-center items-center cursor-pointer"

                    >
                        <div ref={bitmonDivRef} className={'relative -left-1 mb-2 w-16 h-16'}>

                        </div>

                        {
                            isBitmon ? (
                                null
                            ) : (
                                <div className={'-mt-20 w-20 h-20 border-4 border-orange-400 rounded-sm bg-lime-700'}>
                                </div>
                            )
                        }

                        <div className={'text-orange-400 -mb-2.5 flex items-center justify-center'}>
                            <div className={'w-4 h-4 mr-1 rounded-sm  bg-orange-400'}>

                            </div>
                            <span className={'font-sans gloww text-lg'}>{currentBitmap}</span>
                        </div>
                    </div>
                </div>
            </DragContainer>



            {!flyToPanelOpen ? null : (
                <div onClick={() => {
                    // console.log('cloc')
                    setFlyToPanelOpen(false)
                }} style={{zIndex: 100000000000000}} className={'flex justify-center items-center w-full h-full absolute left-0 top-0 bg-neutral-900 bg-opacity-80'}>

                    <div onClick={(e) => {
                        e.stopPropagation()
                    }} className={'text-4xl gloww text-orange-400 flex flex-col items-center justify-center w-1/2 h-64 ring-2 bg-neutral-900 ring-orange-400 rounded-sm opacity-90'}>
                        <div className={'py-2'}>
                            fly to block
                        </div>
                        <div>
                            <input id={'bitmapInput'} placeholder={0} type={'number'} className={'font-sans bg-neutral-700 ring-2 ring-orange-500 px-2 my-2 h-12 w-44'} />
                        </div>
                        <div className={'p-4'}>
                            <button onClick={() => {

                                const bitmapNumber = parseInt(document.querySelector('#bitmapInput').value.replaceAll(',', ''))

                                // console.log(bitmapNumber)

                                const coord = getCoordinates(bitmapNumber)

                                // console.log(coord)

                                const tile = [coord.x, coord.y]

                                // console.log(tile)

                                window.playerRef.current.position.x = tile[0] * 100 + 50;
                                window.playerBoxRef.position.x = tile[0] * 100 + 50;
                                window.playerRef.current.position.z = tile[1] * 100 + 50;
                                window.playerBoxRef.position.z = tile[1] * 100 + 50;

                                setFlyToPanelOpen(false)

                            }} className={'ring-2 gloww hover:bg-neutral-800 active:ring-4 ring-orange-400 rounded-sm px-4'}>
                                go >
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </>
    )
}
