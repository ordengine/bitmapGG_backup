import {healthBarStore, peerStore} from "../../modules/stores.mjs";
import {useStore} from "statery";
import {DragContainer} from "./DragContainer.jsx";
import React from "react";

export const HealthBars = () => {

    const {healthBars} = useStore(healthBarStore)


    return (
        <div>
            {healthBars.map(bar => {

                return (
                    <DragContainer defaultX={0.45} defaultY={0.3}>
                        <div className={'flex flex-col'}>
                            <div
                                className="opacity-100 border-4 border-opacity-60 hover:border-opacity-80 border-orange-400 bg-neutral-800 bg-opacity-70 p-1">
                                <div className="flex items-center">


                                    {/* Health Information */}
                                    <div className="flex-1 leading-3">
                                        <div className="gloww text-[18px] text-blue-300 my-1 pl-1 flex">
                                            <div className={'w-32 truncate'}>{bar.peerId }</div>
                                            <span className="opacity-50 text-lime-400">[GUILD]</span>
                                        </div>

                                    </div>



                                </div>


                                {/* Health Bar Background */}
                                <div className="w-full mt-0.5 h-2.5 bg-gray-300 rounded-md overflow-hidden">
                                    {/* Health Bar Filled */}
                                    <div
                                        className={`bg-lime-500 h-full transition-all duration-300`}
                                        style={{width: `${bar.hp || 100}%`}}
                                    ></div>
                                </div>


                            </div>


                        </div>
                    </DragContainer>
                )
            })}
        </div>
    )
}
