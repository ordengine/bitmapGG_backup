import React, {useRef, useEffect, useCallback, useState, useMemo} from 'react';
import {makeStore, useStore} from 'statery';
import {useSpring} from '@react-spring/three';
import {GizmoHelper, GizmoViewport, TransformControls} from '@react-three/drei';
import {useFrame, useThree} from '@react-three/fiber';

import {boxelGeometry} from 'boxelGeometry';

import '../modules/stores.mjs'
import {useControls} from "leva";
import {avatarModelStore, editTypeStore} from "../../modules/stores.mjs";

window.transformSettings = {
    translationSnap: 0.001,
    rotationSnap: 0.001,
    scaleSnap: 0.001,
};


export const ItemBuilder = () => {
    const {controls, camera, gl} = useThree();
    const groupRef = useRef();
    const transformControlsRef = useRef();

    const {boxels} = useStore(boxelStore);
    const {mode} = useStore(modeStore);

    const mouseDown = useRef(false);
    const mouseDragged = useRef(0);

    // Keep track of the selected mesh
    const selectedMeshRef = useRef(null);

    const lastSelectedBoxelId = useRef(0)
    const selectedBoxel = useMemo(() => {
        const selected = boxels.find((b) => b.selected);
        // console.log('newlastsel: ' + lastSelectedBoxelId.current)
        return selected
    }, [boxels])


// Use controls for RGB sliders, opacity, and shine, tied to dynamically update the store
    const [{red, green, blue, opacity, roughness, metalness}, setColor] = useControls(
        'edit selected boxel',
        () => ({
            red: {
                value: 0.0,
                min: 0,
                max: 3,
                onChange: (v) => {
                    if (!selectedBoxel) return
                    let newlySelected = false
                    if (lastSelectedBoxelId.current !== selectedBoxel.boxelId) {
                        newlySelected = true
                        setColor({
                            red: selectedBoxel.color.r,
                            green: selectedBoxel.color.g,
                            blue: selectedBoxel.color.b,
                            opacity: selectedBoxel.opacity,
                            roughness: selectedBoxel.roughness,
                            metalness: selectedBoxel.metalness,
                            shading: selectedBoxel.shading
                        })
                    }

                    setTimeout(() => {

                        lastSelectedBoxelId.current = selectedBoxel.boxelId

                        if (!newlySelected && selectedBoxel) {
                            const arr = [...boxels];
                            const index = arr.findIndex((b) => b.boxelId === selectedBoxel.boxelId);

                            // console.log(arr[index])

                            if (index !== -1) {
                                arr[index].color.r = v; // Update r value
                                boxelStore.set({boxels: arr});
                            }
                        }
                    }, 1)
                }
            },
            green: {
                value: 0.0,
                min: 0,
                max: 3,
                onChange: (v) => {
                    if (!selectedBoxel) return
                    let newlySelected = false
                    if (lastSelectedBoxelId.current !== selectedBoxel.boxelId) {
                        newlySelected = true
                        setColor({
                            red: selectedBoxel.color.r,
                            green: selectedBoxel.color.g,
                            blue: selectedBoxel.color.b,
                            opacity: selectedBoxel.opacity,
                            roughness: selectedBoxel.roughness,
                            metalness: selectedBoxel.metalness,
                            shading: selectedBoxel.shading
                        })
                    }

                    setTimeout(() => {

                        lastSelectedBoxelId.current = selectedBoxel.boxelId

                        if (!newlySelected && selectedBoxel) {
                            const arr = [...boxels];
                            const index = arr.findIndex((b) => b.boxelId === selectedBoxel.boxelId);
                            if (index !== -1) {
                                arr[index].color.g = v; // Update r value
                                boxelStore.set({boxels: arr});
                            }
                        }
                    }, 1)
                }
            },
            blue: {
                value: 0.0,
                min: 0,
                max: 3,
                onChange: (v) => {
                    if (!selectedBoxel) return
                    let newlySelected = false
                    if (lastSelectedBoxelId.current !== selectedBoxel.boxelId) {
                        newlySelected = true
                        setColor({
                            red: selectedBoxel.color.r,
                            green: selectedBoxel.color.g,
                            blue: selectedBoxel.color.b,
                            opacity: selectedBoxel.opacity,
                            roughness: selectedBoxel.roughness,
                            metalness: selectedBoxel.metalness,
                            shading: selectedBoxel.shading
                        })
                    }

                    setTimeout(() => {

                        lastSelectedBoxelId.current = selectedBoxel.boxelId

                        if (!newlySelected && selectedBoxel) {
                            const arr = [...boxels];
                            const index = arr.findIndex((b) => b.boxelId === selectedBoxel.boxelId);
                            if (index !== -1) {
                                arr[index].color.b = v; // Update r value
                                boxelStore.set({boxels: arr});
                            }
                        }
                    }, 1)
                }
            },
            opacity: {
                value: 1,
                min: 0.02,
                step: 0.01,
                max: 1,
                onChange: (v) => {
                    if (!selectedBoxel) return
                    let newlySelected = false
                    if (lastSelectedBoxelId.current !== selectedBoxel.boxelId) {
                        newlySelected = true
                        setColor({
                            red: selectedBoxel.color.r,
                            green: selectedBoxel.color.g,
                            blue: selectedBoxel.color.b,
                            opacity: selectedBoxel.opacity,
                            roughness: selectedBoxel.roughness,
                            metalness: selectedBoxel.metalness,
                            shading: selectedBoxel.shading
                        })
                    }

                    setTimeout(() => {

                        lastSelectedBoxelId.current = selectedBoxel.boxelId

                        if (!newlySelected && selectedBoxel) {
                            const arr = [...boxels];
                            const index = arr.findIndex((b) => b.boxelId === selectedBoxel.boxelId);
                            if (index !== -1) {
                                arr[index].opacity = v; // Update r value
                                boxelStore.set({boxels: arr});
                            }
                        }
                    }, 1)
                }
            },
            shading: {
                value: true,
                onChange: (v) => {
                    if (!selectedBoxel) return
                    let newlySelected = false
                    if (lastSelectedBoxelId.current !== selectedBoxel.boxelId) {
                        newlySelected = true
                        setColor({
                            red: selectedBoxel.color.r,
                            green: selectedBoxel.color.g,
                            blue: selectedBoxel.color.b,
                            opacity: selectedBoxel.opacity,
                            roughness: selectedBoxel.roughness,
                            metalness: selectedBoxel.metalness,
                            shading: selectedBoxel.shading
                        })
                    }

                    setTimeout(() => {

                        lastSelectedBoxelId.current = selectedBoxel.boxelId

                        if (!newlySelected && selectedBoxel) {
                            const arr = [...boxels];
                            const index = arr.findIndex((b) => b.boxelId === selectedBoxel.boxelId);
                            if (index !== -1) {
                                arr[index].shading = v; // Update r value
                                boxelStore.set({boxels: arr});
                            }
                        }
                    }, 1)
                }
            },
            roughness: {
                value: 0.5,
                min: 0,
                max: 1,
                onChange: (v) => {
                    if (!selectedBoxel) return
                    let newlySelected = false
                    if (lastSelectedBoxelId.current !== selectedBoxel.boxelId) {
                        newlySelected = true
                        setColor({
                            red: selectedBoxel.color.r,
                            green: selectedBoxel.color.g,
                            blue: selectedBoxel.color.b,
                            opacity: selectedBoxel.opacity,
                            roughness: selectedBoxel.roughness,
                            metalness: selectedBoxel.metalness,
                            shading: selectedBoxel.shading
                        })
                    }

                    setTimeout(() => {

                        lastSelectedBoxelId.current = selectedBoxel.boxelId

                        if (!newlySelected && selectedBoxel) {
                            const arr = [...boxels];
                            const index = arr.findIndex((b) => b.boxelId === selectedBoxel.boxelId);
                            if (index !== -1) {
                                arr[index].roughness = v; // Update r value
                                boxelStore.set({boxels: arr});
                            }
                        }
                    }, 1)
                }
            },
            metalness: {
                value: 0.5,
                min: -1,
                max: 1,
                onChange: (v) => {
                    if (!selectedBoxel) return
                    let newlySelected = false
                    if (lastSelectedBoxelId.current !== selectedBoxel.boxelId) {
                        newlySelected = true
                        setColor({
                            red: selectedBoxel.color.r,
                            green: selectedBoxel.color.g,
                            blue: selectedBoxel.color.b,
                            opacity: selectedBoxel.opacity,
                            roughness: selectedBoxel.roughness,
                            metalness: selectedBoxel.metalness,
                            shading: selectedBoxel.shading
                        })
                    }

                    setTimeout(() => {

                        lastSelectedBoxelId.current = selectedBoxel.boxelId

                        if (!newlySelected && selectedBoxel) {
                            const arr = [...boxels];
                            const index = arr.findIndex((b) => b.boxelId === selectedBoxel.boxelId);
                            if (index !== -1) {
                                arr[index].metalness = v; // Update r value
                                boxelStore.set({boxels: arr});
                            }
                        }
                    }, 1)
                }
            },


        }),
        {collapsed: true, color: '#ffda53'}, [selectedBoxel]
    );

    // Use controls for RGB sliders, tied to the colorState, to dynamically update
    const [{shape}, setShape] = useControls(
        'edit selected boxel',
        () => ({
            shape: {
                value: 1,
                min: 0,
                max: 10,
                step: 1,
                onChange: (v) => {
                    if (!selectedBoxel) return
                    let newlySelected = false
                    if (lastSelectedBoxelId.current !== selectedBoxel.boxelId) {
                        newlySelected = true
                        setShape({
                            shape: selectedBoxel.shape,
                        })
                    }

                    setTimeout(() => {

                        lastSelectedBoxelId.current = selectedBoxel.boxelId

                        if (!newlySelected && selectedBoxel) {
                            const arr = [...boxels];
                            const index = arr.findIndex((b) => b.boxelId === selectedBoxel.boxelId);
                            if (index !== -1) {
                                arr[index].shape = v; // Update r value
                                boxelStore.set({boxels: arr});
                            }
                        }
                    }, 1)
                }
            }
        }), {collapsed: true},
        [selectedBoxel] // This ensures that the controls are tied to the state of the selected boxel
    );

    // Use controls for RGB sliders, tied to the colorState, to dynamically update
    const [{hideDefault}, setHideDefault] = useControls(
        'edit selected boxel',
        () => ({
            hideDefault: {
                value: false,
                label: 'hide base',
                onChange: (v) => {
                    if (!selectedBoxel) return
                    let newlySelected = false
                    if (lastSelectedBoxelId.current !== selectedBoxel.boxelId) {
                        newlySelected = true
                        setHideDefault({
                            hideDefault: selectedBoxel.hideDefault,
                        })
                    }

                    setTimeout(() => {

                        lastSelectedBoxelId.current = selectedBoxel.boxelId

                        if (!newlySelected && selectedBoxel) {
                            const arr = [...boxels];
                            const index = arr.findIndex((b) => b.boxelId === selectedBoxel.boxelId);
                            if (index !== -1) {
                                arr[index].hideDefault = v; // Update r value
                                boxelStore.set({boxels: arr});
                            }
                        }
                    }, 1)
                }
            }
        }), {collapsed: true},
        [selectedBoxel] // This ensures that the controls are tied to the state of the selected boxel
    );



    const BoxelEditable = (props) => {
        const ref = useRef();
        const wireframe = useRef();

        useEffect(() => {
            window.currentEditableBoxel = ref.current;
            window.wireframes.push(wireframe.current);
        }, [controls, props.selected]);

        const events = {
            onClick: (e) => {
                if (mouseDragged.current > 5) return;
                e.stopPropagation();
                if (!props.selected) {
                    window.setSelectedBoxel(props.boxelId);
                }

                const pos = ref.current.position;
                controls.moveTo(pos.x, pos.y, pos.z, true);

                if (props.selected) {
                    selectedMeshRef.current = ref.current;
                }

                transformControlsRef.current.setSize(1)

                if (mode === null) {
                    modeStore.set({mode: 'translate'})
                    transformControlsRef.current.setMode('translate');
                }
            },
            onDoubleClick: (e) => {
                const pos = ref.current.position;
                controls.moveTo(pos.x, pos.y, pos.z, true);
            },
        };

        return (
            <group
                ref={ref}
                name={props.boxelId}
                position={props.position}
                scale={props.scale}
                quaternion={props.quaternion}
                {...events}
            >
                {props.shading === false ? (
                    <mesh geometry={boxelGeometry[props.shape]} renderOrder={1}>
                        <meshBasicMaterial color={props.color} transparent opacity={props.opacity}/>
                    </mesh>
                ) : props.opacity < 1 ? (
                    <mesh geometry={boxelGeometry[props.shape]} renderOrder={2}>
                        <meshStandardMaterial flatShading color={props.color} transparent opacity={props.opacity}
                                              roughness={props.roughness} metalness={props.metalness}/>
                    </mesh>
                ) : (
                    <mesh geometry={boxelGeometry[props.shape]} renderOrder={0}>
                        <meshStandardMaterial flatShading color={props.color}
                                              roughness={props.roughness} metalness={props.metalness}/>
                    </mesh>
                )}
            </group>
        );
    };

    const saveBoxel = useCallback(() => {
        groupRef.current.children.forEach((c) => {
            const position = c.position.clone();
            const scale = c.scale.clone();
            const quaternion = c.quaternion.clone();

            const arr = Array.from(boxels);
            for (let i = 0; i < arr.length; i++) {
                if (arr[i].boxelId === c.name) {
                    arr[i].position = position;
                    arr[i].scale = scale;
                    arr[i].quaternion = quaternion;
                }
            }
            boxelStore.set({boxels: arr});
        });
    }, [boxels]);

    const onPointerUp = useCallback(() => {
        saveBoxel();

        window.wireframes.forEach((w) => {
            if (w) {
                w.visible = true;
            }
        });

        window.mouseDown = false;
    }, [saveBoxel]);

    const onPointerDown = useCallback(() => {
        mouseDragged.current = 0;

        window.wireframes.forEach((w) => {
            if (w) {
                w.visible = false;
            }
        });

        window.mouseDown = true;
    }, []);

    const onPointerMove = useCallback(() => {
        mouseDragged.current += 1;
    }, []);

    const onKeyDown = useCallback(
        (e) => {
            const key = e.key.toLowerCase();

            // Get the currently selected boxel
            const selectedBoxel = boxels.find((b) => b.selected);

            // Ensure a boxel is selected before making mode changes
            if (selectedBoxel) {
                if (key === 'm' || key === 'g') {
                    modeStore.set({mode: 'translate'});
                    setSelectedBoxel(selectedBoxel.boxelId)
                    transformControlsRef.current.setSize(1)
                } else if (key === 'r') {
                    modeStore.set({mode: 'rotate'});
                    setSelectedBoxel(selectedBoxel.boxelId)
                    transformControlsRef.current.setSize(1)
                } else if (key === 's') {
                    modeStore.set({mode: 'scale'});
                    setSelectedBoxel(selectedBoxel.boxelId)
                    transformControlsRef.current.setSize(1)
                } else if (key === 'd') {
                    // Duplicate only when a boxel is selected
                    transformControlsRef.current.setSize(1)
                    window.duplicateBoxel(selectedBoxel.boxelId);
                } else if (key === 'delete') {
                    // Duplicate only when a boxel is selected
                    window.removeSelectedBoxel()
                }

                // Update the TransformControls mode if a boxel is selected
                if (transformControlsRef.current) {
                    if (key === 'm' || key === 'g') {
                        transformControlsRef.current.setMode('translate');
                        transformControlsRef.current.setSize(1)
                    } else if (key === 'r') {
                        transformControlsRef.current.setMode('rotate');
                        transformControlsRef.current.setSize(1)
                    } else if (key === 's') {
                        transformControlsRef.current.setMode('scale');
                        transformControlsRef.current.setSize(1)
                    }
                }
            }

            if (key === 'a') {
                // Duplicate only when a boxel is selected
                transformControlsRef.current.setSize(1)
                window.addBoxel();
            }
        },
        [boxels]
    );

    useEffect(() => {

        // Update the TransformControls mode if a boxel is selected
        if (transformControlsRef.current) {
            if (mode) {
                transformControlsRef.current.setSize(1)
                transformControlsRef.current.setMode(mode);
            } else {
                transformControlsRef.current.setSize(0)
            }
        }
    }, [mode])

    useEffect(() => {
        window.addEventListener('pointerdown', onPointerDown);
        window.addEventListener('pointermove', onPointerMove);
        window.addEventListener('pointerup', onPointerUp);
        window.addEventListener('keydown', onKeyDown);

        return () => {
            window.removeEventListener('pointerdown', onPointerDown);
            window.removeEventListener('pointermove', onPointerMove);
            window.removeEventListener('pointerup', onPointerUp);
            window.removeEventListener('keydown', onKeyDown);
        };
    }, [onPointerUp, onKeyDown]);

    // Attach the TransformControls to the selected mesh after it's fully mounted
    useEffect(() => {
        const selectedBoxel = boxels.find((b) => b.selected);
        if (selectedBoxel && transformControlsRef.current) {
            const object = groupRef.current.getObjectByName(selectedBoxel.boxelId);
            // console.log(object)
            if (object?.parent) {
                transformControlsRef.current.attach(object);
            }
        } else if (transformControlsRef.current) {
            transformControlsRef.current.detach();
        }
    }, [boxels]);

    useEffect(() => {
        setTimeout(() => {
            setSelectedBoxel('hammerHead')
        }, 400)
    }, [])


    const {headScale, bodyScale} = useStore(avatarModelStore)

    const {editType} = useStore(editTypeStore)

    const itemScale = useMemo(() => {

        if (editType === 'Head') {
            return headScale
        } else if (editType === 'Body') {
            return bodyScale
        } else {
            return [1, 1, 1]
        }


    }, [editType, headScale, bodyScale])


    const posss = useMemo(() => {

        if (editType === 'Head') {
            return [0, 0.1 - (1 - bodyScale[1]) - (1 - headScale[1]) * 0.5, 0.06]
        } else if (editType === 'Body') {
            return [0, -0.2 - (1 - bodyScale[1]) * 0.5, 0]
        } else {
            return [0, 0, 0]
        }


    }, [editType, headScale, bodyScale])

    useEffect(() => {
        const intt = setInterval(() => {

            let shapeFixedBoxels = []

            boxels.forEach(boxel => {
                boxel.angle = boxel.shape * 0.1 - 0.1
                shapeFixedBoxels.push(boxel)
                // console.log(boxel)
            })


            if (editType === 'Main Hand') {
                boxelBuildsStore.set({mainHandBuilds: shapeFixedBoxels})
            } else if (editType === 'Off Hand') {
                boxelBuildsStore.set({offHandBuilds: shapeFixedBoxels})
            } else if (editType === 'Body') {
                boxelBuildsStore.set({bodyBuilds: shapeFixedBoxels})
            } else if (editType === 'Head') {
                boxelBuildsStore.set({headBuilds: shapeFixedBoxels})
            } else if (editType === 'Arms') {
                boxelBuildsStore.set({armsBuilds: shapeFixedBoxels})
            } else if (editType === 'Legs') {
                boxelBuildsStore.set({legsBuilds: shapeFixedBoxels})
            } else if (editType === 'Feet') {
                boxelBuildsStore.set({feetBuilds: shapeFixedBoxels})
            } else if (editType === 'Gloves') {
                boxelBuildsStore.set({glovesBuilds: shapeFixedBoxels})
            } else if (editType === 'Free Build') {
                boxelBuildsStore.set({freeBuildBuilds: shapeFixedBoxels})
            }

        }, 1000)

        return () => clearInterval(intt)
    }, [editType, boxels])

    return (
        <>
            <TransformControls
                ref={transformControlsRef}
                args={[camera, gl.domElement]}
                {...transformSettings}
            />
            <group ref={groupRef} scale={itemScale} position={posss}>
                {boxels.map((boxel) => {
                    return <BoxelEditable key={boxel.boxelId} {...boxel} />;
                })}
            </group>

            <GizmoHelper
                alignment="bottom-right" // widget alignment within scene
                margin={[60, 60]} // widget margins (X, Y)
                renderPriority={2}
            >
                <GizmoViewport axisColors={['#ff2f00', '#1ede21', '#024bff']} labelColor={"#1b0526"}/>

            </GizmoHelper>
        </>
    );
};
