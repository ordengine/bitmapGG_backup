import React, { useState, useEffect, useRef } from 'react';
import { useDrag } from '@use-gesture/react';
import { useSpring, animated } from '@react-spring/web';
import { useStore } from 'statery';
import {codeOpenStore, startedStore} from '../../modules/stores.mjs';

export const DragContainer = ({ children, id, defaultX = 1, defaultY = 0.2 }) => {
    const containerRef = useRef(null);



    // Default position as percentage relative to the right and bottom edges
    const defaultRelativePosition = { x: defaultX, y: defaultY };

    let savedPosition = defaultRelativePosition;

    // You can uncomment this if you wish to use localStorage
    // try {
    //   savedPosition =
    //     JSON.parse(localStorage.getItem(`draggable-${id}`)) || defaultRelativePosition;
    // } catch (e) {
    //   savedPosition = defaultRelativePosition;
    // }

    const [relativePosition, setRelativePosition] = useState(savedPosition);

    const [spring, api] = useSpring(() => ({
        x: 0,
        y: 0,
        config: {
            mass: 0.5,
            tension: 1200,
            friction: 80,
        },
    }));

    // Save the position to localStorage
    useEffect(() => {
        try {
            // Uncomment to enable localStorage saving
            // localStorage.setItem(`draggable-${id}`, JSON.stringify(relativePosition));
        } catch (e) {
            console.error(e);
        }
    }, [relativePosition, id]);

    // Adjust position initially and on window resize
    useEffect(() => {
        const updatePosition = () => {
            if (containerRef.current) {
                const { offsetWidth, offsetHeight } = containerRef.current;
                const maxX = window.innerWidth - offsetWidth;
                const maxY = window.innerHeight - offsetHeight;

                // console.log(window.sceneDiv.current.clientHeight)

                const clampedX = Math.max(0, Math.min(relativePosition.x * maxX, maxX));
                const clampedY = Math.max(0, Math.min(relativePosition.y * maxY, maxY));

                api.start({ x: clampedX, y: clampedY });
            }
        };

        // console.log('upd')
        updatePosition();
        window.addEventListener('resize', updatePosition);
        return () => window.removeEventListener('resize', updatePosition);
    }, [relativePosition, api]);

    // Handle drag gesture
    const bind = useDrag(
        ({ offset: [ox, oy], event }) => {
            event.preventDefault();

            if (containerRef.current) {
                const { offsetWidth, offsetHeight } = containerRef.current;
                const maxX = window.innerWidth - offsetWidth;
                const maxY = window.innerHeight - offsetHeight;

                const clampedX = Math.max(0, Math.min(ox, maxX));
                const clampedY = Math.max(0, Math.min(oy, maxY));

                setRelativePosition({ x: clampedX / maxX, y: clampedY / maxY });

                api.start({ x: clampedX, y: clampedY });
            }
        },
        {
            from: () => [spring.x.get(), spring.y.get()],
            preventDefault: true,
            pointer: false,
            eventOptions: { passive: false },
        }
    );

    const { started } = useStore(startedStore);

    return (
        <animated.div
            {...bind()}
            ref={containerRef}
            style={{
                opacity: started ? '1.0' : '0',
                position: 'absolute',
                zIndex: 1000000000000,
                left: 0,
                top: 0,
                cursor: 'move',
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                userSelect: 'none',
                touchAction: 'none',
                transform: spring.x.to(
                    (x) => `translate3d(${x}px, ${spring.y.get()}px, 0)`
                ),
            }}
        >
            {children}
        </animated.div>
    );
};
