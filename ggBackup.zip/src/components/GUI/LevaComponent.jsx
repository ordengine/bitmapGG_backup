import {Leva} from "leva";
import {useStore} from "statery";
import {showSettingsStore} from "../../modules/stores.mjs";


export const LevaComponent = () => {
    const {showSettings} = useStore(showSettingsStore)

    return (
        <Leva hidden={!showSettings} />
    )
}
