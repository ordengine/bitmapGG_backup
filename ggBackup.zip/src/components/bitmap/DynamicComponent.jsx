import React, { useEffect, useState, useRef } from 'react';

class ErrorBoundary extends React.Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false };
    }

    static getDerivedStateFromError(error) {
        // Update state so the next render shows the fallback UI.
        return { hasError: true };
    }

    componentDidCatch(error, errorInfo) {
        // You can log the error to an error reporting service.
        console.error('ErrorBoundary caught an error', error, errorInfo);
    }

    resetErrorBoundary = () => {
        this.setState({ hasError: false });
    };

    render() {
        if (this.state.hasError) {
            // Render fallback UI and a retry button
            return (
                <mesh>
                    <boxGeometry />
                    <meshStandardMaterial color="red" />
                </mesh>
            );
        }

        return this.props.children;
    }
}

export const DynamicComponent = (props) => {
    const [Comp, setComp] = useState(null);
    const lastUpdateTime = useRef(0); // Track the last update time
    const throttleDelay = 200; // Delay in milliseconds

    useEffect(() => {
        const currentTime = Date.now();

        // Throttle logic: Skip update if last update was within throttle delay
        if (currentTime - lastUpdateTime.current < throttleDelay) {
            return;
        }

        console.log('recec');
        lastUpdateTime.current = currentTime;

        if (props.jsx) {
            try {
                // Try to transform the code
                const transformed = Babel.transform(props.jsx, {
                    presets: ['react'],
                });

                const importComponent = async (code) => {
                    const codeWithReactImport = `${code}`

                        // `import React, {useRef, useState, useEffect, useCallback, useMemo} from 'react'; ${code}`;

                    const blob = new Blob([codeWithReactImport], { type: 'text/javascript' });
                    const moduleUrl = URL.createObjectURL(blob);

                    try {
                        const module = await import(moduleUrl);

                        // Replace 'Component1' with the key of the exported component
                        const Component = module.default || module.Component1;

                        if (Component) {
                            setComp(() => Component);
                        } else {
                            console.error('No valid default/named export found in module');
                            setComp(null); // Reset the component to trigger fallback UI
                        }
                    } catch (error) {
                        console.error('Dynamic import error:', error.message);
                        setComp(null); // Reset the component to trigger fallback UI
                    } finally {
                        URL.revokeObjectURL(moduleUrl);
                    }
                };

                importComponent(transformed.code);
            } catch (error) {
                // Handle syntax errors during transformation
                console.error('Babel transform error:', error.message);
                setComp(null); // Reset the component to trigger fallback UI
            }
        }
    }, [props.jsx]);

    const renderComponent = () => {
        try {
            return Comp ? (
                <Comp {...props.props} />
            ) : (
                <mesh>
                    <boxGeometry />
                    <meshStandardMaterial color="red" />
                </mesh>
            );
        } catch (error) {
            console.error('Rendering error:', error);
            return (
                <mesh>
                    <boxGeometry />
                    <meshStandardMaterial color="red" />
                </mesh>
            );
        }
    };

    return (
        <ErrorBoundary key={props.jsx}>
            {renderComponent()}
        </ErrorBoundary>
    );
};
