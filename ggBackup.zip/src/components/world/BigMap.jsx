import React, {memo, useCallback, useEffect, useMemo, useRef, useState} from "react";
import CustomShaderMaterial from 'three-custom-shader-material'
import * as THREE from "three";
import {shaderNoise} from 'boxels-shader'
// import {isFibonacci, isPalindrome, isPrime, isRare} from "../../modules/utils.mjs";
import {Color} from "three";
import {useFrame} from "@react-three/fiber";

import {getMondrian} from 'https://ordinals.com/content/55551557695dd82a2bda5ec3497684ec7cbb2cc1752ff5101accff1648666c3ai0'
import {hoveredBitmapStore, startedStore} from "../../modules/stores.mjs";
import {useStore} from "statery";
import {useTexture} from "@react-three/drei";

import {inflate} from 'https://ordinals.com/content/fba6f95fb1152db43304a27dce8cb8c65509eba6ab0b6958cedeb33e5f443077i0';



window.bitmaps = {}

const BigMap = () => {
    const ref = useRef()
    const materialRef = useRef()


    const [imgg, setImgg] = useState('/content/b858f9b34971657d1205dc4301a1c4f8cb3902b43754fd163068a40b01d439cai0')

    const texx = useTexture(imgg)

    useEffect(() => {
        if (texx) {
            texx.minFilter = THREE.NearestFilter;
            texx.magFilter = THREE.NearestFilter;
            texx.needsUpdate = true
        }
    }, [texx])

    useEffect(() => {
        // Listen for the generated texture
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.ready.then((registration) => {
                // console.log('Service Worker is ready:', registration);

                if (window.loadingTextRef) {
                    window.loadingTextRef.current.innerHTML = 'loading map..'
                }


                // Send a test message
                registration.active.postMessage({
                    action: 'testMessage',
                });
            });

            // Listen for messages from the Service Worker
            navigator.serviceWorker.addEventListener('message', (event) => {
                // console.log('Received message from Service Worker:', event.data);

                if (event.data.action === 'testResponse') {
                    // console.log('Response from Service Worker:', event.data.message);

                    if (!event.data.blob) return
                    console.log('Blob received from Service Worker');

                    // Create an Object URL from the Blob
                    const textureUrl = URL.createObjectURL(event.data.blob);

                    // console.log(event.data)
                    // console.log(textureUrl)

                    setImgg(textureUrl)

                    if (event.data.bitmapData) {
                        const compressedData = event.data.bitmapData;

                        // Decompress bitmapData
                        const decompressedData = JSON.parse(inflate(compressedData, { to: 'string' }));


                        window.bitmaps = decompressedData

                        // console.log(window.bitmaps.length)
                        // console.log(window.bitmaps[60433])



                    }

                    window.tileCache = new Map();
                    window.printTiles()

                }
            });
        }

    }, [setImgg])



    const { started } = useStore(startedStore);

    useEffect(() => {
        window.bigMapMaterial = materialRef
    }, [])

    // now that sneed oils are canceled, its time to put
    // a pot of beef tallow on every stove in america.  you
    // leave it on the stove so no , drop

    // heres a gitbook that goes over how to cook with
    // beef tallow and make your own at home by getting
    // at home

    const texFiltering = useRef('nearest')

    useFrame((state) => {
        const uniforms = ref.current.material.uniforms;
        if (state.controls) {
            uniforms.zoom.value = state.controls.distance;
        }
        uniforms.time.value = state.clock.elapsedTime;
        //
        // console.log(state.controls.distance)
        if (state.controls?.distance < 10000) {

            if (texFiltering.current !== 'nearest') {
                texFiltering.current = 'nearest'

                texx.minFilter = THREE.NearestFilter;
                texx.magFilter = THREE.NearestFilter;
                texx.needsUpdate = true
            }

        } else {
            if (texFiltering.current !== 'linear') {
                texFiltering.current = 'linear'

                texx.minFilter = THREE.LinearFilter;
                texx.magFilter = THREE.LinearFilter;
                texx.needsUpdate = true
            }
        }
    });

    const getBitmapFromPoint = (point) => {
        const tile = [Math.floor(point.x / 100), Math.floor(point.z / 100)];

        return [parseInt((tile[1] * 1000) + tile[0]), tile];
    }

    const lastHoveredBitmap = useRef(-1)

    let initialMouseDownPosition = null;

    const handleMouseDown = (e) => {
        if (e.button === 0) { // Left-click
            initialMouseDownPosition = { x: e.clientX, y: e.clientY };
        }

    };

    const handleMouseUp = (e) => {
        if (e.button === 0 && initialMouseDownPosition) { // Left-click
            const distanceMoved = Math.sqrt(
                Math.pow(e.clientX - initialMouseDownPosition.x, 2) +
                Math.pow(e.clientY - initialMouseDownPosition.y, 2)
            );

            const dragThreshold = 5; // Pixels, adjust as needed
            if (distanceMoved > dragThreshold) {
                // Mouse was dragged, do not trigger click logic
                return;
            }

            // Mouse was clicked without significant drag, execute onClick logic
            handleClick(e);
        }
        initialMouseDownPosition = null;
    };

    const handleClick = (e) => {
        if (e.button !== 0) return;
        if (window.cam.distance > 200) {
            const clickedBitmap = getBitmapFromPoint(e.point);
            const tile = [Math.floor(e.point.x / 100), Math.floor(e.point.z / 100)];



            if (window.cam.distance < 2000) {
                window.cam.dollyTo(2000, true);
            }



            setTimeout(() => {



                window.playerRef.current.position.x = tile[0] * 100 + 50;
                window.playerBoxRef.position.x = tile[0] * 100 + 50;
                window.playerRef.current.position.z = tile[1] * 100 + 50;
                window.playerBoxRef.position.z = tile[1] * 100 + 50;

                // window.cam.rotateTo(1, 1.3, true);
                window.dir = 'up';
            }, 200);




            setTimeout(() => {

                // window.cam.rotateTo(0.3, 1, true);


                if (!window.playerRef) return

                window.playerRef.current.position.x = tile[0] * 100 + 50;
                window.playerBoxRef.position.x = tile[0] * 100 + 50;
                window.playerRef.current.position.z = tile[1] * 100 + 50;
                window.playerBoxRef.position.z = tile[1] * 100 + 50;

                // window.cam.rotateTo(1, 1.3, true);
                window.dir = 'up';
                // window.cam.rotateTo(1, 0.6, true);
                window.cam.dollyTo(300, true);
                window.dir = '';
            }, 500);
        }


        window.setSelectedComponent('')
    };


    return (
        <mesh onPointerDown={handleMouseDown}
              onPointerUp={handleMouseUp}
              onPointerMove={(e) => {

                  const hoveredBitmap = getBitmapFromPoint(e.point)

                  if (hoveredBitmap[0] !== lastHoveredBitmap.current) {
                      lastHoveredBitmap.current = hoveredBitmap[0]

                      // console.log(hoveredBitmap)

                      hoveredBitmapStore.set({hoveredBitmap: hoveredBitmap})

                  }
              }}

              ref={ref} position={[1000 * 50 - 1, -1.1, 1000 * 50 - 1]} renderOrder={2}>
            <boxGeometry args={[1000 * 100, 1, 1000 * 100, 1]} />
            <CustomShaderMaterial
                ref={materialRef}
                baseMaterial={THREE.MeshStandardMaterial}
                flatShading={true}
                color={'#ff9900'}
                transparent
                key={Math.random()}
                uniforms={{
                    playerPos: {value: new THREE.Vector3()},
                    tex1000: {value: texx},
                    zoom: {value: 0},
                    time: {value: 0}
                }}
                vertexShader={`
varying vec3 vPos;
varying vec2 vUv;

void main() {

vUv = uv;

vPos = csm_Position;
}

                `}
                fragmentShader={`
            varying vec3 vPos;

            uniform float time;
            uniform float zoom;
    uniform sampler2D tex1000;
    uniform vec3 playerPos;

varying vec2 vUv;

            ${shaderNoise}

            void main() {
            vec3 c = vec3(0.1, 0.2, 0.5);
            
            float a = 1.;
            
            
    vec4 texColor = texture2D(tex1000, vUv);

c = texColor.rgb * 1.0;



    float dist = distance(vec2(vPos.x+50000., vPos.z+50000.), playerPos.xz);


    float zz = smoothstep(0.7, 3000., zoom) +0.0;
    
    zz = smoothstep(0., 1000., dist);
    
    // zz *= smoothstep(0., 2000., zoom);
    
    
    float distFade = smoothstep(-300., 1000., zoom);

    float n1 = snoise(vUv * 24222.);
    
    
    // c.r += zz;

if (n1 > 0.0 && zz > 0.) {
    c *= 0.8 + (zz * 0.2);
}
    
    float n2 = snoise(vUv * 28777.);

if (n2 > 0.2 && zz > 0.) {
    c *= 1.2 + (zz * -0.2);
}


    float n3 = snoise(vUv * 5222.);
    
    float n4 = snoise(vUv * 15222.);

if (n3 > -0.2 && zz > 0.) {
    c *= 0.95 + (zz * 0.05);
}
   

if (n4 > 0.1 && zz > 0.) {
    c *= 1.15 + (zz * -0.2);
}

if (c.b > 0.5) {
    c *= 0.9;
}   

c.b *= 0.8;
//
c.r *= 1.2;


// vec3 cc = c;


    // c /= (dist * 0.04 + 0.5);


// c *= 0.2;

    a *= smoothstep(-300., 1000., zoom);
    
    // a += 0.2;
    
    
    float bigFade = 40000. + (zoom * 4.);
    
    // if (zoom > 500.) {
    //     bigFade = 1000000.;
    // }
    
    a -= smoothstep(0., bigFade, dist);


    // a *= smoothstep(1000., -300., zoom);


if (a < 0.0) {
    a = 0.0;
}



    vec2 gridPos = floor(vUv / 0.001);

    float lineWidth = 0.00002;
  
    
// Check if vUv is on a grid line or outside the padding
if ( mod(vUv.x, 0.001) < lineWidth || mod(vUv.y, 0.001) < lineWidth) {
    c -= (vec3(1.4, 2.7, 0.0) * 0.02) * (1. - zz);
    
    if (c.r > 0.5) {
        c.b = 0.8;
        c.r = 0.1;
    }
}

    
// float padding = 0.00025;
//
// if (vUv.x < padding || vUv.x > 1.0 - padding ||
//     vUv.y < padding || vUv.y > 1.0 - padding) {
//     c = (vec3(2.8, 0.64, 0.0) * 0.8);
//     }
//    


if (a < 0.) {
    a = 0.;
}





            csm_DiffuseColor = vec4(c, a);
        }`}
            />
        </mesh>
    )
}

const m = memo(BigMap)

export {m as BigMap}
