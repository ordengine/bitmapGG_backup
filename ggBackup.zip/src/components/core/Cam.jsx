import {CameraControls} from "@react-three/drei";
import {useEffect, useRef} from "react";
import {useFrame} from "@react-three/fiber";
import {useControls} from "leva";
import {startedStore} from "../../modules/stores.mjs";
import {getElevation} from "../../modules/getElevation.mjs";

export const Cam = () => {
    const ref = useRef()

    const {fov} = useControls('camera', {
        fov: {
            label: 'FoV view',
            value: 32,
            min: 5,
            max: 200,
            step: 1,
            onChange: (v) => {
                ref.current.camera.setFocalLength(v)
                ref.current.dollyTo(v)
            }
        }
    })


    const {dragSpeed} = useControls('mouse sensitivity', {
        dragSpeed: {
            label: 'orbitSpeed',
            value: 84,
            min: 1,
            max: 100,
            step: 1,
            onChange: (v) => {
                ref.current.azimuthRotateSpeed = v * 0.01
                ref.current.polarRotateSpeed = v * 0.01
            }
        }
    })


    useControls('mouse sensitivity', {
        smoothness: {
            label: 'smoothness',
            value: 1,
            min: 1,
            max: 10,
            step: 1,
            onChange: (v) => {
                ref.current.draggingSmoothTime = v * 0.01
            }
        }
    })

    useEffect(() => {
        window.cam = ref.current

        // ref.current.mouseButtons.right = 1

        ref.current.moveTo(-0.0, 0.0, 0.0, true)
        ref.current.rotateTo(-2.5, 1.1, true)
        ref.current.dollyTo(40, true)

        ref.current.minDistance = 2
        ref.current.maxDistance = 100000


        ref.current.draggingSmoothTime = 0.08
        ref.current.smoothTime = 0.12

        ref.current.dollySpeed = 1

        setTimeout(() => {
            // startedStore.set({started: true})

            // sendChat('welcome to Gladion! [test build]', 'system')
            setTimeout(() => {
                // sendChat('□~~~~~~~~~~~~~~□', 'system')
            }, 300)

            // if (document.querySelector('#load')) {
            //     document.querySelector('#load').innerHTML = 'loading map..'
            // }
            // setTimeout(() => {
            //     window.tileCache = new Map();
            //     window.bitmapElevations = {}
            //     printTiles()
            // }, 1000)

        }, 3000)


        setTimeout(() => {


            startedStore.set({started: true})
            if (ref.current) {

                // ref.current.moveTo(-0.0, 0.0, 0.0, true)
                // ref.current.rotateTo(-0.4, 1.6, true)
                // ref.current.dollyTo(7, true)
            }
        }, 1500)

        setTimeout(() => {
            document.querySelector('#load')?.remove()
        }, 4200)

    }, [])

    useFrame(() => {
        // console.log(ref.current.camera.position)
        if (ref.current.camera.position?.y < 3) {
            ref.current.camera.position.y = 3
        }
        const x = Math.floor(ref.current.camera.position.x)
        const z = Math.floor(ref.current.camera.position.z)
        const elev = getElevation(x, z) + 1
        if (ref.current.camera.position?.y < elev) {
            ref.current.camera.position.y = elev
        }
        // ref.current.rotate(0.002, 0, true)
    })

    return (
        <CameraControls makeDefault ref={ref}/>
    )
}
